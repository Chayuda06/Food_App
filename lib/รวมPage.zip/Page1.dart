import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class Page1 extends StatefulWidget {
  Page1({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _Page1State createState() => _Page1State();
}

class _Page1State extends State<Page1> {
  // ฟังก์ชันสำหรับเปิด URL
   int likeCount = 0;
  int dislikeCount = 0;
  void _launchYouTube() async {
    final Uri url = Uri.parse('https://youtu.be/f9_Uhxgb_Aw?si=mUo_6n41WT0IoK4Q'); // ใส่ลิงก์ YouTube

    // ใช้ launchUrl แทน launch
    if (await canLaunch(url.toString())) {  // ตรวจสอบว่า URL สามารถเปิดได้หรือไม่
      await launchUrl(url); // เปิด URL
      print('เปิด URL สำเร็จ');
    } else {
      throw 'ไม่สามารถเปิด URL ได้: $url';
    }
  }

  // ข้อมูลเมนูแรก
  final Map<String, String> menuDetails = {
    'title': 'หมูสามชั้นคั่วพริกเกลือ',
    'image': 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEhUTExMWFhUXGBoYGRgYGB8eIBoYHhcaGx8eHhsfHiggICInIB0YITEhJSkrLi4uGCAzODYtNygtLisBCgoKDg0OGxAQGzUlICUwLS8wLy8tLS0vLy8vLy8vLS8wLi8vLS0tLS0tLS0tLS0tNS0tLS0tLS0tLS0tLS0tLf/AABEIAKgBKwMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAAFBgADBAcCAf/EAD0QAAECBAQEBQIEBAUEAwAAAAECEQADITEEBRJBIlFhcQYTMoGRofBCscHRI1Lh8QcUYnKCFTNDUxeSov/EABoBAAIDAQEAAAAAAAAAAAAAAAMEAAIFAQb/xAAuEQACAgEEAQMEAQQCAwAAAAABAgADEQQSITFBEyJRBWFxkTKBocHxUvAjM9H/2gAMAwEAAhEDEQA/AGyWPv7+xGmWn7+/p8xlkK+/3/WNkuv3Uv8AqfoIggzLEI+/1/aL0o6few/WPsqX2u3Qq/ZMXBPx+n7qP0i8oTKQjf7+zH0y406Pv8/i0fSiO4nMzAuXFExEFkYNarCL/wDo6QHmLAAvtTuYo0uuTFsyzdvv+0CMXmkpE3QVoIZzWqSOfRmbrDviJWEVKWkLQXBL+YHdqbxzyXlaZMpM6domTFF1JIBKEEM3sH2N4ytXqGrOPH95p6alCMv38Qxl0yXMClqmJTLDgc9Q6GDWX5Cib/50ksCQliQDZ60sfiEzD4jCBQQgMm6QCq55vX36RsnYuXh9KpKla9QUGLdwRv73cwtTrcOQ/IjFuhY/x4j0jw3ISHJWpuv7CLMDg8GtIUgIUD1f6E/SOe554lxCJ4nAhpqAwSaAHh0kE1LuzV3jxly5pKdLq1H0gGh0vxUo1YPdr9je1MzNWt26nQ8Rj8NJmeX5Y1AA0SGD2c9Y+rzpGsS0oIWR+IAAb7F453MzRBAMwjU4A0uNIeoUC9R1cXpFuY4lMudKMpa1E6uLZDgqeyQSa0tFRr2YnGPtNFtFWg9/wfxmP6czmIUy0OndQo3tvAfPMyWZ2uUpWhMvSdLFyS53cD0j2j5kmYmbJSVkBbVdt7GkK2d4ibKXwq06n0EGji4MBv1djJhej58id0ulR7McZ/sYSleKlyViUoeWVjUgEghtRf3Jc1Dsa1h0y/O5cyWFlQCmqH3HLvHM8fNlTJcpcxGpQoVhXCGNQGvU0pTaPWX5hpGlLsKAPfqdoqmqsqOc546hLtIrjA4M6XmWaAI/hgTFFwztsblubD3jlqFz5QmzVSipbl01s5HC1WHPpBzKs/SoEkFgHLpPJrM8ZsdnAMwJQpwQW+LMR7wvZrWvA3jBErVoiCQP3LpeNOIloWtkSzpKEAO3Mmwq30O5jxmEtKDpSa8g6gKP6rcoowgAAK0JIJJ0pLaVc26cqb1MasGPxkAqDgFQ4X67PUEUi+7gEcmcZGrHtH5+83ZJlEjEDT5ikTkjiAYhnuPkPXeNc/wZMHomJV3BH5PAjDES1haFJ1j0sSG7hmL8n3h8yPFLmyUrmJCVF3A7xraV1sXBHMSvRk5ibNyDEIvLf/bX8qxjmS1JopJT3BH5x06PEyUlQZQBHUPDfpjxF9xnM1KilaofsV4dw6/w6T/pLfS0A8b4RmCstYV0ND82ipUyAiKxMVqMa8fgZso/xEFPe3yKRiUYGYQTy8SPjRCYrLzyYhj6Y8mJOz68fdceRHyO4kh2Wr7+9hG/Dq9uvIbq7mBkn76nlGyUv3/U/sIZUxNhDMpYa2wDdDZPdRqekbZaH7v9dz2TYdYz5ZlcxXEp0jYm5JuoDbkHhgw+FSiwsG9ovmU2ZmKRgiamg5bsLfuY2SsKlOznmYvaJEJMuEAkaAvizK5mJkeXLUAdQJBLBQANLHcg22jTis4lIBY6yKMmrG1Ttv8AELeK8XqTVZTLSSU1S7KHuPrSsLW2V7SGMaoS0OGQciKGEw0xEyYhaAtQcJaocE1SfaLJuHnOFFBD+kGjuK9bbxdmE/Wj+EkhJTqCg5KmUQQ/4Wp8xhkzJkgmYvUDq4U6nCa1pWv5R5x6QWLDx1NW3W2W2AYGfP8AqSdKRIAdMvURVT27D6VgThVGaQkAqPpTVq7V2a8fc7xgVqLDibao7d4G4Ba1LcKA+gozVSLgsbQStA/uMdyVXjuPeSYBU1KSUsWdRASS5PqRy3o0NMqYgJKaFhxDcOHdt7wj5PnoTLQiWVAi6SxJJVdLAP1uaJ5RDnrrUkywskkVc0BJLBt6kmLFtjYA/rEU0ttzkDgCeJiSnEKWZbhS6rcJ4dQJo/E9L2YNcvrzvNytIRMCClwUhHIuK92FekYRj/MAQlAOwo9z91gyMsleSBNICwCQRcVdgr9P6wutrseeI1q9EiqN3f7/AKzNl+YIl0Ex1BSQyWBJYdO+5/OMOf4xH8RKlHSKAUB9Wpjsasd4xKny0FQQbGrivybQGzJJxMxkliEtW1CafnWLpy/wJcUDsCDcRmBUtgSEJchOqlqxowWPWWYltzyeC0rwqJaULUsHU9Axe49P79IN5F4aTLQZy2dxQJoBRnPOlH3htmrbgShRkO4+Z98KKmaJjSlpSpvLWbkJBBYXZ6uA1YJYXKjKqVkJNVLWqxJYnUbm3zG/ClJOpJp6Xf8AFy57G8Ac+z2fJmFCdOlReof4BPaFWVSfzLVV2WuUTgn5l2FVLmlaEvqSqvJT/tenSMuY6pYdJtRifeK8ozOcuZ/EcmYeBRoym25bRMyzYSj/ABEpIbiF32a0QKN2B1OWUW0NtY5MwycahlzFLSlYA0pUS+smgCb0qXbltDP4d8aTky9BeYaJSCirk7MQ8c0XmUqaopQlKNSvWt1aRVgKOlnuOju0E8nzZeEKglBUpQYOoaUn8VOZpa9I0FZqxwOYs9aWAgzt+SZqVky5paYK2YNbn+0Yc38S18uS+olgoB3a+kd2jm2ETPxCjNViA+kFTH/8itW9mduUEpGCQ+sTjqDVNn/bbpAtTrLBXsXg/MGv06s5Jb9DqO2V+ItKtGImJ1ULUdI5qs220M0qalQCklwQ4I3EcnztU2ZpM1CClNUzXLnoDcc7fMX4PxVNlJ0Spg6oWhtHUE3q9+cX0uuNa7bOcefMG30xmA9Pv+06ktIIYhwdjALMvCkiZVI8tXNNvcW+GhYlZnOxBQ+I1caANJCGc1cUJ6R0URpUXrfnA4ieo0zacgMeZzXNPDM+S506080ufkXH1gJHZoD5t4dkT3JTpX/MmnyLGLtV8QIs+ZzExCIMZx4enYepGpH86f1Fx+UCYCQRChgZ4iNHoiPjRadh7AYNc1QSgV+iRzJ2hyyrI5cpieJY3O3YfreN+DwiJSQlAYfmeZO5i+GAMRWQRIGZlm6ZStLalM5Dsw223jPis7dH8JJK3AY0Ybmt6QN761yCeoRanIBAhp4H5rmiZcmZMTxlCSWSX6fEBhiTMJClFwKjt+UZcXK0pN7bUpb+7wjZ9Q49gjVelAYbjFJGoylLC0jWsEgk6noxYbOSbi0YE5fMM3i0r0sJYBITXi1OWNS+1XPJj6zvAnUhcoAanarBqHrzMeTj5iBpKbXS7sOZZ4zhZheB/eadlgawgHk/ubV42fLH/jQlmcKdgKUFapJduYF4W8djSVE6iQ7h7joefJ94txOOWTxBwC5I2FIFZvikeYoobQ4Zt6be+3SLqWbgiCq01dPuHc9qKpimSzl+3ONyclxCRpVLlh3SdSg7mrsORa8CcuwmIExM1aSiW9lDTqFRR2JZwacxHQpWMM1ImpUCwYjUNiKAMGKm1O7Vi7gpx9pZn9RRgkYP+ojKEyQvQsMqhSxuNiD7XglgM3OsqXV/VQOoH1dHbc1izP8ALyo1eodyCxFwX59O0LE9EyUWNa0I3jigOMjuNbhj3R4lZmmvlhbAbsSb1LU5W3jJP8S60kFdRYcuY7wv4DFzkEaUggkEg9PraJ4xxqBo0qSVq4lgJbTyetSR2PD2gY0+59vzONYqDdKMyx7alPVrdf3inw+uYtUwnSlgOJVOyX5nlAfDqWpYYKUouUjQT9B+cHpWFMsuR6mJr0vDbVrWm09mVpud7AynGI6ZDMlAvOU6gQwFmcbkDudma8a8yzcS53lpLoJSsMaObG7UHOFjLcStagE1JKUhLnt8C/tFGOmnzV+kqSoJKWoCN2IazFoTFbE9cRlrK/UJc5J6H3jEjPVJQWClLK9VAKgsCT7BqXfo8ZsRgpmJ4lug7O7fk8aJk5SJcvjSlaX1MwFS2kUa25O0MScQkyvMJToYcOoUL32JJ50NTHDWM5B5+YnVrzvOwcg4/wBReyWUqWviU4YgAt+R6QI8QJEzEkTaFKQA1Lg3Fas1bwWxeKnTElcmXwBwVOk1ZiWNe5AhOwuDmzpqvMmBNbnUdXKoBA5VMXrXs5xJrGts5Ay32i/j0GWsgVSCWMbstzhNlEAWOr6ffWHjKvCstesTUeYmpBcsGf8AlUCo9QWi1XhPBJ0K/wAs6ABq1FV2BYAqc3q36GHDamz3f2ilItB/wYHwOIlK4GUHqCLbc+xq8NODnoUhJ1PpVpKX2alRbenQwKwnhKSdTTVSpbApVq1BI1FxUu7abmkfJGTzZIZIE0Ek6pbk05i46PTrGbcEb+JmijnIB4h/Mcxlgp8wulLOC1RQFvse8BJuiYpc2oJLuX0s7DeotXpGiRkkycomcRKCB+PnWwF23PWBeOxWlCpKlhYHoKaj1Oegc8+faCKMjBkVwjew8ifBiVBQJUkoFSUOWFK9A/WOieDvEqHKH/hAO7ele4Jfe9I57JnJDJFNNxpFe6nqerdoP5CtKVcKdKWoVF6n39gTBamFNgK+fHiC1StfWS44HmdN/wCuSXSnUQVFhSCUcqxapnmV1ncBw3cNHQ/D8xapCDMqWvuR1jVo1JsYqRMfUaYVqGB7hEh4WM88JIW65LIV/LZJ/Y/SGiJDRUGKg4nIcThlS1FK0lKhcGKmjqeb5RLxCWWGIsoXH7jpCTP8L4hKiAjUBZQIY/JgJQiFD/M6NEjDmmaysOkKmq0glgWJr7AtGqdOCUlSiwAeDZEFgxP8agpU6Ukkh3FHLMA7gXrWBKcUsBDgCtVdO/vDFj8zw2KlkJWQoUYguDVnAeEyXikqK0VOn1BmY1DP93jB1iAWFge5r6awbRW3BjPhpqUlRcEEXfbrz+kYMdPSuYCicSL6RYN2HO/YwHUuWQUrKkuAUsH1FlEVelAa9D0ig+WhQSlTimpjUAsalv8Ad8QozezgRtaFB79344lWIxStJ40gDUSk/iJ6btUvtHnDZaqVIlrTxLW5VpLsdgWrbn1jPLIWvVo1VOnfoAGp1aMUxaytSUhSVC+oM3f844nI2d/ec0ejFdp1FjDPxPq8vROJWdSQlTKSgXPUbXqaX5wcwfhmUkJmiVxpcpBWS/XSXaxIfnazZ8MtEpASkhZuoszK5gV63e5tvajNFy3UADQs5AanWu/6Rb1cYUGEtG9iyjExZ1iBNYTVKKQ1UlmHR+X6QsYPHKS4BLPQncO9e8EcXidTl7qeBOOkGStl0BDhw16hu/KC0glSpl7AqYPUZ8Nipk5ACiDpbhINas1LsWFOYi6b4RnTiP4iAi9XJBq4At0YHYXaFvKcxEuYlRqncU7frHRMHnsgBIJLaXdQIp1sTzN7QapFTOeIraX7XmUZb4OSglXnggJBNK9+0WZl4ZkzHWqXKWsVqkdTZj2b6xvweZJmABKKHnckRjzjMChYcBSR6tIrQVFBvCrXAE7R/XmRKrHbBmXGZn5IJMsDQApIuCC1Eh6cnLAXaFvxBLRN06Fp81TqISaVqATsQS32ILFcuelSJhKVn0OzAfhBbfo8K0hPlkuKuQ/YsfqIiHzjkR+ilTZgnEwS56pa7lKklqEhj0MXzUKniatBSFlitLtqNOJPV9RYUSHFmEDM4x6FTHR/yI5v3cx5k5iUl0A63DaSXfo1Y0FRgAcdxTUBHJUnkeYzaZctGqauoYhJDuXqGo1YF47xCqcsSZbpBpXYN0b8o0TPC2JX5RmTZYSv/uaVjUgPYE8Kjao3cbOSON/w8k8AwcxQnJ4pnnLpoY8kipLdGeBhKV5duYsC1f8A61/JmzKMSqXICHBQA6ibKFTbe5uHqYInMJKmYIJCAUsEsQQeEhtv6wtoyvEJVoJQoGiUg+k8y/0uC9oY5WVoEtjpQs1IQH4nYuSXfp0hGxVAJ3d/EcrvqJHPHUmAnhC1KE1kquhuEHoxPxB5eNGICkywNRQQpRJG3bf2/OFcZIHAE7idiGp7H7tBLKPLkBRJVMVWooGBoeb7xwkkZBjV6afkpnI+0xY2cAjyg6ppsC6QgcyFJq7FmMe8mRiEEKCVh2BJpwg2vF2MzV1AqRqJdiR+E2IS1Qz83faMmJzKaEhYUpJoAaM7PRqezUvs5KKl2jMCNQxyNvfzDmbyzNJJmJSGcBd3HZwN/iFrF+F1KlqnCZLqSUgaiTU0JJp04d6xjXijuSd7uSTTl9YIYGYqYkjUEqe5H4QzsAR1joyCdo7lLMqg56+0DYHCqZyHLkFP8pEbVZoqSkhPr1JYHeuwgksoSFkUddB/V2bsIzSyFzAlgnX6VWOno43i1jIefIltNbZgp4PzCWBTjFrCphYkgse1gxp8PHWcqQUykAgg6Q4N/eOVy8bKwxEogvu6RR7Mbn6QewudLmy9C5hKRvpbs+5g+j1SqSW78TN1tW84UzoMSOXDMlJX/DFAeZd46XhJutCVfzAH5EatN4smdbSa8Zl0RokSDwMS/wDEucRLkimkrOpwG9Lb71p3gKpCZkkAlRJLO9FEF3arUcNcw7+KMCJ2HUCWI4geRs9ehMc1wCVJBZSgzU5/PJ+8Yn1A2K/tPYj2mr3VnB5zDeXZfLkySdZBdyFnowS55bd4Ws4TonlQcamcEM4LOEkb0PzTroxUlWtK5nlEkhLKrpFHLbaand2sI1GSsFP8VkqBOldGYsQW6B3FRuIRRbSu48xl9Or/AMm5i7ivEgmKTpS0pDodgCWepYGj2j1hMVLKQNQJ1EvZnv8AkB7CGfy5CAyUJdV1AVqXJJvU+/6i8TiZxUKijuABxU3cE+0RtnWef3GqRhQAOpXLxstJ0pULU77wAxea6ppTUEXL97jn7xtOCRNWNMtI0qIKnUBRJqSOQcjmwvFs/KEIX5hm+ahLkMlnI961/KO11qpyTOFw5G3wZmlzFAAl2U4IaxFq7ghi+9eUUY/GBKQpamBo169oMIml3JPlr4SQLPu7UdhStGo8YcykJExyEFWkEcRVQggNs4NDTrd2uK1JzDhyOJlwkoTK6SQ1AaVJpTcfR2rBTPMnSEnUoKUlKnAZ3KNjyBFuh5xgwGEVfU1jV3cf6bNf7MFsVLASoetH8zsQN+T133vSOl1X+PcHbW9pw3RirLypIcTHYlkgFiQC2omt/rF0nK5wOlKnQkOVKNQl6B9zyLe1IY8vypHmlalgJUgBAUN0tYvU3cdRGBeCnOoS1KWAxI2A2JIDc2drR03Mx9vmNBUrTZ5Hn5jBh50qVKZCEp4SHSmqiA9XueZinw/NlKChOS+ssFfp0/WMyMnUUhJUyyWoXAUEqJHPYO4pTmI+YUBBSkoCylyS/CKEVPdy17c4A9b49x5lEsrFTbeyYRnZWpaZiQ1xxWNWNORFfiA+WZMlU6ZJxYK5YDJKeE6lG+oXoDZmNxB+WtK0skAl2BJZLtV1DZtugq5Mec2QtKDNcAgD0qqqrEUAYBhQXeL1MAnB5xFGDbsNxE4eDcNJTMW5UpIcJWx4dv8AkRXUGHINHvCCXLlyikMpISxPazc7xqz5ShKRMQHC1Mbkihpc8jQ7iFyZipgUrhSEqs1hvc/e0EVnuXJaHotorBHk8f1jMjEzCnzEIOgu500cdrD9oMYHHOtJ4g6QFG5p/Z4S8PnBKBLHCmyutq96D7rBTKsUA1ia1fo0AeoqCIxw68xtx8yWSyaBjUDs/ehdoBScx0zXmEAjhJ3NNLm9WimdiQJbuyxUW9LV9xeBONWVV51oYoteTmKXaNXUAcYMY5pClzAhQKXYsdqK9qtfnGcKAsTQhyCf5g5+OkAMLP0DgLE6nqQX+/zj7icyKEuaAnS7VIJ5PSDejzgRksccmap+PKFEauEWBeoqwb36W5x4mYsTA9H9g/VyW+TAbMM0TwhWrWzBOlywJbpGBOOUtwhCn2CqW5gQ0unJAJiVl6g4HcNLxgIokUBcg3d2PPdt7e0epeY+TLUrzAFbDclrDnATC4GfNUxUJYfYO/JnreCknISlpiitQDkOA6i3S1YvYta9mcr32DiecinTZyjqPCDdX1DcoYM1nvQ+pNQsVHz+kfMImQlKFvpLsqrsWuRe7fJtF+MyorNGIA1AbEitenMQna2bcdAwxsqTCPndjvxn4nnA4iZjEpStSgUKIASzqtuXf4gz5hSnyVyyECgUWr/uNlG9GhWwRXhlpJS4qohiakUrRh1rDQvM/Nkam4goEB3cMxu/OBOGDjHUuxrwOM/P5muS+kEhxzFAU99+wjouQrJkIcEU37wiYAyyONekpqEAUD+1jf3hxyLMyvhWz/hIFCOXeNTQ6hS2D3MfV1kdDiGokSJGvEJ4mocEc45nnOBEuaQsfiBDfpHT4UfGmbS5SkyykKJBUQoUGwvQ706QlrQoTc3iH09hRuIh42aJYSSnzEhfpN18EwFJo4q2xZxygcnM1nTqZgkhLClTe7OzCgFA27xVihMUFKCgJZVR1FwsBXpVyDqd+fOMUvCzDRTACgY/QULk3jMYZUBeptUOjDcYwS5+ugGphcco+rw8xY4U061gPlgWhVS4VVA3bUQHF3oY05tjlg+UV6FFnSSxUDQAc3hA0MH2iaCVoU3ky7AyClPlOkkKKioGoBv99oLLlhSCGZLF/rf3jHP8PrwyRpRpmLN1q4SkB9jQ3oOcERIdtVGvtBmVh5iTshPs6mHDJWUpAQNBBFwaAg222PzaPq8pVMWiWkMrUeI2tvWwY93blGyThjLm6jpCCDvxau1PvlGrESlqshwC4Nah6W7ivKsVFgA7nSx3ccQTnuSzMMxQsTNgClizVepHV/7wMwOa+kFQ0q2UCoEHagZqPBTMgpGqgqGDuyKtz6X6CzkRz+dOmBWhSVFCVEK0hj8tWg7wWmoWgy7WsijeciHfEuepFJYIYBWqo1AuQBzBY1FPrFfh3xIpc5alsEzaKSzpQAOEAc716u1IVs2w3CFDUSSeYARtQ1BfbvFeD4aB60p+n6dhGjVp0rT2zOex3sO7qdDm48maWJT5auFL1AJrxBg+xPQDlBLCzwhCyzqW6qc6m/QQnS8yWFplzB/KlwGewST9PeHaYJSZYDhL0JAJLNsTCFoKnJjzupAQCUYbHKVLEsAJILggAjT/AHjdKnK0kTNBIG4dztpFWqBtte7gpWBKyUylnQnics9xYgdfpDJgsEgJExEwKUbqBc+kHTT7pA68Id4GYvq2V/ZuxkwRjcUllobjCwtLuOJg5B+sYZmWhYAKkpdgLC9X7M9yOUMuNwgmeoOUkEE3BFdrQCzXGolp/ioStTl0lxYECoFg+7fBeB1EO52/mdq0lSr7uTErHZWuSCrWkkE0D8zY/vzjb4fxaFTEBerS9g9/tviPOWTpeJ4ykM9qgDsl2aC+TygF6JZUhyQNNmZzc3NPjtDrOOVfsR8UMtYdT7TBXifFrlHT5SxrPDqSsGmwcB77c435VhiZaVzUKZSbB+E9Rd2Ztr0MOeNKjpl6kqJVyrY9/wC8XYHJJuvzJh3NAb/7v2ED9VTX7R/WZ73WLaAeRE/KvCAJUUzJpCiWehBPN6M+zDl1i/H+EAxpM1AVdu1Ki/8AWOlyAEiiehEX+QDxILEWI7RN7Nzu5gmuI4xxOZYHwmZwAU4UigJDkUoHe3YxfI8NolrImlvxagNh0vfZ93hpzKRNC/MQtRajA6S16bHq72gDmuaq8mYZyWKWYsEl6iwoRUVEDLORjzAs72NtAxPE3BSJaH0oU7NQKfmbWjDjNaVGXKWyCNQJDAC19wOf7RkwE2WpSiVHy07lnJ+/0jJhZEzELCJaiRMILM9SoXBrQ/SsVVMsd3iF0gt0zhzzn/uY5oymSuSE6UqmJAqQOJQSA5oRUbwEOZSwAkqKSCoaS+okGqQOe9KQSw3h6dhEHzCsqTRMyWXAQLOlW29i23OBsyUJhCpiz6rpqAkgU3cvWj23MDQAMd75GfxO2HCkl+D1MWLmzpqtKEepOokfyvzsK0Z4Jy8rmyEAmWAq4KCpW1iNuf6x9xuOlYdwiYrQQC+2pzfr0j4rxS4JmEggONIovkx7/EFYsOFWNoNyA+Jml5ikkqoCoVa9D93ho8L45S5iQOdGFupjnEiRNnrGlKiVGhP6mOl+C8iTgyJ+JmgzFHTLQkGpPINqUb9BDaaMlw/7gLbUFZXz4E6OIkYsvzJE7UE0UgspJZwfYkRtjbVgRkTEKlTgzJmWPRJQVLLULDc+0c9zvHf5hSvMkKLFgSptNjYF2qDyh68RYPzZC0tUBx3FWjmWNx0zy9CSKUBuR06RkfUt5YDxNj6XpUuBz3n9QBmGKSk+WlRoSXFEsKApH6xbKVMSlM1tbFgmlC3Coi1OTbu7xmkZZMBE9SFaHKfcB/isOOX4RIVdywKhsDp/Nvz3hWyzkYEdsrWrKg5xFuVmKlLC1SgJqSAHS6mNmpc7G5ekaMRNmrUFCXpmEpQCoDVxKYbenUADXlB7NUKA1JTqIqFA2IcX51LXrADK/EihOklbIlJWy3DGoUOWxYnYNA0XLcA/uXFm6vO0R2OEnKwyUTVBa0pcr0M5HIEm4o+722gSlIZ3FzZnABPsTGjxh40kYSWriC5rcMtJr3UR6RvXlR4V/DGYKxEgTClOpQLmtWJBYVDOOf5R3UoxTcOupn6fOeeIaweLBWf4YWkBuKrK+6e8HpmPHllZrR+5+6QkzBOlK4EEhhUE9+36xTi8ynTCJRFSfxGgF7jpzhauphjErfqQbMbD33N2Z4wTdRYg0U12G5IuB3EB8GtK5iAUD+I6ap9SqM1qEpSNJo5ghh83WUIEvQND8xQgA29XpuHt1pVi8AJ6kqJUDpcoHcHhuwNWNWKhtDQUI3EeD7kIlM/Dyn0jibVUijCpYgseLcHnzhOIEqZxG1r0cvb3PvDhp0rEzX6RpCVCoZmN2DCgA5FxzGZ7l8zF4lIQlIWpLKJLAaX4nFTRhbl0hmsqCVJ4i43hFuK4H3nvKjLxHliYh0BSiOJiVBmD6ej3ItSHxOFAQQtlNX9vuveOcTcixuDSVKQFIB1KEtRJATXUxAeg70rzh/8ADmaoxeFSpJGw2BB360o/tHHT468Slty2YYH8y/MMDKl4aYdYS6SAEno9W7Py+YDYTA4iUAqSpM+WbKRwqHt2IdnseUWpmCUspXqsU2dq7d+nKK8twMuUXStct1MQFGtXS4dt/pClViAFXEX1mgezDKYZw2PSZbqFWNahv9Nr0PKxgJ4ky0YlAKNDkhJKw4Dmr8ubjqI+YyQDNSrWEoKlD1X07EcrkN+tbcTgwJKyiYVKRxdCk3FAKitfsCUEMGB5milapWFJP3nP8ywxkf8AbXpWFEqYggpG+kAlv9VqiCGU5gvUVJUxUnSHA35i3V+kE8TjwqWlkrVNUNPCfwmpajgk3ILbs7Mv4GalOnUkhWo6gNqhqH3+I0yd6dcxGq5kdhnK9idJ8OSkEeYSrzdgSVBI6mwev0gzgFkzTxuA9Gb551r3MIicepGkpI4g5G12IY8iG+IM4LxMUpGoCm70B2IF3Ad77WtCJVTw3GI5sdxvXnMc/OBcpvyP33jLicSE8YPcV/t7wtL8TeYyxoUCpt3Br1q9TXl0gRm/iAqo5a2kU+kDZcnHM7VpyTgmOE3xBKavq5Wtfp79RCbnmegm3C9gAXvd4zycPNWlMzQyW1a3DBJLOK/SAOfYKaCWBUhyAvYh70JIehg9SF2AJ6l7FqpU45JmjAZKcRNfzxJkq4ghJJUR3oB/Q0h4yzDSMOuXoCpZD8WrVUbkkVfrHOcAqZLRKK0LRqcAqSwLNQP3PyIZJWOAlvqIi2q3/wAR1GdDp1tq3buejH/FeKEeSokAqALB/Upn5QiYKaCkHVR+W/aB+GSJylKKmS2lz/eCmAwyEghI1EO5JZuQ+lxCjrgc9zzuv9JbDXX4MLTfDomIZkqLAsoMxIBPEH37RiX4enS5Y1aWR6WL96GtR1g9kuK0FZUkp0ioNW+YxZlmmtVGNWofw8yXA9g8EVyQMTQ0zMy/aTKs7lypLIkoE0lgou1uXPo4gXhfECjOMxRUVNpOomnMAH086NeCJwcmalCVFUpWonUhiEkgEaw7selel4YP/j8TQmYrE6l6QBpSCgi4PM93h5RdcMg9RNLko1fI9vmC8hzlYmBaBbhIJ1O5o9iejuaXjp0hZKQSGJAJHLpCvkngtEhYWtQW1gEtXrUvDbD+kqsRTvk+o202Wf8Ai6kIgfOyXDqVqVJQVc2ghEMNlQexEVdl/icRM/xATIl4dCCnSSo6QkMGpqfpbuW7hWVikJqkkKOtKmNLhhvS9b1Z94L+O8eFzgjRqCEqSAf/AGKbi7BgPYwpo1DhcFQuaXfn3eMLXOps9vjibmipPpe7zzNeYL1JASsosCQ9meoehcXF4XsbhlgOv0gtqFyL0FzBlAUVlnUAKMK7Ofl/lo9Kx4fiBCQG0khT7sTyr8/QFZx2Y56r1qVSI6ySSAgaQfUsVAfl9+0MfhLN5YlmWzCXqYbFBUVW51HO141Yv/LzEBPlAGxKaau7v9tSBy8ODLAlAIIAQBVyCXJt0c1HpgzMtq7JnqrI/qPz4/MZZmYkjUpDOKOS5f2v3gDpKFNp1OaAkelya7k6hfdmN2jdjcSFBKWIKZaUhJO4Szq9veK8ERLOossjZqDsTvaFlO3xH9VoqrKRu4b7TNhDMROCkU0kh23/ANpF39vo+ucVFIALFLsw5s7m55NFgWVK1L4au3cED3tGWdimoGp+fSOu7dwFNS1jaJ4WlS3UrVqF2Divffb4hly2WgVSnUaJcPxb3NySeQ7WgHJxaZaQSoAUfUafl+8VHOwmUtQmM+pI2NT0sLHsYGyPYuMY5grdQ1oFXiVf4gZ5MCDJQ4Utwb8KLKApc+n3MJ/g7PFYKaUqfy18KkmjHnzHIw+5Q+gGagcIToNGIPpUBVuexDR6zTIpM5SlzpSCtYId3Ni5DekgvW8N0XJUhqKn7n7yg0ePcpmxefy1MEsVEO7c+rNGnEgFKZj6goEEMaEU+P0J5QgY3L5mHWpIcoFnLqT3aj82jbhs2PllO5F3+3MDspOeOZp1Cv0xnj/MLYDOxhp9eOUARoCQSHALh9wr6ExXnXiNc4ukFKQ4FavS/Kwp03aFyZidI3elizRiXOKrqPJt9qk2a7QZKAeYnbsJ3EQxhZhXMToDqcEfLmsMGfeGUaQqUrTNpqBNFUdwSX9+tYHZJg1oCdCaqbiI2a/bru8MmDz7DSp2nEEgAMFLq5b+YPpFuUBZn34TqAOXbLLjAilleWLPmBR8tabA1BUwevJiGI/SDWVZchQ0q00DrUdhvX3YQcxWDGMnoMshMrSAVAuC5JpzavzvAzxFhZchYlS5gWWBULlJ2c9QX+IoXZjkzS+nqBmsnk9cdCK+a5YlKZikzFaUuwPLkSCPy/eKRlMxaQoTEEOApjYUrz+g7wYl4RU5RkpYguFKIJADGrWfkDv2jV4jyaXh5QXL1ApACnL6ncOfoKUrBRqMYU9mA+p1GmzNQ4xzN2VBAlCStWpIGlxwv8GBuZ8FEBSkSzQ3ALWLfFd+sDMhTMUrWlQrw6VO6yaaQbfmwHKGbCZatcvgUU6n1A2FwR0r3taKLS1bFicgwdzAgY4gtWVpxaQZ07ydJtYjmAGID2cnnSlVrEzRh1qSV+ahJbUzVZzTdrP0hgnomSVJ8ziQj8KGu3Iq+tO0D/EZTipYneUUJSdJIZKgDYqFQQ4PXsIZq/4EcRMLedzFsZ8CFvCeRy8YmYqdMKAkgJZrNQ/o3SPWCyhSFK4tQB0pZTOlyxpfbtC14fxqijSklWkaRWwKtvmw5wdy7EJXWpV9CXgF4cEgdQlWl2kWJyYYQVJGlZDNRiaq3Je/Kr/rGWcnk4eoNrf3jcVFQahAoAbfA/vHybLf1LYPvt2hf0znM0VsA7lOXqdaUlRSVqSBMu3Fcjs+4vHXcny8SJYQFFVySeZuwsB0EcoXKIBCEl9uIcXOOrZEZhkSzMLqKQezi1a/MbH0/jIMx/qSKXFg76m+JEiRqTNkiRIkSSKHjTJgUrnIPEQAUs72BI/4u4+zz+UhjZRNu4rV2ru/SOzY2RrEKmK8JeYp2APYfWkZOs0rO2UE1tFrFRNtk59PQSHfoR78+/P+2nL8ArEJOlctIduOYxUeqWs/W47u74rwumTJWrTrUlJI1M3a1oRMnUhExJWDpBBOmjMX9uXvCbVNUQGHc0qSmoR2U4CzHnuEXg2Kly1O/pJLexA5fWFrK8SqbObUpCWoRzpfnR/n3h88RZjIxCSAJpoSy2UHJcuGDBtg9bQkzJcqQXJKCXABHTsYOmxSQOfiK6hilauT+R5hYicFMlKUgfyqU3c6lKPt0jRJWlF1Anlyb6wujOkoKQt1oo3awfZhU+8eZ+aPpEtIoGKnfUYhozyBKpqBYO4cxmPcGvavxGPDJVOXpG+8B/8AMKuEk7EmwNvtuUbcPMXLKVIJBchwxqwe9K0ipox3CFiRtTuFlolIU848ThghuTXLgH2MWJxMtCVzZktBdwm2wDFmcPagcgVaBv8AlFLIWtTrFQGADvuw7+7RpwSfOXpYAJDMab79f6RQEAcmdb6awrLWEhh1NuV5gMSsBaSSkBSla1BzZgmgAFqdItz3PVSqChcvVwSbb/f1jYfCwAdJUCzuKU6dOsY1eDwTqUS/JR1fW/1igZd+49fEE95CYAyYHwWDxWIQvypeqhPqA52KiOZ+xGrwnlcqbKUJwKJoUUq1Eig5Dn25Q2yVzMPK06wEg2Djh77h/wAxGU44ICkLlgpUxLMS+6hRm3vFbLmwVUffMJS7uAXPXiI/ibLjJmBCOIGoWDQizEbKG97hqRkynw6uaQqYoJA1FgqrBrC1T7tBnNg2oudIdtT2fkfj2EDpWJIKSkK3A5H250hpLXNfHcs9K7kDdEx6TP1SUJYcBYAUJoKAnkBR49T8Bh5slQmr0kPdlNQNw70szH6wrZVn6kT1JnIZBIpZqbsd7uLflqkZvpnzlJQmZqAQk7sLt71elhCoWxGzjxBX3FrSijC+IWTj0y5KUEggIHCLlXIchv0aLsVlKMSiUVNrsFhgptgSzkd9zA+ROE7SgyUO/r0sQN6gspxSoP5Q25Rh5UtioBxZ61FYEynIKnHzCJqML1gwGPDapXEhQdwGVv8AX3irHKXpKZpSA6a3saWD3b6QTzrMqkpBcuLsx5hjQj2fc7Qv4lRZ9RJDVs5jm0Ehs5hhvdTvnxvWglOg1qNRCuYZQIBel2aPOExykSygEsLOOXP8v3jxhqO5dya/FDz/AKx8xKtJo5u4AB+9h8QfIb2wDOqAk+JixonzAZmhSg+mj9L0p9N4YfB2WSgqZLmq1hWkzEkkhi50kV1D01gflc8+WCfxGoEasPPZalp0pNasA78zR6gR1dVhiuIlp7jq3KAYOCYaynASJYZDKCCpKbcAc8IblZ7neAea+SjEOlSdSvWkGx5vzO43j1gFDSryyriNQ9AaNZutYtl5GiatIQwcsLEXuaCFqlc3lic5mmuhNRJJ4An3UDxFQAa1N/uwgngMuXNSClgDYmu/KCcnwMFVVMX2SAB7uKw35flaZaEpSAAkMNzG0mlJb3DiZNusAGFPMweHcrCElK0hRJBcphkAiqXJAi2NBVCjAiBYscmSJEiRackiRIkSSSJEiRJJVi5IWhSD+JJHyGjlWMwE/AqUnUAV1dhao3EdaimfhJa/WhKu4BhbU6f1h3gy/qMEKDozkKszxR/86vp+0fJXg+ZmKFL8wOgkcQuSAbj22jrIyuR/6pf/ANB+0e50oplqEoJCmOkMw1NRwOrQsmg2tuZiYuKuZwrNP8PpskErMvSkUckB+pIG8Bk4e5UlqMAm1LF4aM+xGKVNbEJUshxVXpPMJHCPYMYwf5YqI0g13tU7X+m8LWWEnCj/AOz2Wh+mpVVl2BJ/X7gvDZWZikhfCksBswJFhZ735neHrNvC48tpaQnQHSPij9YIp8ETPICwoCYUupBFAeh2594KyMyQpA1slTDUORaofvHCj5xZx8TNs1I9QPV2D4nLhL0kpLhQ2I+kb8zVIRMliSOJv4inLKUw2fuH3Ea/Fi5SlAIGqYSwa7PX6c4zysMJYDpBUzneu9e5he11rUqfMe1v1OoVK9mc/wDH/P4hLDYhiK8nEbpmIBFLnflAKVN0sVGhNuhjQZhIvWn5/wBIzDnxEdLeuoXdiWJmAlSVDUkkkvR2dhTZzaMmPmlKC1N/mPSDpClO/wC8C8yxCtOoAtsS+0MIrEgGOEDPEHZirgDEWJVewqTXZ6e3WMKlfwZSkuVA8CWd1OaXuaRakGZQoVpNCQLBjte7Qd8I5CQrz5gZMsUHNZH0AF3jSUqq8zmqBLADoQSvKsS/mTZSkilyktycAkjaDGWJDMSQaVrs9C13BseVCIszHHEhyqhBBL7Gh6c4wYdR0jiYX+duW7/PKA72fnGJVqsfyMZ8FKQghTEPUChFPZvveKF4pRmU7u3XfZu8ZETgAyS5HWx5DaPiaVu/xAyjE4lF2rzCSklXEq/eAeezEhJILk7Rq89alBCQSomwjJmnhjGqWk+VrSxdSSC3/Eso+wPWOU0+7mR7sDBMy4EKKdRCe7vQ2jScvmKIWmYyxbgBHwT3jbgfD+NAAMmZpUGukMORdTj4h88MeG1S1a5qEmjAXYWqTc+0NJpbXb28D8TLv1GPbnM5zrJIJIK6CliSWpBdGQYlEwy1Sy9Wax6uzR0LE+DMGuYmZ5ehSSFAILBwX9NvhoYAkQVPpmc7z+oLQap9I7MBnIxOTzvBeIljWE6gR6UlyPaDHgXJZwmFc2WUpTbUGJV2joMSGk0CK4YHqPW/Wb7ajWwHPmfAmPsSJD8yZIkSJEkkiRIkSSSJEiRJJIkSJEkkiRIkSSSJEiRJJlxuXypw0zZaVj/UHbty9ozZbkOGw5eVKCTzqSOxJJHtHyJFdq5ziX9Rwu0Hj4hJSXDQFxvheRMSUnUAeSv0tEiRV6Uf+QzOI7IcqcRKz3wVMkKEyTqmgAv/ADB6UAHInfbrAaXNXqKVgijaj6h3DV5c6vVokSMbXaVFYEeZe9zqAGs7HEsT4QxWL4kLSEiqdThzzcA/0i45ZPw40T0st/UC6VDmC35x9iQW3S1igMIbSXsH9MdTFjpS1IZAdRoyR+kXJkqXhlYcEKOhwmhXr2A3NXj7EhKtORNUvgH7cwQjAzEs6FIb+ZJB+ojUJEyyEzVKIbhSo/lEiQ2ulXdHn+ou1QOBB8jwtmWokYVagbhRb4reNH+Q0cKkKQ9WWGZtiD8OHj5Eg19QRQRMenVNc53Qz4d8OqxIKEq0tdZDttbd+7U3hnwn+GcgEGbiJ80jYlKR8JSIkSGtPWpTcR3EdRY/qEA9Q7gvCmHkVko0mxUS5I7mL1yFJ29wI+xIHqdMhG4cGDWw555m/DJo55Re0SJDVS7UAgz3JEiRIJJJEiRIkkkSJEiSSRIkSJJITC1jfHWBlLVLVOGpJYsRf5iRIozYnRP/2Q==',
    'description': 'หมูสามชั้นคั่วพริกเกลือ  \n\n หมูสามชั้นคั่วพริกเกลือเป็นอาหารไทยที่มีรสชาติเปรี้ยว เค็ม หวาน และเผ็ด คลุกเคล้าไปกับพริกและเกลืออย่างลงตัว\n หมูสามชั้น, พริก, กระเทียม, น้ำตาล, น้ำปลา หั่นหมูสามชั้น\n2. คั่วพริกเกลือ\n3. ผัดให้เข้ากัน',
    'price': '65 บาท',
  };
void _incrementLike() {
    setState(() {
      likeCount++;
    });
  }

  void _incrementDislike() {
    setState(() {
      dislikeCount++;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ), // AppBar
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            // ปุ่มไปยังหน้าอื่น
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/page2');  // ไปยังหน้า page2
              },
              child: Text('ไปหน้าที่สอง'),
            ),
            SizedBox(height: 20),
            
            // แสดงรายละเอียดของเมนู
            Text(
              'รายละเอียดเมนู: ${menuDetails['title']}',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Image.network(
              menuDetails['image']!,
              width: 200,
              height: 200,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 10),
            Text(
              'คำอธิบาย: ${menuDetails['description']}',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 10),
            Text(
              'ราคา: ${menuDetails['price']}',
              style: TextStyle(fontSize: 18, color: Colors.green),
            ),
            SizedBox(height: 20),
             Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    IconButton(
                      icon: Icon(Icons.thumb_up),
                      onPressed: _incrementLike,
                    ),
                    Text('ถูกใจ: $likeCount'),
                  ],
                ),
                SizedBox(width: 30),
                Column(
                  children: [
                    IconButton(
                      icon: Icon(Icons.thumb_down),
                      onPressed: _incrementDislike,
                    ),
                    Text('ไม่ถูกใจ: $dislikeCount'),
                  ],
                ),
              ],
            ),
            // ปุ่มเปิด YouTube
            ElevatedButton(
              onPressed: _launchYouTube,  // เมื่อกดปุ่มจะเปิด YouTube
              child: Text('เปิด YouTube'),
            ),
          ],
        ),
      ),
    );
  }
}

// void main() {
//   runApp(MyApp());
// }

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Page1(title: 'หน้าแรก'),
    );
  }
}
