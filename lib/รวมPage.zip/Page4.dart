import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class Page4 extends StatefulWidget {
  Page4({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _Page4State createState() => _Page4State();
}

class _Page4State extends State<Page4> {
    int likeCount = 0;
  int dislikeCount = 0;
  // ฟังก์ชันสำหรับเปิด URL
  void _launchYouTube() async {
    final Uri url = Uri.parse('https://youtu.be/GdwUwBHiaXw?si=a69lN4ts3dOKSJcd'); // ใส่ลิงก์ YouTube

    // ใช้ launchUrl แทน launch
    if (await canLaunch(url.toString())) {  // ตรวจสอบว่า URL สามารถเปิดได้หรือไม่
      await launchUrl(url); // เปิด URL
      print('เปิด URL สำเร็จ');
    } else {
      throw 'ไม่สามารถเปิด URL ได้: $url';
    }
  }

  // ข้อมูลเมนูแรก
  final Map<String, String> menuDetails = {
    'title': 'ผัดเผ็ดหน่อไม้',
    'image': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQDRrfJ5ZdgEYugXDLsk2JFd48Du8FAI00eOA&s',
    'description': 'ผัดเผ็ดหน่อไม้\n\nผัดเผ็ดหน่อไม้เป็นอาหารไทยที่มีรสเผ็ดร้อน หอมกลิ่นสมุนไพรจากพริกและเครื่องเทศ ผัดกับหน่อไม้จนหอมกรุ่น' 'หน่อไม้, พริก, กระเทียม, ข่า, ตะไคร้, น้ำปลา, น้ำตาลปี๊บ, ใบมะกรูด \n 1. ผัดพริก กระเทียม ข่า ตะไคร้ ให้หอม\n2. ใส่หน่อไม้ลงไปผัด\n3. ปรุงรสด้วยน้ำปลาและน้ำตาลปี๊บ\n4. โรยใบมะกรูดแล้วผัดจนเข้ากัน',
    'price': '65 บาท',
  };
void _incrementLike() {
    setState(() {
      likeCount++;
    });
  }

  void _incrementDislike() {
    setState(() {
      dislikeCount++;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ), // AppBar
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            // ปุ่มไปยังหน้าอื่น
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/page5');  
              },
              child: Text('ไปหน้าที่ห้า'),
            ),
            SizedBox(height: 20),
            
            // แสดงรายละเอียดของเมนู
            Text(
              'รายละเอียดเมนู: ${menuDetails['title']}',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Image.network(
              menuDetails['image']!,
              width: 200,
              height: 200,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 10),
            Text(
              'คำอธิบาย: ${menuDetails['description']}',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 10),
            Text(
              'ราคา: ${menuDetails['price']}',
              style: TextStyle(fontSize: 18, color: Colors.green),
            ),
            SizedBox(height: 20),
             Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    IconButton(
                      icon: Icon(Icons.thumb_up),
                      onPressed: _incrementLike,
                    ),
                    Text('ถูกใจ: $likeCount'),
                  ],
                ),
                SizedBox(width: 30),
                Column(
                  children: [
                    IconButton(
                      icon: Icon(Icons.thumb_down),
                      onPressed: _incrementDislike,
                    ),
                    Text('ไม่ถูกใจ: $dislikeCount'),
                  ],
                ),
              ],
            ),
           
            // ปุ่มเปิด YouTube
            ElevatedButton(
              onPressed: _launchYouTube,  // เมื่อกดปุ่มจะเปิด YouTube
              child: Text('เปิด YouTube'),
            ),
          ],
        ),
      ),
    );
  }
}

// void main() {
//   runApp(MyApp());
// }

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Page4(title: 'หน้าที่4'),
    );
  }
}
