import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class Page5 extends StatefulWidget {
  Page5({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _Page5State createState() => _Page5State();
}

class _Page5State extends State<Page5> {
    int likeCount = 0;
  int dislikeCount = 0;
  // ฟังก์ชันสำหรับเปิด URL
  void _launchYouTube() async {
    final Uri url = Uri.parse('https://youtu.be/Y174QmkQlKI?si=HYOqOsSw57iESfBc'); // ใส่ลิงก์ YouTube

    // ใช้ launchUrl แทน launch
    if (await canLaunch(url.toString())) {  // ตรวจสอบว่า URL สามารถเปิดได้หรือไม่
      await launchUrl(url); // เปิด URL
      print('เปิด URL สำเร็จ');
    } else {
      throw 'ไม่สามารถเปิด URL ได้: $url';
    }
  }

  // ข้อมูลเมนูแรก
  final Map<String, String> menuDetails = {
    'title': 'บัวลอย',
    'image': 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTExMWFRUXGBgaGBgYGB0ZFxoYGBcXFxgbGhoYICghGBolGxoXITEhJSkrLi4uGB8zODMsNygtLisBCgoKDg0OGhAQGi0lICYtLS0tNS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0uLS0tLS0tLS0tLS0tLf/AABEIALcBEwMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAEBQMGAAECB//EAEMQAAECBAQDBQYEBQIGAgMBAAECEQADITEEEkFRBWFxBiKBkaETMlKx0fBCYsHhFCNjcvFTghUWM5KiskPSc4PCB//EABoBAAIDAQEAAAAAAAAAAAAAAAEEAAIDBQb/xAAvEQACAgEEAQMDAgYDAQAAAAAAAQIDEQQSITFBEyJRBWFxMqEUM4Gx4fFCwfCR/9oADAMBAAIRAxEAPwC3YHjKpy8ixexFcoHxbjn0h7jMGhMvugBVW2Uq7lvnHA4QiUFLTRR94b7BO1fCEWC4hOXOyt3RdJslIPoo+pPlqY9dkHCJE8Ti4IBLreytma+wI08ota+IS1PLBGYCqdum/haN4nEIEvKmp0+Ibn7pFUk8JWmbnUSqW75vxO9Aep1/aJgnMeEO8HwIJV7QOR+FJuOfPl59C/8AjaUr9mS4FFK2O3PnER44lICVKDqok6NuduRsY4l8HTMVnFPiHxfQnf8AzAaD1+kYTOFomETGrcbKOhiv8Z4+uSfZBLge/uAbAHfWvLeLBiOJCQAkjkEi4AuYExfCpWLTm/8AIUL3Y/djSIgv7dkXBVJmp9qavY6pDX5PCrjU2b7QFL5aBBSbk78zz03rCvtHjZuGZKe6okhwKZR9dtnhz2T4p7ZOZQAVUBJsR+IjeukXaK98DzhuJCUATCAphmVYEm/StBCTiPCzOmZkFlG4NmG21H8dnjntJhlKpKqlPvJ1fluBtu8ZwKcqSj+ZruapT4+ZH0ioXzwxphseMOjK1BQJN3+6mCwhGJDv42I5H6QunSUYoBQL3yKGnUa2tpB0hIwst1GwdR+I8vFgIDCv2IuL444ZISn3jalGEKcRxBRlOAUkk1cVyjMyagkm3nDGVj0YgKKhYOpJGnLfYQtWgKIAZKaAChCXMkZa81a36kCKSlhF4R3P7BmGXUkly5JLH4qhhtksfCJVSnAF7DQv3UJo4r7xNK9XaA5Su6Drl2D1TMUwY7q0psYLlqU+rAkuHrlWNXPwihNrNaMMjGBVinSSreu/+op+6oPcd5x0rFF4zg5pnrOUhGZRCtCGJ7oSHLMRQReeId5DE1JFyDXLKDB0gm+lai9GpWOxCjmArmuBlJNDoDVyr16RjZBS7KWQUlyc4LFJkKAIUQ4dtb2f3h9YZY3iqTMzSQE5QwOXvK3roKCnKFkiQhCs00pdz3T/ALhUpLg1ej8xpFpnS8JMRlQlKFigZLkl1JFQ7vlNISlDdFquSx55EpxX/Eos7vrJJqXL849b7NTAZUtXugISyQW0+UVrDdk0TZJCilE5JLHMQVahxUNpStH6vFYlKGdqUA60EOaat18v4NKotclnmTaODUX5dYKkMQ9+sV7hE90qSTW9ev0+UG4biCQVJJDEPeqQXAJFwKekNqSfJqQdqZ6F4aZLUooKwMoBqSFA+I30imTpZ9nkQyWAAGjB7nepL8zEWJ7SfxC6pCUIo4LityTtb7dpgp+mn1jy31LX2+viDwl+4pOSlIquM4TOucoHU36sw8YZ8IkKQhiGJL+At+p8YarZUMuH8I9oxsgUozmhUwfoYVhfdqEqYrl/H/ZeEcsO7LhZJBfKx3Z+TasYcYhBUC2oJF75VNpT3ritLUp1hEhASlIYCgtuOfIneOlzLCj02+JA35Hy1j1WlpdVSg3kbisAGKl+NSdTZS1aln7oDHp0GCSEMzgDK1L5UosSdVGz23gucaKI2OqdUhnex7xoQxdtnkCbbhT7/jUbAflHpqKsFiH2iNSHc3Uh70uHtGQNPkLJcE2TqfhHKMgkARx9SpoQzoLBI/EOZ9X2A87IZSChwaC6henz6c4Al8Kln+awC1C4sx3G/rFd43xSbKmBCXSka/hWdfAWa9+UMCnXYNxXDYn22cO5LIINADYctXBpeLXKxCUSQFkAgd46E/oTtGdn8QJksKWGUoe6bEbjreFfarArmDLKNA7oe5G30gJhxjkS8QwEyZNzS9boJsOXgxI6kRa+H8RTh5QCiShIFfxPbxPKK1wITJKXmvVwAfeQnatebaU6RNxNSMT3UqoLKFQTaoF2tuK7tB7DjCyixTEpxTFw591aagD9WreDsww0t7AD/uP1MV/gGFXhh3qLVUj8LCw66k3ryg9PGJWJdFCPhOvMb8j8oDRF+4DiVIxiilQZRFQa0HzA8/nAHEMKcPLJldEgXTq+pIDXu7dYfT+FiRKWoVeqibpArpoIq/DOOGbNyLFyyCL0+Lwck/KCnwD8jDstxBSv+oHSPxfIH4g2sG9oZYmkJSWUqpVoRsW387QXjMKlEs+zAB00SpR32rrCTszImCcVrBygnMk6qO21CLUt4Ton2G/ZzAqkVUCCaZdG36wwx2Il4gmXRQSajUKt+pHnBmLmBUvumpsRcQgwfC1SVe1JBqySLkqOV28fukUbwWS8I7m4ASXQkkmhJ/2rIScuzO9qwv7QcRVISCkUJUx2ylLMPd0Ds9ucE4rF90vUmt0muQOdBrzPmIqs/Ee1M0KJCQFqF2uVP+js1Y52rlL03tfIw4NQeDiR2lKQpLk5nqrvVNP1NOcSf82zPgQfBjqSzWqSfGKzipRST9BA4maPHHr349k3j8sTTa8ls/5kWS5Zjofd0uxejDWIRiJ0wKyoVz9mk5P/ABDWa8VpKHUwJ51Mel9isFOkIPdKklVSfzBIYhRqCwi8KZWy2SmyKLl2xJw/siuchZX3Vh8iSPeYPd6Gra2hpwXs4pWWbNCkISEezSXBUU5rglwG0o7xdpGFQmgGWtGLs+kRca4cqdKMqzlLnXuqCqc6GOrTpIV4ab4XXhl1Xt6F8nBywFM4VoG/U1gXFSwvFJSgd0MO7owJJJ0c08YHnSlSlpSVFrJAJDtpXZIJ8DtDDCykUU4SquWjB+o3GvONZPPBqkRTOzgSrNIUtLl1ozOFGzupynRw7FozinB0zEKRNQHYgKaopdJ2tSHE/EKSkKJdIT7wer2AAuY6URMQKCodKhZtjE9vWAOHB5VP4RLw85CUqUolCyrM3IPTetOXKCQhg6S2raeWnhBvaTAzETTMKe62UEWuTfy9YGIHdFnHpp98o8prsq58CMl7mb9uRceUP+zWNzKMsWKSdLgFIv8A3fKKpiMYBMylJDanXmOXOLb2SqFsLFFd3VXrQesW+nVv+Jg+v9M3qzuLHSpDOc2orWYdRfr9X4xFC/PlVvaHa9qc+r9YYHV9N9kO79TenrEq0P0at/y79Tf6x68bF6FBlVpmy6kNnSgu1Qe6rdtY5LkAEFymrkmuQ70VVfUjmIknSix0LOD3nFFGtizq9DGJkAKd/l8WoJb8CdrHwgSZEgGtLnVtdjaNQBNWUnKFAABIbu/CNw8ZByTAo7R8XVhQAlwtRdjVLWJ/Sn6RxwLGSsUCFDuj3kKq5vTf59KQrRxdGOPsyO8alKrADUHYb3hhh8KmQnJKDAfiNVObsTb5wbtRGvspTp5WPjoY8YSUIPslJBVQFSwnKNTXlZt+UBcExakkJmzZKkizTUlfIVNfnCfHSiXNzuaxX8YggwotXKTHXooL5PTO0qEzJTAlK1CihcDWKdwLh02RMKlBkCwd0qIsR0A616wm4ZxybJLJU6dUKqg+GnUMYvvD+LSp8glKWKQAZfwk2L/Dz8IahcpPDF7NPt5QfOxkucgynct30v3gL/Z26wq4fwEylma7pHuNcHc/L6QrwfBJonBQUSl8xmfiDnXYncU+UWtfGUpZCjlUfd0DbnaNk8irXyD4rtEkq9ioturR9AdiKVt5RrC8DQhJmpASshyD7ratsfppEI7OBa/aCwL5NFG9H+UbmcQUl0GqOd3cGn5R9s1aWWxrW6bwi9VU7ZYisivAcVXMxBQR/LD90hsgDua2PLwi0YjiclKQACprNT538oqeK4mATqTffl9mFGK4lMVRP1Mc+Wsss4rWF8s6UNBXX/Nll/CLOcYAszM6sx50bQNt1jJ3aUKotaaWsPTwEU3+AnLqX/3GJU9nlaq8hA9G6X6pst6lEP0xRYv+YpBV3ig8yAT5+A8hEkjiGFFUpljoW0I0LamKtM7PK3MBT+DLFniPTS8SZP4it9xRcuJ8Kw+I7yVGUTsApJ5tRvCK3xDsriZaSUATkXeXUtzSe8PIiFSJs6UXCj+kNuF9rFy6LBZ7iFnppwecZ/HH+DOVOms69rFU/AzXKihQBbRqsDbS8ejcEmr9jLzTFLUUipJszh3rRwK1gIYrDYwd/wB7SYmixY1f3ra7XEbw0qZhmSshco91E1IpUksuvdU+/rBXPK/qVjpPSeXyXjhE3M+Y1DdYKw/eJ5E+TlorOBx4NBqHB084dIm/yy1FBN+enrDdVykl9jGyrDEHa9E2XlxCFA+zJKpZHvBXdNRs+2sQ4XFGdJE1iMwBANwC8NOO4oCWXIBLht92+9Yq3DOOzAtUlchbJpnQHSUj3XB5ag12gS9zwVj7ex/g5BKRXWnnzh/gE9zK1nA8fswqw0xLh1O1gObi3V/WHmGTRxt6xemKTK2Mr3a3GIRh5sp/5hALC6WILuLPbxjzCbOWogkkkUrcAf5Meldq+Ed2dNIqADmFzRgln/tDnlHmU3EkqIyDzr5xzNfXa7G2uMcfgStzu5H2GR7VIzFyIuXZuSJcsczy0LAVOwP3bz7CLWBdqesN8PxiaABmoLUte3Op845ukujp7d8lleMeA1SSZ6EivNyk6f0+f385ZRoDow2/JsbdPpCLhOInAPML2ZNlBlIHifo0O5U0EBq233HKnj/j1NVnqQUsNZ+exwixErMGo+hpsmoH0rXpECyzktbcbTDcD7+Zix18X2TenI389uJqLirt+atF7GNSEKpTl3O11C1LeEZBSSasNTpzP5oyJgmSn9muzyZKCpu8u76JFkjlr5bQyn4aHKJIAAGgA8oFxEuOfastyZ0KnhKKK1jJG0VziGFi6YqTCTGSLwrymNLDRQsXJIMHcDx5lTAvSyhuk3H3qBB+PwcLEyCDDcJpowlHDPXMFjpUuWnMoVAZXxlQp4kNSEXFOBrnTCtBYXUNAn8u3SAJXDJs/DySjvMkoydCQ48APKG2HmqRLEjM6U+8rUn4f7R+kOu5KvdI5qoc7HBGzxAiX7NJIlgMPiIaz7fOEWJmlXLnBc05jryr4Qy4dwl+8uuwjnKEtRPdL/COq5Q08Nsf8sR4ThCl3DJ9TDeVwtKBQDrDeakIFoHEwks0PxjGHHk5dl8pCoIdRagGsHYWSDSOhhiCxFHeGOEQLRZZ7ZhnkCOCeBp3DuUWMyWiNcqDgtkpeN4QDpFZ4jwlnYR6fOw8Kcdw8ERVoupnmMsqlqcHKd9ItvZ7tLX2c0DvUINUKB0IMBcY4Uz0ivkFJY2+UYWVKXPkbquceH0ehYnDfw6FTsOkKlKLqBfNLNbke8l2APnzhT2iUEnKhKVOwLkterEVV3daQD2V4+UqCF1BpWygdD4Qz4rwkIIVL/6SyMtyUnvFSS2z0+sL8557NnFd+BMvHrKsy1FRdqnQA0DilXpDrD4hS0AhgHrQEnvKevif8xXcdIIN+Q65VfvaGHZJas0xNxQ1NQXNh4hz03iTcnHEXgz2R8lz4ahk5lMOesPcPMG/6D/MIuHSSC5r3TlB52bxaFvD5cwZs1netS7kO73ZvKKwvlBL2/8AkLTgnLsu06QmYkpVVKgxjyTtfwL+GngEulfeSd9wRuI9QwJJ8Ipf/wDqqUn2RCRm7xKhdgwAPK/rDGpxZQ2J3RWBTw7BpUwe9OdaRZuHYCTLAWlIcgkKckgFExQYtRg1RsPGl8BxobLZQ+W8WjD8RUzGtCHc0cM7A1a+96xwNDqKqLXG5fh/BShxjwx2tfeoaFQu/wDqJcGjHavKCZLsHH4RofgfU0q/lyhfkdf/AOx7Ef8AyKy1Jr7ouNfKeSe6A/4dABZCBZ3BY6b9H9QmOjBS6kGlKUH9TnGLSDs1dmqJg1PPl82HMwZi+xp3f636fd4nKgM9dDr/AHUtTxe3ncqFS2bQ1O2pMZESJTgVP/cRalo3BAdIS8QT5ULOynE/ayEhR76AEL3JAYK8QH6vDtYeF3HKwMKTTyJcVLhPipYiyYmXCifJhC6LQ/VJMrWJw94XrwcWKdJqfvWBhKTmGdQSlw5NgPv5iMq5NvCNrEkssa8KxPsMOlIHfUO6dnNT4X6tC/GFmT678/vnBa5wmzVKSMqU91OzD3ifvQQLJlGYv7t/iGL5bmoLpcGWnhtTm+3yT8LwznMbaQ9kYlJLCrbQDOmJlpa1IWdnZ5KySaOfnDbX8PCKx2cu+31ZNllxeGKgCIjkSQLkPDGbOSE+FeohLhMVmVmpeNG4p5FjfFJ2QFmjXDp6QHFd4hx6h7XK9MoP/dWCsNgEpyZSahyDWtv0MayolJbvBXes4DJmOFtdf3iUQv8A4BftCRYw2lyWEczTW6md01ZHEVwvuO2QrjBbXyDrRA8yTDIyY4VJjoi+Ct8QwIINIo/GuG5SaR6lPkRX+L8PCgYrJfBpB4PNJBY5fI7GPQOyvEkzZZkzSK0L6HRQ+94pfFcHlJiXguMKJiVOz0PWFrY8bl2hyqX/AAfktvGOHMohmqd9M3O3pCrBFcpWZJ94soEEhiU+NK7fOLopInS0q19002SpvSnhCrEYAW5q0/f7+c2qS3Iq24vaxzhiCgAqpoQbcxHOHwTrfM4DnwhMMMQoKTQgliw2WK1aGJnTAXCrGzBrrH6D05wfTT8GT+UO8TjESZKlkEszDUlwG/ePMO13F1LWFFgVPTZOg++cWWfLzOpTkvtuZf7coqXGOHFZzl+XRlEi+4jK+M5Yw+F4FrKZSFMhSnSsHK5oejPTasPMNxQiiw3PSAZkse1lykg5E5Q5DOcxzk1YByrybnFq4nw6WEyzoU+YYnz+scuzRK3P2E5cdnWF7QJSkOnMQQQQzsM3J3dRP+S9nw4ZgwagcMDRMvYNt5Dk1CweCMshQZUsqAfYnRW0ejYRb61o9dhLd9LaGHvpsrfdCb4WMfuNVSbRAtRfXzPwvt+b70mRO97di19StqtTSJFIto3XUIu/J7v84GxUvunQgB2fkTR7VVvY836psHykUNTdW/xHaMgWXJva6tB8R5xkQB5p2Z44fa55YOWy0HUbnxqD+8elYbGpWkKSXB+67R48UHBJJcE76KOgb73h32V40pcsqSSCCQet/wBRGWp9q3//AEY0/ve1nokxbwFiaQkPHJgux9PlFd4p21WpXspCQpe9wOm8JJu3iKHGlVy2WLieNRKGZagNtydgNTFX4pKmT8qwWSDVBpR/e5loQ8S4fiFfz5qjM3FS3h8PTrFr4XNPsMi6qVlD6gAvlO5YX/yWa9OqYucu8MWsvd0lBdZHGCkNLLWYDxN/OsNOH4UpQVam36/pEHDpRygaEv5NFiEoBIHKFdJDdJN/kb1dm2DivJUMDjTnUT7yVP8AfJog4agoBoWct0ekOJ/D0GYVB+bQccMkpYaCO1fKFsFHycFLEmQYPMpJFSfSBEYRcolwcpPlEWadLUyQ4hxLxalIOZLMIS27uGmsF8c4FM7CTFLC015HbSH/AAmSpgVU2hbweeAXVXf9osKCK8oy0H1aOpjKEeMM2u0nptNhKURsqgdE6NSZrqPKOgZpBhIArGBQeOCoEeMRZwKQApZJ1SAYWcTwNHEMUHYx2sOGMBoHR5X2jwNy0VBmJHj4iPUO0GFFRHm3EUZV9DGDXOBmL8noPYvHFcsAmpT6j/DeMPZkoUtQ8tSNvA+XKKR2DxDU+FVI9BWirdN90RjRxmPwzbUdqXyhWcOMttK2bvJO1NenpHU1IerV5izTjr1HLweD5UsU/wBrX2R+/wBvAs2QQAXNATrfJ03f7tvgXyBz5e/xAfhdvaAeFtPmICnYJ0sWfL+WhKR/9rcxyh1Nl1F6r5vRUw7VtfkPHUqUCyX1G9WMrlt0v1MTBMlaVwod+gJZTHu1ze2VTzHm/Wb/AISSMhUohJsSWHelp2ozL8/GG6AwU71S34j/APFWwBNSdP1hilIzWq7a/HpW1dPpFdkX2gPnsr8nCFKSQCxT3hloU5CpNGFQopqK03eGODxBSsAg1o5B1VLSzvSxuNIImAZRSySNA38sFrsLDbrqe0SklVrKOzg+0B066fN4tGKXQEkvAU3uto3kyNHfa3+YyoEHpyq6WFr3FuXKJ5YFn2a39PYQIA4V03PwDYddP2uVCJCS1RVybjUk7RqJJbga3Ns255xkEh41jVjFkhKTlDunVJP4v38N3Y9muG+xSpN3U76mgvz+kHcZycPTklpBmGrmrjdXLYfZK4QkqSlRDFQCiNQVd70eMda8V48s20XM8/BBieGmd/LBYGqt22iv8f4P/ChpQLfiULp5U/8AbS0PO02OXISFI95dAofgGnRR0jns9jhPDzgwFATZZ8dN+dOmmmrUYJeSmptc5sF7M4pRSFzGB/A/4m1O3W2tLwXMkI9t3RlNcwHug0tsbP8ApEfaLDkUkABZFhYCzh6PoAaa9V3ZSRNRM/mBgaAK96nWuX5wdV/KkvsDTPFsX9z0Lhciiej+phtjQWptAvDJYCQ236wbjTryhLSRwN6qW5lfk4rKWNIYSF5i4tAE1aC5UphWwcx3wXiCctRe8OSg6UpPycxtNvBrFz2VlHnGJQSKEkxrjyUt7VKqgFxyED8KxIbMqr6fesdGhqUOBezKYR/AKSp0sx05w4wMopTU1MK588lKPWGHDprgx5SNenp+puEYtSaz3x9+DsOc56dNsjxs4prHfD8akIJJq9RqxjWLQFUhPjsKphsI7cnKPJjVtl7ZFiTiAQWtpHcqE/DcTofW8OJZi8XuWTScVHgIRSJ0KgcGOZs4JEWFJCfjyQ5jzHtFLZRi7Y7iBXOKNLxVO2kjIUnNmChTcdfIxp/DZjuBG7EtpL2Hmd9Y3aPUMrkeGh5c/t48o7CBypXT6x6uEuz7DQaDrzjmV/zZf0Ohd/Lj/U4lpZqbdbS9z9t58zEunkU7fl68/SJk/R7fk+6xGlIKRZsv5bEAb2+9oYFSFSVP4kih3mUv5P8A4jJqBzFWNO9LF3p48o7VYGgIfQH/AFPL5eEZMZ+bvYfGB99OsQgvX3gQ591iAKD+W41pf0tvPKnOojYpD92rTGD72N2qTraCWUhAtYbC8tFmcPa3LlBmTvk2NHqbe0Nbc/TxIRZnSVdy101FiP5b7OLttE0mWxJc+8rX8x0avutTaBkzDkzPTLufgPiPnW2xj1/3E6mmYg6372v0iyKMyoL1533QDpbrzgfEhg5BsdCSO515dPVySagNzP8A4HenraIMUoEFxoWfL8J58oJDEqXVrOWoNz+aMjETb0fvK2+IxkAJVOKYWXipWdRdF81lZtuWx/xE+HIRLVMIYJST5RCqUQsSwGSkWFjoP1vDHG4YKk5DTPQ9NR1Z4x1PvtjA20y2VORVeD44YpJTMH94NlPon6aRrjkn2ctpScxIZKP21AGlzz0M4pw4YeU8tLpSKIuol3vruTy1ivcFxc2ZMPtQVD8arZBomtCaW0D1vD/XAiQcGx011ZznQn31KoSrUA7Dn+0ScN40ZuNlqtL91I6g1PlSOO0PFBilCTJS0pJAK2Pevqa5aHWp8HWyZHsilTjukG+oQVajmIwt5i4jFS2tM9v4ae6IJ4gQEAm0Kuz2LC5YI1AMG8dJ9iSASxBps9fSOYrHCLkvj+w3KG6aQvRwhMwO5rYerQFNwaZagkAn6Q1wOOSBQggt6fIxDxaUVKC0Bwb/AFgfRPqT1i9O7lrvgW1dPp5cUblyUqT1iHC8PQFECvImgjrDSikOddNohwOKyrIVSsdi6fpP29CcVuXI1EoPkUluUFolBIYBo4m4hC2NMw15RIJgIpGSUXLf5+fJdSeMAWJBekbyEV9I5xeICSN9BBstByBR8ekXlYm9oFwcJw8shwGMQpTlsTBCkwKpBzPANFNhUmbuYXY/E1yi5gpUV3i0hZVmQbRWcmo8FWxN2glzMPNRPSXAoSK1INCIq3aHiS56sxDCviYt+KlrV74s8U/i6e/lEaxvkoYLV17pZLD2Cw5CX3V6Wj1M82tytTeKd2RwISlA0SK9f8xblKYdBv8AtS0c/TPc5T+X/Yf1XG2PwjgXvt//ABGSrAbAfLp0+7Ys9aHnuHtaxtHCZmlXanvMaI+un1hkUIZpYhmsaU+FbtR2r0jSlOzN7zeUwWYffzzEhxTTNu9EqYho17QuL+9z/wBQDx8W8miBB0NlIOoAdyz+z3A5bQctHW4rW2c2/blygRBJf+2tFP7iub+B0gwgFRbUbfmVzr4N60KAweXKJDaMRYs+UChfmdjTq+5ZLktZ3o1CVGteQvEyU0a3uuKVYS/v7EaSdKWoXGoV9R/iCAxCkitCQaW0Z28UabcoiMvm1QKf7BRgxudr8olWWNDrZ9vaHQdPLeMVpTUDXQ8zdhrv0iEAV4laSwBOr9/8Xe25xuBsRiFpLZHomrD4QdVvGQMhwIezc9U4CcoMV95tgKADkwfxhh2nxiZKUlVQlLkXJOjR3wLDBISkBgAEgbAC3kISdosWpeOEoB0hIqA5SakqPJsvU2hSiW+5yGrlsqUQLh/HJmIWAsUqcwrkQ1M3xctSatA/H8WicoSMPRAP8xQBdRcAjR+Zr5Cp3aBaB/Iw4GY1mLTQvSmgKy99OtlsiQmXQAFqigZsyi1TW1w0PTnjgTrr8sElSQkJyiwJdtcpG9+8KXvtEi0glqtmI11UlPMmiTQtfR44xqmIZIrQW3ljqbnZtNIHlLYE8tlCyVmoBYVPO0ZGxcOxPEW7juxcVcMrvAeAI9I9BkkEbgx4thMWZcwKQXyk0zCrezQRUWqfsx6rwHHpmIDGhDj6QrKO2X5Nf1Q/BHxjhwR3kAcuUZw+alUu9W13Ah2pAUGNjCv/AIWEk7baQ9ppQjl47FblKaxk4UoM5iGVgxMNaDdo64jJVQiOMNi2oQfKM7bm54wZbMLIPMWEKCbD0cQbMnHKwtEc6Uld6E2grDYJmcu0V2Scs+CuMiTj0uYyVJuIb8G4k8sA1O31gudJBFY4w8lItEenfqepF+MF8rGAmOFiOJ88JvAhxrqyphhrCyyuQbHz1BwBCb+OIcKTWLCVPQhjC3GJA2jGdblhph7E/EMScpUq53vFa4RhDNnZjYF/pB3GJ5mKyJqIsHZ/hoQn1JhXU3YWyPZ09LTtW6RYuB4bLLJNCbX2Oo6ekNJoof3/ADfe0aw1ma1NbB/rf9o7mBv8HfrDFVahBRFbbN83IGmD3nHxaE/Hz+URo95udOmZIe/LRrx3iQwP+5wya91W/L5RDMSc2znYVZan9G+yYuUMmJOUUNEl3BvlTsb9K/rqaixZu9SmuZSi7nYajXnTaBRKr92tBXuo+n2weRSAbswL6BqzH++vOCQFwye6kkCw0s6Evc/W/nOSnMTTQ/h+NR8db821gfDhwwamUXTr7JrDnpX0icLGV3sHJehDTDoLxCMmPvPRsw2oO5y5PG5CbM9hqdkbDZ/Xm3aaBi9y17AUta3SOEJYWoAGpyS2t6QQESh72YOMt2/IxqTz+6xC5L/3KpQV/m0qeVjEpSAk0DNsnRKOe4F+Ucgd56XOouDO2H19KwgDPWHqlDgAfgNgBtGRPPQc1yLFqm4eNQCxHwyWwfYE/SFvEUob+Wllqy55gF3CyEv+IhvB+rOFDJLL0sIC9hlSQNAlgyQe7KAZ3P7WtUqaZbRrUPcVVeCCQANMr+7tJqdj58tIGxIYKdgCH/CHJEwvYued9hD3FIsKAgs7jRaE7ctH6wry5gQT3jQ1Le6LMK+8aXrcRuYirFI74Fa8h8Q0Nfwm8KpYIZxptQUFHSW10eHGLlspzZwANPemGx5NQk+kLwiqRSgZ6E1TKFxWgOg16QUAllLc3/ENSze1Ufxckwz7LcX9ioIJ7pCTcHKcqVE0smsKEFg5JeqjUigE46ufNrdIlmJoa1ZThxcGSj3SOu/rQSipLDDGTi8nr/D8YFjnDCihHlnA+OGUQlROR6E3DqUwpcMIv2B4ilYcH6ERhGbg8P8A2XnWpLMQ2bLa8A4uQ4pDFE8WMaXLBsYZjYmLyrZWJCyCQR47Q5wmNSoMP8+MDcWlkJNNIV8E4gEMCKjex+kcv6jqbtPs9Ppvl4zhG+n08ZRk32McfjiZaixDFvvnURFwwEBLmp+z84kVKzgpAIQa19P1jvDywmOn9L1crNMnYuX9sCuqpSs9oD2gnGg0hZIK3JSbfKH2NyqFawpm4hCHb0hu26v09sykNPOUsomkziO8owl4pxAqonz+kbxU9czfp9YkweCAqq/oI5N+rSW2J1KNHjmQPwvhlXPl9YaDFd4S0h0jNmoaqyq2qQLfYjr2iQO6RXVwPxITqHPvaVgfCqJmKdi5JAoTXMzkXDNWK0VSzvn2XvuTWyPRd8Mkknzsdc3Ppb6N1MW/IuNBuNH56fSOcGKetutbt5RHiVMbahrbp/8Ar6R0PBzfJqYXSbCh+GvdV4H9ohmE5iRuBdOijd/1rfnEZn3L0Ny/9N6U3UPu25k3vFjRw9WrmXuOVvpUZLYO5bBIP5fy/An6Wt6RKVAgs2tinQzBp4+vOIE0SkaZWuKd1PLV/XnEiny33Lv/APkaw6QUBkIUyr+8R4sqWnbkYlkLdNSXYWJ2WWsPlpEaCSrodc1vaUvQlhrHUuWSnqA/vfCPiqLn7eIQLUl+fvb7r5/KnpEa6Of0ABqo6ltvt45mkVp8W39Q2J+3EcrUwNaUeqWcEg+NLH6wQEc4sCwFXc0FMqH0+e3SJSA1z7yrFizzNh18ukRGY97EMa6ZE6M+vP6bSXOtyp6nWafEfe0QhzMZ6s9N9qRkRYhIKico01O3WMiBF2OI/loLl38whSvkknwg+a1bfir3dMqRz5OfGEs+cF4xEs/gQpbN8REoGoZhmVffWHpWMz6U1GqyTb+31hXTrEcjN792BPjZZBfmbE2MwszBz4Qrky8wJF7EGotLHQ25X6xZlpcAXokl32UvTwr6QqxOCyh+nyRSuj70jZoxyVvEyDnfdqd4VedTwpppu0L1WoPwvfUIw5NSAdfvSw4yQQqgJJYBgXFZtaVb9W8F0yV3QbADm1sOADpy8TziEEk2VQkVZKuYomdonWnM1asFYdWcs/4hqLe3STo1k6RPjJGYhOgpcVJViEm4/aulXCkzsiwX2Job5pR576NBIFlOVD1cJFgn/QWv8J1J8elYPwOKmS1dygeqTb3pSBb3aqUX84FmDNLcVpbu6YZNDte/6MIYS8M6gwqlRejDuz5ZuP7T19BWUVJYZaMnF5Q8wXaNJoaGndVeopDaXxBJFFEfKKKmUMrEsSig2Pspis1Xq5O2m0FIlqB7qiO9lbMDebkBy3YByw25GFbKJr9Lz+RiF0H+pFym4xdWZXSFy5gdzJY/2kQh/i5qRmoWAJY1bLmcjpBkvi8wGqVCvq5GnMQpONyfTX45GounHa/sNxjyzBI9YgXiVHXyEBjiaj3mUQQC7WBAI8GI84mTNmlVEGtKkbkfMHygqy7r3B21Lng5mhWr+MQKkB6wYcNMUHcJsDR6EpvUNRXoY6ThBlOYOcpuFAik3TT3U+vKLKm6f2/JV31R+4J3aJoH5gWIs/UeYiPiUssUgGgexNR7WhYsfdTS9Y6x8sBRBoBTlVUoPWmm/SITNzNUKpR6hvZuzu7Mo6PdoZq00a+XyxWzUynx0gyXKoE1cMGdTnLNA2c0T6bQNhZYeje6HbKzFAPQ3+3DspagcrMan4qh5qtL2TX50EB4VQCr17ruX/DLBDkNYdX8IZwLplzwlieZ0AspX28czzUV1s50Kmte3pHWAsa0NRYak6XvHGKDv47/AJ9vulNI08GXkCUogdd820tO3M/bxwtZDn5E2zTC1jsKcoIylQ2Lnf4kelNflGig5VUuG/F/UPUXgFiSSXSATVhqWtL5c/WOmdIHK9a6+dT9vEcm4fbY7ywP8iOUq7ocH3TpyRua/t5kBkpDAGtSbg/FMVqenO0ZIoa6nlvLSNX009IkDEO4FFaClJla6V5xmUUZr8t1PpuPTq8AR4igDXNvdDk5U/hB+PT6RFNW5UXpRiCb/wAwsaNoKfSJgDlAc/hFydZXJt/XnA65ZIUKhv7tUnc27xvtBITpJJA6/F/TH1sf1jhNmNHe9qvub98C142WBsNasLuqt/yizaeEEw5ctadRoZTG3z33qIQLlJcPlFzrzO1IyJpCHSHJ1sotflGRbBXJQuz81UziM9f4U5UPqCFD6Ki0rJFKggVsGGVZ0DM+0ZGQtXxBDNvM2aQvc6Hc2lj7e8bmJB8yX6KQNekZGRojMX8RwrKFrh6CoBmGpfdj4c4STsNkZOjPSjZf4caHnp/nIyAEGnJY3eqQzlvfn8t+dW5CE+JwbJDihZmYXTI2Z6g3OnSMjILIMOEpZCQsByKgbqEpjalB96MpBKSTuoqqBqrEr8PdHkNzGRkQBoYT3gKMCHBL0ky5Y8amo+sFscxJBcLa9GE1fi4p6c4yMiBNewPsiNAk1Yf6KWP/ALeXSOsfLbMQWZXqJswPT+17aeW4yIiGsEuqRVzo71H8Ok30+9aMpKC7nZtP65FWu5ZrRkZAIGYVIYP8YFhTvShRrWECYhQSCKDusSx/01kWL876mMjIhEDcQQCosa5spuGeaNah72DFtAYXSZCkhJdwGBVSoyyxrW4P/a40EZGRGRBMshABcAipobBM8/hLAWO4grDoBmgOaEakt/0Qz7dN4yMgMJaOHoIBBpQbbJOnj9tGYojMAdS2v9T9Pu0ajI08GXkEQqrPdVL/ANMFq/OJlzAQerHqyjvtGRkVRZolSAS2rnT8yb13EcJw9ALd0B2FWCP8V+kbjIuVAcxCXt3S7GrZSdt1j7sWMUlWrVO9wZiSedvukbjIATCBQGtQ190tc10vt0jkSvRnpyRXVrc4yMggIpoIB7rBiKZQze0fSu0DLxHfSl6d5qmjGVSg5ne8ZGQCB2Dn9wMdVf8Asd4yMjIsgM//2Q==',
    'description': 'บัวลอย\n\n ทำแป้ง: ผสมแป้งข้าวเหนียวกับน้ำ (เติมสีจากธรรมชาติได้) ปั้นเป็นลูกกลมเล็ก \n ต้ม: ต้มในน้ำเดือดจนลอยขึ้น ตักใส่น้ำเย็น. \nทำน้ำกะทิ: ต้มกะทิใส่น้ำตาล เกลือ และใบเตย.จัดเสิร์ฟ: ใส่บัวลอยในน้ำกะทิ ',
    'price': '45 บาท',
  };
void _incrementLike() {
    setState(() {
      likeCount++;
    });
  }

  void _incrementDislike() {
    setState(() {
      dislikeCount++;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ), // AppBar
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            // ปุ่มไปยังหน้าอื่น
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/page6');  
              },
              child: Text('ไปหน้าที่หก'),
            ),
            SizedBox(height: 20),
            
            // แสดงรายละเอียดของเมนู
            Text(
              'รายละเอียดเมนู: ${menuDetails['title']}',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Image.network(
              menuDetails['image']!,
              width: 200,
              height: 200,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 10),
            Text(
              'คำอธิบาย: ${menuDetails['description']}',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 10),
            Text(
              'ราคา: ${menuDetails['price']}',
              style: TextStyle(fontSize: 18, color: Colors.green),
            ),
            SizedBox(height: 20),
             Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    IconButton(
                      icon: Icon(Icons.thumb_up),
                      onPressed: _incrementLike,
                    ),
                    Text('ถูกใจ: $likeCount'),
                  ],
                ),
                SizedBox(width: 30),
                Column(
                  children: [
                    IconButton(
                      icon: Icon(Icons.thumb_down),
                      onPressed: _incrementDislike,
                    ),
                    Text('ไม่ถูกใจ: $dislikeCount'),
                  ],
                ),
              ],
            ),
            // ปุ่มเปิด YouTube
            ElevatedButton(
              onPressed: _launchYouTube,  // เมื่อกดปุ่มจะเปิด YouTube
              child: Text('เปิด YouTube'),
            ),
          ],
        ),
      ),
    );
  }
}

// void main() {
//   runApp(MyApp());
// }

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Page5(title: 'หน้าที่5'),
    );
  }
}
