import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class Page6 extends StatefulWidget {
  Page6({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _Page6State createState() => _Page6State();
}

class _Page6State extends State<Page6> {
  int likeCount = 0;
  int dislikeCount = 0;
  // ฟังก์ชันสำหรับเปิด URL
  void _launchYouTube() async {
    final Uri url = Uri.parse('https://youtu.be/gLQJ7pWnzts?si=J_2zN85QoPPxUVTK'); // ใส่ลิงก์ YouTube

    // ใช้ launchUrl แทน launch
    if (await canLaunch(url.toString())) {  // ตรวจสอบว่า URL สามารถเปิดได้หรือไม่
      await launchUrl(url); // เปิด URL
      print('เปิด URL สำเร็จ');
    } else {
      throw 'ไม่สามารถเปิด URL ได้: $url';
    }
  }

  // ข้อมูลเมนูแรก
  final Map<String, String> menuDetails = {
    'title': 'ไข่นกกระทา',
    'image': 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTExMWFhUXGBcYGBgXFxgXFxUYFRUWFxUaGBcaHSggGBolHRUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGi0lHyYtLSstNS0tLy0vLS8vLS0tKy0tLS0tLS0tLS8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAKMBNgMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAEBQMGAAECBwj/xABAEAACAQIEAwYDBQcDAgcAAAABAgMAEQQFEiExQVEGEyJhcYEykaEjscHR8AcUQlJicuEVQ/EzghY0U2OSorL/xAAaAQACAwEBAAAAAAAAAAAAAAACAwEEBQAG/8QAMBEAAgIBBAECBAUDBQAAAAAAAAECAxEEEiExQSJREzJhgSNCkaGxcdHwBRTB4fH/2gAMAwEAAhEDEQA/APZK2KytioJNVlbtWWrjjAK6rVbrjjDUbLXQrdq44zVWIa40m9SE2rjjdatWaq2K4g0K6tXOoDiaGxOZxpxYV2ScBdq41jrSLEZ+W2jUnz4Cq1i81eJi8r7HlfhQSsx0HGvPZesTmMaDdhSbFdph/tqW8+XzqhY7tPEw8N3fkNyTXKfvcq3FkH1oVNyQTr2vDLTi8fiZEeS+mNASzXAAtuRckXPkN6qk+Y94fAC56nem3aTJDPOsQctHEESNAfD8K6m6FmYm5/KrFhMlwuFAiZXml0hisamyg7C5Fgt7G2phex6GwSiu2w4zx0jzopigSV2prl+VTkapvGOlXWXK4Z0cxRPDLGRdXINwRcX0uykEXtY3uN6LxM8OHvGYWkCIrSv4bIrFhezG5tpYkDgBzO1C4xxub4CVr6RUFwS3AEdj5VaMphmW21h505XLFUkqPxt5USIyOVWIQx2KlJPoxBtvWFgKxkbkPrUKK7cV0+tqJv2FEGKmFwBzotBYVo4bmRXGIduSk+gNVqKHCUpS7YziWEjJJLVBJJqHpQz4wXsdj57VEZwL71bHxqaJSxNCY5TpNTYeYW3rNWs25UFkcxaQucdsilZlh5GUhQaT5DBMJRqUjfjXqBCLtYUBipk5AVkLQThBxTTyXqf9RcI7cDLCAhRRyYgc6X5fLqFEvh60NLQqoYRmzluZucRvsbUkxWTqGJ4ip8Zh2G4NLkzFkNm4VaayPrqclwIM47IK7akbSTxsKyrnLKukG/GsodsRDck8Dyt1lYK4A1W63WVxxqsrQroVJBgFdWrlnA4m1DT5lGnFqjKRIXatNbnSWXO2O0an1NA4rEORd5Ao6UO8naPZsfGouTS6XOiR4F96p2K7Sww3W+s/OksvafETkJAmm/M0pzl0NjBYyXjEyPIfHJoXoDSrG5zhYtge8foPEaSDs9PKQZ52I/lXwj6U2wmTxxCygV25HbWBYnOcXJ/0oginm3H5CgpMpd95mLnpwFWrULAUXhsrZt3OkdOf+KCdkYrlhRiytZTlESnVotanglVRTqLAxKOF/U102TwSciD5H8KXC2EnhBNSS5KxBiNDB143BHsb1YsYUkEeKjLpqljWRQxAO+gXHPcqPMWpXnmAMJFwCp4EfcehqfBzBsBMeUUiSnyETRyn/wDBpso5g0/YDPqWDqPM3hlmVSkevEW72UMyAjD4QRxgBl8Td4bDUN0bYk0HnKSscVJJKLxQoWSNQqTIneSaZQxci41r4GU2PoATmsvdYhC6numcSFhuFMcMsbFxxAGqE6rWFiSRpFCNCtsUqSxyyYpWWNUbUzajLpZ7XsqrKiFuAWJTztVB2ScYxT4wv1yPSS5G+DxkplSQyN4sVPCU20d2jzogAtsfs0a/EknkbUqGMmWGKZZZS80AkkBctqYthyREr3WNyJHVQLC7C/AEMMbGYy8bd6pEpmikjieW+o6zsqMNWpnXSd7WNCS4Z3WJIoJl7hVuroRZI5IWAVz4ZHIiGysfO1OcrN2Oe3/HACUeyWVYxOsJE5LW+0/eZrqzLK4B8dxtC/A9NrV1h8VLK/dSSyFUR7sj90SY8RLGGlZNLAsqLbTYXSW4HhqRoJC3f91JoGID20nWUGDeHV3fxW1va1r7XtagHy+cJOhik14mORY7LcKZMRi3AkYXEZVZ0Jvtxtci1Ao2qPGeUvfvJOYsIy3M7RrPGZwO8iR4ppDLqWYxWILMxB0zIw0sN9iK3iM9ZY4p5sW0KygMoSJWhQMAyh5DG1tmA1FlDEGwHAZmiy3lSOJ2m7/vlBRu7IiCPGe82U/9NBbUDfbbiBcBio4pLHGx90Qb4Z49EoLclQsHXe/2ei3IAV05WQWMvt/5klKL5wNcPn8ziyRRyOqF2PijEq95IkXdgg21925uSQNragb1I+awFmCYZ3cAmRLKrR2C2FmYAkhrjTcGx34XrsURJ0SSLE8bHuIZGEJbDyMJApdR3osr92NJspiFwbG5OXzKUxEsAKM/dQKWdpbyk6VfvHuZF1ToATxVF2A2pr1E1nD9lyuSNi8DyKXDykIneRM4JTvI5ED2F7DWBvYE6dmsCbbGo5MtlKkwzRyEcQNt+l7kX9bUtbCd9CkGuQCaaUK+su6RIZWVw7XJuqDj/wCpbhWncRp3p7oPDOI1kiTug0UbqMQNJZrKFScFbkfZ32NrMjqpcOS84IUcPKf68mpzOiapInA62uPe3D3pPHjtT8as0GNxCd0HxKd5IoLJKgYBzp2jCFCFuSviJ/h53vvF4fDzfazlYJY5O7cggB20h1AJHiurKw2uNxypsNRXZ0RL6r9AOUyKFKD1qc50VsGFjXGbYWV4mbAzRzaeKXGq4HAEG2ryNvWvI8xzrESP4msVuLDYg8DcdaduwKjHk9Xl7RpwaoZJ45OBrxrEY2e+7E1b+xGcHVocXPKp+IaELK4x65PR8vwqEWf2vWUoxrTSNZFIA59ayoc/oUJy3Szkvlqy1akkA4kCgcRnES7Xueg3qW0hIwrTMBxNIpc3kb4FsOppXjsUbHvJbe9qBzQW1ljkzaMX3vbpQD58SfCu3U1QMR2rhh1Kjazx239agwHaGbF3WIaCefSkStnlosQpi1uLpinLtqlksvS9qUZh2pwkOwbW3QeI/SgD2Zdrd9Mznpew+QozL+yYjOyA0zKFYAF7UYmbaGEov8zbfSi8DkxmN55mb+m9h9KbHClRpC70G0UicqHcwtq8BEWQ4ZTay1wmFjU+EDbhQ64KaVgADbmeXzp5hsnQAa9/IHb/ADS7LYw5kEot8IAklsL3odMGznVZiTVkWCIcEX5CiZWUrYEqeRHKhjqIM6Vcl0KsmyvSdTjccAeXnTOY0HBmaDYtuNjfqK4mxgPDesq+9SbZahVJdmY2e3Okj540Z41LmM4pMcnmnN1Fl/mbYe3M+wqpXKUrMp4LsK4qPqLPl3aBJh3ctiD1pjBiY4SUEY0tsRtZh+OxNVXB9jnWxOIAPkl/rqFNsTk+JIUh0k08APA1h5G4PzrUhbfGL28+xVtpolJYlj3HmEWCLxRQhWItqtvp28N9zp2G3DauMVnAQHQiqeZApdgJ3a6lTcbEEWIPnfhVa7S4xu8Md7BbarcyQDx6WIqu9ZfJYi8fYmvSQlPDHQ7XuhsTqHmNxTFO1UbIQZQjW2O1weW1qoeEwJddWtEXUEu5axYi4A0qTw52t50X/oraLkktcqwRA4jIk0EOQ11O19lPLfem1W3xXDbHWabT554GuM7T4kfBiYif7D92m1IW7S5ndrYvY/8Atxbf23XajXyhLSFWf7PvVIYKCWjj1gixOxANxxFRxZegiEjLI3gRiqsqm8ksyC11JO0YIABvcm4FWHqrs+Bf+1ox2/2/sTDtdjViVBMC4t4yiljbrtY/Kum/aLjVWxhhY/zaXA9xq/EVsZYimRUJkkBlQi6jSO8MQYIy+PiDqVtieG164XJUckI7gK0iNcISTGoN1s4Xe4FiwsSNzeiWpu9gXpqPchw/7TMRbTPhY5R5Bk+dww+lPsF2pyyWRZWMsbllYxsJNAdVCq5C3Q2AG/8ASDa4Fq9/o72Uhh4rcbgi6SSb8eCx3P8AcKigwr2DMVRSAwZxceIsF4KxF9D2uALLe/C8rVv80f8AkCWiX5JL+P7l+yKHDxPGBi0k0oYoEBW4Q6SdRDHW9o1Grbgdrk0rnyucRRLNH4YSveMvj71ndRLIqLdghUzA3AI747WBNVuTEKjlJIo2K2uUJG9gePUe24qy5N2hiv8A+YkQna0xLr8ySB63FGp0T9OcYz9BMqL4erbn9/8AP0JkOufW91XxS3YFT3UC93FqU721yzyeyUDhZTpbFSTJhzqlVDKoKqZTH/1LsviHdpGAGAsnO9WieJJUVpYosRpuUYBSN7cL322F997Chp8v7xnaJktJvJBMt1LWAuLboTYX2ZTa4ANyYs0sseh56X2/9FRuWcMR4HOD3MGLkF5DL3alBYzozsoAHMMBqW9hcK23J1Ni5GusmHw7gjUYdYL6b7nxLpYnz0i/8XOg8yy8xyYefEMulHKqFuIodcTopYn4iSQuo2AuoAFySPDZZHeRRaBpZXkWzGV5QREoI38EJ06COLR2va5TvspW3OPPv9g2oz5RUf2gdnYY0ixeGBEMjaGTf7N/FyO6i6sCp4EW52C/sTlDyThhsq8b1de1qlMJBhmt3kkjTOOITUzyML+TyBQeYU0BlmqJToG/lWhzlcC93pfJZxjkRiu1xxrKq0UcpuzCxJrKPdL2FbY+4yx8+ttUsllHK9qUYztfhYvDH9o3RRq+6qy3ZyZ3viZWa5vpBIG/pVywGTwQoCsa7ClxxgKWUyrY3tJj5jpih7sHm3H5VGnZSebfETu3kDYfSrMcRdrlCByqVsWqi5uBQuXPAajxyI//AAxh4lCBdzTHLsNHD8AAplEildR3J4UJjCgGna5qH7snPhHMgaRgQ5FulMIxINzKdqCy7DXNkFyelWGPBRwjVMdTcl5D865ZaIk1HsAyyLEPIW/g5E7f80xxM8Ee7HW3QcKXYzNXfZfCvQUPBgS55k1Ep46Ebm+hzgcc0gLWCpwAHPrUszC1SYfDFEC2O1BZgxA4Ee1YuoslJuTNOiCSSF2KzErcXpYe0TLtxH686FzGfc7/ACqvyvc0ulSly2acaY46C8ZjixY3O+9+dDZR2icnTck8LcT8q3hcI08iwpxbif5RzJr0fs/2cgwieBRqO7MfiY+Z/CnuMFHDQN1sa+BfkuCLgSSKQOSsCCfMg8qds9uAonTzNCYtgPlSNuxZRTc97ApsYRzt6VNgc+ANiaSY+U3b9edVfMMYQdib0Wnts3cD3RGUeT1z99Rxa4Dff/iqR2owl5S68TYMvO42uPa3ypFl/aJxtXecZkxCSHYtcHz02/OrN8nY1jhg0UuqWUzBOVRozazMjbncFA4FvZzTVExEveMvdAvqLFQgc6yWYBwNVieV/LhVNnzAmmPZ/NyrWv6eXX0oVGUVlj5c9YyMIsxlmYEzNqQm1yQynmduDbbnjUyvLrLd+wc7FtbgkdC3EilGPgc4x1hRmL2cBRf4uJ8hcHfzp5h+yeMfchEPRn3/APqDXNN9MGUoxXOEExZNiWTSswKcdIkfTxv8Nrcd6Bx+MxEcmmVyXAIs1nBVviuCCGBsL3HIdKZQZXmGF30a156Dr+mx+lSz4qOfSzizLsevmDTYxW5RllZK1l01Fyjtkv6CpM1mAO2/iIYKVKaou68GmwWygAbbW2qYZpHIft1c3eJmKkEv3ad2b6uouf8AuNFS5rEmyi5qBsSj7uAfb8asvSy8S/Uqx18fzQ/RhEuMjmVfEpYhrIxI+2mY6mYFdIC63IfVyQHcbCY/AKIzIydyyg3jux3ZwIrhySpIEpO/CMEDeuGwkTfDdfe/0NS5fh3hYlTrj4sAFNyoJTwuCNmI342JtSZ02fmWfqv8yWa9TV+SWPo/4z0Qss2GKGNnRjs2lviksGK6edlkQEG/ivTXBdsGItOit0dRY3/qHA+1qWtm42YoRMgcKQfDqkJLSEHfXdmO219P8u6lVJ2Av5ClK2Vcvw39izKmFsPxUv6lqXtTJE9gEeN/ijbawPGzW2+RFNsC+AJDqpj3VzCt1jMiW0sVXwkggb7fCpPAWpeWZFK15pVIUbceBPCnmHyQst04+tbGG+zC3RXR1mEL4id5Sw5BR/Ko4D7z6k1pnaMXKiwrnC5Hi4yToJB6EXrWOwcrKUIdb/0n8qL1ZI9OCP8Af+88Q2rKgfLTGi2c1lT6gfSTxMS12W5+6tf6grNoUEW41uVWsdBFz1oOHByXtYX9aQ3gaueWNu8HPhSzFYxZGsPhFb/0+c7a0Uelz9a4i7PL/HIx9DYfSgWc9AyuXROL2FmHzrrD5ajyAuyg9SdhXUOTQDkT6m9dyZfGeVHmTF/FGz5phcMuiJ11c2vc0ixGdxE3L3rJMiiPCwoVshXr9KVL4jF7h7kTJOToB0rxY7b9B51ZokCjYWHShsowawRLGBwG/mTuTROIksONZ9trfLfRcrhjg286jhXH74tJcXiDvxpJi8zKmqcdbJywkXoaXI67VdnEnjLw2WUC+2yyeR6HzryaTFab32IuCDxBHGvT8pz4kaTaqH2k7M4jE4yT92j8DWYux0xqx4i/M7XsATvV6Ftc37e5Zqc6k4z68Fj/AGW4YMsmIbi7aV8lX8zf5VesYwsfQ/dVZ7L9npcLCsbSqSBvpU2uSTsSb8+lMsRKRsTeq1s/m4ETW+e7IYs403pXjZiT5/n50GcxUEKTY8OlcTY2/wCtrHjVF2yksMdGra8i/MH6n5dKrWOiuTzpxj8QPv8AzpRPKL3vVzTpocBJFYiszrG3SNehY+xsPwrWKxqqDvVbxGO1NflwHpV6EHJ5YMpKKDpcRTPs5H3kgUG3MnoPzqrTYjarZ2KYLGWPFj9BsPx+dHenGttA1z5weo5Y6ooCC2255m3U86P/AH+1VXDYvapJMZccayPiSj0A6tz5Lfh85Xm1vWgu0GCjxKM0dlltseGvyb8DVHnxhJreX5wyNxNquQ1Nu31LIuWkj4ZuPKdI1SHfpUE2JhBtct5CrBNlyzfaE7Nva+w61zHgYl2RQT6VtwalFSXkxZR2yaYqweIB3WI+rbCmC5mbWC39Bt86mGELHfh04CuiVXYCiBIo5Q2zRg+oFN8sy1Cupe6W/wDUoIt1vvSKQnrUsEmn8zQ4Wc4C3SSxngsmK0ABFOq27NyJ5AeQ60A0jKbqbEUPDiL1zjZLDpRZBLNBnNwDcXtuL1FnHajuoiyoC/AAna5qiS4k6tjRC4czkKXItyrt78Bxj5YTisa851MRfyFq3WxlrKbAg1uu9YfoAsDjGPidQp6CipsxVAWsT6UE+FkA5VzlmILMdS2sbb86r8sc8RQ0ikBsevKi2lW21K5UBu2k38jULubbIfdqLJSawxjJiByNQnGIP4qQTQyMdw1vJgKiGWncWk38xXZZBYv35D/FTvs5hVcmQm4BsL9eZqjQZM39f0r0PstGEw6LvzO/G5JqtqLHGP8AUbTFNjESjnQeLn2POoMbNpJ86WYjMBWFbqM+nya9dOeSPMZ7CqxipbtTPH4kEUgmltU6avyaNcMD7s7gzLJbgq2LH7h7/hVyuFFhsBwHClPZCLThlbnJdz6Xsv0A+dMMZLT2lHLKl0nOzHg1Ni9qR5jjbbfP1rvET7Hfl+VJcXLtv6mkqbkFGCQBnD6lJB9Oo8/Wqwe0EkZ0SEm3A9RTyfe9VXtHBtqHGtHTwi/Sw5zajlBr54DvehxjZJm0QqXby5DqTyrns/kikGWbdRvbr0HubCvUuzuSpHGNKql9zpAHH76K6yFXEVl/sApSay+CrZD2DZ7Pimvv8ANh7kbmrvh+xuAAscNCR1K7n341MzaNzfn/AJpfiM5CHa52v0qvDVT3ZkDKty6Fvaf9k8DoXwbmOQC/duxeNvIMfEh87keVef5TO0V43BVlJBU8Qb16dB2mbSf+f1/mvPe0w7y8yjxC5Nua3/Dj86vO6NmI4BqrnDLY8wOOuBRjym1UjLsy86sOHxwIqpbRh5HqWQmY0MwqTvBUGJlAFdFeDmz0HsrmirAoa17mrHDioZOKqfPn868by7NiB5UwTNiDcE0cLLanhCLNNCfJ6Fm2WW8SNdOY5r+YpNLGBw3NCZT2jZiFY7U6sLbAWNX9Pqla3FrDMzU6Z1c+BJLA3E8elQNGbjUfbpTaXypXi9IPHf61aaKgywQ2rWJKltPXnXGCFluaBliu+q/teuSO4GEmRxX+M0BPF3Mw0sWFvkaOwsoLDVTaHJsMx1Prueeoj766MBjsXSFSTat9VqyrEnZiFt0lkHup/CspuAMlOzDGkkRqCPO1CFmXg30p7AigAHjz2qDMSvwLbUePkKqJ4RZaywfLGaVTqNr7AjqKlfLQRYyN9KHwcfdsqrwJA+ZtROb4MpIyhQSPMg9etQ8SeRVq2kLZT0dvcCu4sv076r28v80olk5Eke7bUHJjSNgT/wDI1zSXuKTH2NxLgWDgf9tWTs6kqwjvBvc2uLEg7jblSvsTlRYd/JuL+AXJFxxY3+lWnEtttWZqpKSx7F3TxfkT5pMSCP0KpmaYhludyPL8qtmLmF9+NVPNhe9Z1KXxDbpeFgTvnKkcaV4rNR1oXNobEsKGytlaCU8w6j20mtmNUUso6duHg9o7LYkPhIGB/wBtPmFsfqDUmMk341VP2e5gO47m+6Ekeasb/Qk/MU/xkvnWNqG1Nw+ouMecgsr9OFK8UaIxc4vS2SXeipgwmQyLVe7QEW9x99PcROADVK7Q5iGbQOtzWnpoOUhVs1GOWN8Nj793GOGoE+YXl87fKvX8rnAjHpXgOUYm0q+tez5ZiLxr+hStYvhtMitqyITmeIBB3ty8v1+VVHMJiL8bmnuPnvewFqr2L32871Wp5eWWFwheshG1czICpHkR9KI0XO9QY5wik7cOFXU+eBbKjoY7qD8tjRWHxMo5VbspCOguOXSp8RlcbDhb6UyWoWcNCVFrplX/ANTdR8J9qHONaQ7mw6U+kyrpRnavs5HFBDLELOBaUfzE7hvXl8qmM4PoiTaEOGNMYyaX4RqZREUMw1I7hlKm9XrKsdqh1GqFNIKf5IjNCADsSTRaeP4ikVtZL8LAbjse7HSn0onKsrPxNuaJweBCjfjTFRtvwrTMcgkiHDjQOIwzAcKZNP8Ay/PlXDOCDc3+6uOwLMC51hSbHkf81a8HmpX7N1sw8tiORB5iqNjG8VwbU8kxhMCSBvtI9rjiVPGmRYBcYMxFuF/QVlVDDzM+5u3rYfnWVIWSUQG/xH3tSPOkiubDc87m9dM7ayQzaLWC3v70LiIv4rm9UJPwX4x5yB5ZABiYQGc/aJtqJHxj6Vdu3WDs4lBIFgCPOvOlzGSKXV3YKqQdWqxABvwtXrXadVlw5/qS6nztcUyPyCL1yeS46U6r3ff2FTZdCrmxJ+e9LTPvZg2xN9xx+VE4WRdWwI9SB+FLz7iEew4CIRxIg4KoH0qDFyXFc5diNcEbD+UX9QLH6ioMa1qxrJdmvVETZo2/tVdxbbb0+zN6rWMek0rLNKCEGZDjRHZr9n2JYOZCIkksQttUmxNiV2C7Hmb+VW3sVkQkb95kGwJEYPDbYv8AeB7npV4aMKKuyvmk4w+7EXyi5L3RQMN2NXD2ZJpdQ66LfIDgelQZtmTJ8Y2HMfly4Va8xlsDc/5qm5yL3/X0qpBudnr5H1v0i184VuDCoZc1VRuwqvZ1gCAXS4PlzoXsnkb42bRc6VsWPPc7AVqxor2b2+EVrL3GW3HLDcbmrzHTEDbhfl7VDB2dLeJrmvWsr7KRQKPCLbcfT6V3icAi7qNr8Kqy1yhxBYO+HGb9XP8AB5BiskKbqdxVq7O5+NGhiFYbH2ptmyi/wiqLnGG0nUuxBvToyWojiYWz4fqiXybGBlvf5fSlU0461Tou0zDZx5eVXHLMkxOIUNp7pSLguPERysnL3tQSpVCzN4QyF8LPlYFJjAt96RZvmGs6B7/lV7j7ApuZZJGJ6EKPYDf60vzDsBEovFI4PLV4h+dTXqKE+/2FWb5dCvJsUVAp+stwL1XY8HJA2mQW6EcD6GnGEa4BJqLUnyiYvgMrvMJy8JQm/StKPrUGJcCkLs5sqfeaGK9DRC40Uhz/ABhE7aeQHztS9sa552rVVDkkyhLUqLaLVLjRwvVl7NZ1chOXAV5/gGGm7Ek0+yeRtQtYeQ40yFah0VbbXZ2esriRbb5mh5cST8ILH6UHla3UaqZjoNvvp5XZxDhWO8h9hwrMa2lfKibedJs1nvtyriBXiprnjb76Y5NMfEt76hbxWFAYUamCquo8hRsaNE28bj0F/wAa5P2OUcjTCCVlsrIpHG4O/wA6yocVnKwoGkfu1Jtd9t7E2+h+VapiTaDwkKIpZ+WgjzBFCY3PjG+hoHY8zGCwHyFMs1xSQR6nNhwvY2Hqa1lGPhdbxyhh1FyL+tqoL3aLrfhMgxeHV4QXBF97W38r9Ku3ZnEjE4AKDdovAeZ8I8PzW1VjMJ10H7QcPI0u7G50MHiQZG+ynsrdF/kb67+R8qbDHXuJsTaIu1GAWOTXY2PS1r0pwjqP4b+ZNendr8r8DFQCCLi4Dee1680/fGAI0ID/AGCq1mY8CYJNls7KZ6q/YEjc3X15inePxA52P515LjMYRvZQf7RUidsJQLSDV5jY+451Ru0s7OYmhTbGHEmXLM8UCbfoVW8fi7+FeJ2HqdqS4rtUp6j2pHNn/iVhc2YH5EH8KbRopRXRc/3dcV2fSGAhVI1QCwUBR7CocZPxtQ+HxYZQwNweHyoLH4njvwrNdq24JjX6gXMnt94qsY6YHl9KKzHG325fq1JnlvTqKscsdJ4BsZGNJ9KM/ZLZHl/qNBY+Twmo/wBn+K0yHfmfvq9JN0yESw5L7nsM7XGx50rxS2FzzP6/GiYZ10/L8KU5jiNt+u3pasiXLCghJmsl71Uc1XarDjpr3qtZs4JC33Ygelzb8a1NNHA2TWCzfs17HKxGMmW5P/SU8AB/uEcyeXlvz29PaC3IVzk0KpGqqLAAAegFh91T4o7etVLJO31yf/RT+WWELMS+xFK5zcknYAf4onHTcd/1ekOKn5caqxTky1FcEOYQh1Kt+j1HSkEPhbSeIP8AxTozb2pF2jmWJle/xD68av0J/KBY8LIc+JsKT5jmIUFidhSjFZ+lttz5UgxmNaQ3bhyHIVfp0rzllKzUpLjsjxEpdix4k3rgCukS9McvwGoitDKRn58kuFgNgBVmyDAkEGuMJgKsOX4a1qXkDI/wIsKYRsBxpHiM1jhFmPi5KN3Pty96c5Dlkkv2s47qPiI7+Jh1duQ8hXbvCAbIM0zDu01WOnrbaqyMaZDc6SOgYfXrTjtVnCySBAB3a3VRyPLhSXBRxaiSibk8hyrn9R1ceMsLwWbaZRyFrWuKa4rNbgknn+vuqj939q5VgLtwsbffVmy/Csw3kQ+qGnR4IfIm7R5n3hCEXA336/o1urccohdLvFh3sbX0kHgefOsrnBslSFsGOjn2YqUW+xOxPXTztyp1gMLD3dlj0nlawFvzNUnL8kXByapDq1kkeBthyub8farg+JVkCxeFrbEgkffwqs4ccDt/IuzvL0cFLm38VufRR06n2qr5vhQNugsKZTviIrIXEjbkkrsAd7mx4mk+Z4uW12Vfbb76Dnwxix5PRP2cdphPH+5YhvtFH2bHjIo5ebL9R70s7W5EsU+5sJLlduJA3APM87cflXmBxciMJFV1ZTdSL7MDsbivUeznauPNsN+54krHjFs0bHYOybqy9D1X1o5w+JH6orzW15iVfF5ettiT7UhxeCAOwqzZ1lzQStG6WYbkA7WO+x5ik04JvYH6VVhlMltNCV8Km9/kb/fQT4JTwA+dOJcOb2/CoWw1WFPAGC99jM71YdY3N2i8J6leCn5beoovG437q86gkaMh0azDlvuPPlambZ8GWzDSefSs2eiXxHOPk2NPqo7cT7D8bihS/wDe96Wz5kh/jX50DLmSDfUD6VahS+sHWXR9xnmuPAQ0r7L5joksTYk3H4ilmNxuvYCw+tCqDfbjVyNC2OL8lCepfxE14Pb8FnAK0LjcxvzrzbAZ5Ios4uOv+KObtAp5n5Gs16BxllIux1cGh/jcWACaqGYY+zhuhBA9DetY7N9Wyj3NKGJJuav0UbeWVr9VlYifTeVY0NGrrurKCCPMXH0NSYmW97/r9bV5x+y7tFrh/dnYa4vhv/FHyt6Xt8utXXFYoW8+P1rzd1c6put+C7W1NKS8gmPk4/KkczE+VMMTKDS1m3/W1NpjhD2zqOPnVR/aBKCkY/q+gU/nVnlnA/PpXnPaPMe+l23Vdh5nmfw9q0dHW3Zu9inq5pQa9xTatgVIkJPKjMLgCd+nPgB6k7VrOSRknGEhq3ZNgPLekuH0If5z0Gy/Pifa3rTbDR4nEeFQdPRRpT36+96S5AtjlsbDF8Tam/lTc+54CtYbE4rFNpw6aF5kcvVz+FNch7DjZpTq8hsvz4mvQMuy9IwAqgAdBYCuUWxbYi7L9jo4CJJPtJeNzwB8h+NZ2x7RrEvdI252JH3Ct9re1ceHQhW8iRxJ6L1PnXkGLxsmIctcAm4UE7C/640yMV4CjH3JcJJI7szF2BYkcNgTwH0p0Yjo/wBxdug51rKMhKoC0q6vIEj7xemmPy3RC7d6CVtZbEaiT5ttUctlnpGsmyeMQKXZi5BJN7czyFTZe4SZx3r6FC2F+ZvfiPSgMFijoAJHC3GhcMr3ctYeLbfiBTOkLGWaZxL37pGx7kabeHctbc36b1lDQwy8dIINiDr4/K/SspcpyyNjFYLjnkCtE9xe248jQuSDhsP4Rw5b/lWVlKr+Vky7R2iBjci92N/Oqz2khXVw5/ga3WVC+ZBPoqGKlZTsxHuaWYzFPsdRuDcEbEEbggjcGsrKckhTbPSWmbEYbBzTnXI0VmY8SFY2vb1NATYCMHZfqfzrKyqdjfxWBjgEkjAqKSIX4dPuFZWV0uiYgmIhXp+r0O0Q6cq1WV0WG+iFsIjcVB/4oPE4NBwUVlZToyeQUuBbKoHCoga1WVZQB0BUyCsrK5kHDCuLVlZXIkJy7ENHKjoSrBhuPM2I8xY17AJCUBJ5VlZWX/qKWYs09A+JfYCkc9edDOxrKyqsS5Iq3arFOIwAxAY2PmKQ5XGC24rKytehfhmRqX+INsNGC1iNrUNrLcT7ch6DlWVlEVWWzsnl0TgsyBiOu/04V6Fk+HW3wjbh0+VZWV0RT7H+HUUB2nnZUUKSA3G3P3rKymPomPZ4NneKeTEPrYnSxVegHQCp8IKysox3gbw4htK78xUuKmZlsSTWVlB5GPolgjFuFanFbrKhHDHKT4D/AHfgK1WVlBLsZHo//9k=',
    'description': 'ไข่นกกระทาทอด \n\n วิธีทํา\n วิธีทำไข่นกกระทาทอด  เตรียมแป้ง:บดมันเทศให้ละเอียด ผสมกับแป้งมัน, แป้งข้าวเจ้า, น้ำตาล, เกลือ, ผงฟู และกะทิ นวดจนเนียน.  \nปั้น:ปั้นแป้งเป็นลูกกลมขนาดพอดีคำ.  \nทอด  ตั้งน้ำมันไฟกลาง ทอดจนเหลืองกรอบ ตักพักให้สะเด็ดน้ำมัน',
    'price': '30 บาท',
  };
void _incrementLike() {
    setState(() {
      likeCount++;
    });
  }

  void _incrementDislike() {
    setState(() {
      dislikeCount++;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ), // AppBar
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            // ปุ่มไปยังหน้าอื่น
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/page7');  
              },
              child: Text('ไปหน้าที่เจ็ด'),
            ),
            SizedBox(height: 20),
            
            // แสดงรายละเอียดของเมนู
            Text(
              'รายละเอียดเมนู: ${menuDetails['title']}',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Image.network(
              menuDetails['image']!,
              width: 200,
              height: 200,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 10),
            Text(
              'คำอธิบาย: ${menuDetails['description']}',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 10),
            Text(
              'ราคา: ${menuDetails['price']}',
              style: TextStyle(fontSize: 18, color: Colors.green),
            ),
            SizedBox(height: 20),
             Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    IconButton(
                      icon: Icon(Icons.thumb_up),
                      onPressed: _incrementLike,
                    ),
                    Text('ถูกใจ: $likeCount'),
                  ],
                ),
                SizedBox(width: 30),
                Column(
                  children: [
                    IconButton(
                      icon: Icon(Icons.thumb_down),
                      onPressed: _incrementDislike,
                    ),
                    Text('ไม่ถูกใจ: $dislikeCount'),
                  ],
                ),
              ],
            ),
            // ปุ่มเปิด YouTube
            ElevatedButton(
              onPressed: _launchYouTube,  // เมื่อกดปุ่มจะเปิด YouTube
              child: Text('เปิด YouTube'),
            ),
          ],
        ),
      ),
    );
  }
}

// void main() {
//   runApp(MyApp());
// }

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Page6(title: 'หน้าที่6'),
    );
  }
}
