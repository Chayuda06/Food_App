import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class Page2 extends StatefulWidget {
  Page2({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _Page2State createState() => _Page2State();
}

class _Page2State extends State<Page2> {
   int likeCount = 0;
  int dislikeCount = 0;
  // ฟังก์ชันสำหรับเปิด URL
  void _launchYouTube() async {
    final Uri url = Uri.parse('https://youtu.be/PupEj90q4Wk?si=o5oyiKhZvUdyqfWo'); // ใส่ลิงก์ YouTube

    // ใช้ launchUrl แทน launch
    if (await canLaunch(url.toString())) {  // ตรวจสอบว่า URL สามารถเปิดได้หรือไม่
      await launchUrl(url); // เปิด URL
      print('เปิด URL สำเร็จ');
    } else {
      throw 'ไม่สามารถเปิด URL ได้: $url';
    }
  }

  // ข้อมูลเมนูแรก
  final Map<String, String> menuDetails = {
    'title': 'ก๋วยเตี๋ยว',
    'image': 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxITEhUTExQWFhUXFxkbGBgYGR0dGhsbHxoYHR0fGx0dHyggGx0lHRoZIjEhJSkrLi4uGB8zODMsNygtLisBCgoKDg0OGhAQGy0mICYtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOUA3AMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAFBgMEAQIHAAj/xAA8EAACAQIEAwYEBQMDBAMBAAABAhEDIQAEEjEFQVEGEyJhcYEykaGxFELB0fAjUuFicvEHFZKyM4KiU//EABkBAAMBAQEAAAAAAAAAAAAAAAIDBAEABf/EACoRAAICAgICAQQBBAMAAAAAAAECABEDIRIxE0EEIjJRYXEUQpHBI4Gx/9oADAMBAAIRAxEAPwDo+TyWq5sv3xZzOaCjSogY2zeYgQMDXOKGYmKUSKq5N8R4kIxGcAYcwcRscZc4jY4AzZ4tjRnxo74qV80BgSYQloviKrmwNzgNnOIecemAzZ01HCAm5iQCYwtnqMCXGStxVRscQHiPngbk+HaT42JYx0i8wIB38r4L0cmCCYv9cTnLHDEJWq5vqTivU4kOuNON8OYDWg5XWbe2E3L16tRnZbIota0z8/2jG+RQLJiX+k7ja/FPOMVKvGI2M+mE5arMxDsV6/8AOLGXqBLKd7kzf7YF2PqUYlBjKOOOIJS3TnidOPrOzj2OAFPMu06SHI3A3+RAJxqOInVIJA5CcKGRhKPGDGxeNjbVfobYtUeL9cKAzasfGAYHvjcVFLQhI+31JwYymAcMe6WeVueJxVwj5fNlWht+vXBnL54jzGGq9iTvjqMGvG2rFCjmAbjE61MHcURLE43ptGIVfG4OCEGF8lnyLHEfEey2RzL97VoguQJIZln10kSfPfbFFTi1TzJAicMB9GAyXDDjETjE7DETjD4MrviFjidhiB8CTOkTNirXqxiLiGeVFktpkgDqSeQxWzFcKJYgDqThRcQwJrXzPtgPnc4BzxLncypEg/p98JXHOItMIPkQfscAWhqsv53NMzBev2wbytOnQCVA0uRGkC8n7wAcKXZx3qVDqEmAAIv8tzbDjVyzKqnSQL6p/ukRFhNuV8S5nF1cqxL7hXhOgbmfXrgslMcgL9MAMqrbW8xODFIsBN7eeFiG0kroYO243HLnjnfGKLZesYE0nJ0nodyp/Q9MNud4g6uskhTaeU8p/nPATtbnx+HIIHxAz7j9MILqz8CJPlKnRi/VWgRpZiD6+Z5Dff12wL4tlO5cANIOxxmvlFqOrKwkxbDRlOzy1QNTyQNiLffBPkXDRYxK5eBidTqwQQYP2OLKOD4oBmdQjmIM22kfY4IdouzRy694jFlEBgdxPMRywI4bSaqwpqJZ2UfcSfnhyOmROanUrTMCLEkLkY8uY+eDPa7hT5cUlLhwQYOnSbad7mdx8sL6sBffGIVyLyXqNXJcJ5XMjZrg/TBfJVSotBXkAbx6fURhWVzi/SzJgHmD8hjRYM1qIjdlcxzGCSZsbExhP4ZnZm+x+mDlJwYw4NJWEYaT4tUzgNl6+CFCthoMURCC43GK61MWVwVzIxviJhiwwxBUMb7YpJiZXcYpuur0xYZ9e2339MV61bTYXJ5YQXuFU5z28Wp3qlWMJcAcjvqHmMUF4lUrqQxvvMwIESQB7EjDN2goZeC9V1L3hVYEj2GEnKKKh0gEQbz9I9vtiRzRudz4mxM5/MGSgJgRvY3v7T9bYqKBaTH85/f9cbPJ1NuQ0+Ln5HExuLBZYQRzjfffoNsHqXKNRn4VVShemusc21AkmNxA2j74s0M0K2aRSYKyQgIOwm4O3lhWy3Ee6ULSTQebEzfnpHyF746FwFVqZTLs86xrOpgAx1M0ecGRHtjzsmLjbMZX5NUBKa14caiquWMCQIkmRffF1s2ymSJHltH64q9quAkjvguw8QHQcx5jn8/UHwTPJqZGLBiPAQd7XBwfk4rcUF5HUYKnduDeVP8AIwtZrLa20iWX9OUziTjemmwILISdLEgDfn5Anra84F5vtEtGh3LIRVUadUxYCA1rzH1wLcslFRPP+SSG4wf/ANoNCqDfSfKw6x03+mGPKVHp1NerwFYKxz5GZ/5nAbsrxcMtRSgqsYIVyZIghgOtotilVp5ssRTjRJ0wfhHTxHltO9vmTKzkq1D+ZNdw32w40pptTFy1vngR2JpAZgs9tIt6k7+wB+eK+R7OVH1MzXDEMDcjnvzH7YkyXDjTrnXU8K3Czc9AeoGOTHjxYWxqYatxWMnb/MNmClNIKJ4tQG7GwX2En3GFfh3Z6vVJAXSAJLHYD9cFOLdoSNNL8jWVrGCLWm0Cd8FM8FpURTW7MZLTMjmZ5yY+WAxM+LGq1OGdlETs3lHpNpcEdDyPocXOGrMmxgXH85THzxc4/n1WilFQJkmo32HttPli7wXIFKSl0EuNfisIHwA84J8RjkoHPFWMlgC0tx5SUsyuvBqzhaqQJEw1rekSBi1la+nwNY/P68xi9k+K0qJbXmGqOTJAQmPaAY8pti5mhl6zK0DURKmIBHz+nphk65Vo1IOL2XrwfLA6plnpEK152IEg+nTGadeMEDOq400Kk4uK2F/h+a5YMLVw5TFFY5tha7ZVqi0hoMSwDHyvt0vzw0MuKHEuH96NHXfyH74PMbFCIq4u9msyxpLRazCyExdRsI6jb0jE/Gaq00NJCO9cEAk3mN+tvLC7xvNJk6qoWDMzSg3MTu02AEe59DjWtUpljUImpbxkkm3ISbegxEchUVH4cRYbgU9jsxGlaqE+QJA8t/5OAdTs7WoVNVVwQbDSDf1/hw6VuLBVsfEcA+I131KH0G3I6iDymRE++AxsY8fGQGwIHyqX3sQRBnz+1rc5xJTpACFFyxG4tsB5j264jShUKskhjYpAOq8yCOQgb3tihUQkAswXmB9Lz7YdGzerWVH8V4M6RsYN7nqLe+O0VKYdFegwIKh6cbaTBEHlvbpGOD53iE2ifUb/AOMP3Y/tZ+Gy60alN6hUak0afDMyt9lvPucKzoCouCuSjHkdoqTUjSrAiptsLxz8iIvgLneFUXCsqCmwM6k0jkQQTaZn0wHzNbvKhrh6hSoWYqFsrW0rIa3h8ht5jFbi1fMd5RqjVUy6OhcU41ATeRI+Z5Ttvjzj5GcC/UrIRF5ASzxLs8x1qrl2ME6r6eoH+kDa0+uNchwRR4IDskajVUGQZEAHa09ffB/IkEFpBZt45X2wu9o+I1Mu/eUbkgyDMcuhHXra/XCcXyMmRvGDPO5Y2zWRqUu0PAaaPTqZZEpsHnwi+obSvTA4cSBdkZqaOTNj4Z6A8jOwPzwP41xmrVpzP9ZyFOgQY2hQLyTA/gwHzOSal/SqIVaxuCCBp6b7k3i8Wx6uL45Zf+Q3EZ1VntRQjbwrP0qVOo9XU7s9wgB0gaVGozG55Tvg3l62VFMO2moWvDkGBytyPlvhX7O8SywSpSNIo709JdbwQZUibgzpMdVGBWU4RVqGmzjws8MfPcg+eDbHjAJOjBfBQsGNvEKlOot6aMseEEALy2JH8jFfLUoAJ5crn0A64x2gqVGcBVApAAqwg7RIj8pBHpHvjbhalnKswhaT1D0EbE/U+2EJjtaBk/CzUu8OUDxAKZ5kTzOPcX4gQ4QNcAaut7gegEW88VqPENWwJPkOo/WcCM5WopVZ2qMSxJK6byTPM9MJUO7HldDoRtEwvnWyyqr1UJeodxEgALBJNudvQ4OcB4IzJT1qDTDhgDIaOUAbAz1xa7K8Kp1kV2TVpaRNwNuvpPvhxqryA5enzxYt0Jci0ADBncqCfhVV9PeSZjAannslXZqdNkJk7bG1zB5+mIP+oPEjRofh6SlqlZWGqfhW2o7TJ1R7zjm3A8pmUqo60nOluQsT0nb54NQauM1dR7zGTNI94hBS09R/j98EaObkDA7JZCqlF2q21KbTIBMQJ8rjFajVYDDEMF13OxvViT0H1wO4ln+6pkz4j164xxWtopjVzZfuP8YWO3vEO6po8gAhhz+KLAdCf0xrMS0nVRU5rxeqa+fN9RJIJ6kCD7SDHlGN3/ErU0TYGBUF1iJ9yNvXFHgKlq4YCYmeYuIv6zGGviwsNP8ApIjeZafsPljGAMoQVuD8uy6x8TWYHVuTAPLYTiqayMXI3mCLbTH26YshvHrHn9IH89MDVpBWMiASI9fLACo4y+tVhZTBggGYPKQTa1sUXpNWjvHWnTWYCrqcyekgcz8zgtwSjTquUd9BYHQ1iJHKCLzc78vlbzHZtqSBkClgDKkEgm8EGZIuD/Iwh8yq1E7m8S0VMzwmiKilKhIkWeJk9IHL+HD12U4UqE1TJDAi4hd95m4t0wi8GprXzKh10nUJVZEdbGSP5tjo3D8lFPStQqpGpdQErMSpk9T9dzhfynZQN7i8eJXa61AHabhDJ3uYouUMg92PgChbxzLE+lse7P8AG3qUSCnhldbG8iNuXW4vjfjGbqKzqtGrU0sAJU6TY6rBSLmIPlilwCi9MVcswBNEMtTSbG8SD19BywtgWxEt3/qc+QI1J1+Jbz/EaNFyKTOWA1eEjTfkRyHlilnuKrVem2ksIYvAnSLX9J8ueBtSkq5ogmVqLpMmSCRz8vPzxe7Lo6se7MNdW0PAUGPiJJgExzG3KBgk+Olhvdf+yJsv1cgJmrmstVzlKpREJIRiQQms7MIG2/O5At1fu1HZVM5S72kE71EGmPzqOrTDeR8772ReIZYkFEh0Oos1pDQbiNgSRO+1uZwN4b2jzdNfwwq6H1TqNwywZUyOceXPqcU+NtcT1O5+TcH1+HVKTMwJUhiIP9whiCOW4+ePUuLVA3iMKGY6eQJ3k8z5npjoXHsv3tKmyCmWqBVLKQxqPoiDAA/KL7RA6QjplaTBqbd0jiQWLkGZE2BgknrtHlhisuRdwiCBVy6ePU1UbsxsFAuT9vfDBw3LihTq1nRi2lRAAgkEl994ja3wjCrltNICpGooxVPWfE3sLf8A3w0Z4ppp1XA7lVI+MkhiR4lA2tud/SLpGNMQ17h/Hx2SZvwTM5erVLLXam0hiCNMzEwNmNgDI69cNufy+UqoWrKj+GCWAmJnfcXAO/LCrxHglGqneapbSzjSIIWRcR5MCZJJ0zyg2+J9na34QDvGOiGCk8v9TADVG8+WC/YlB73D1DPKAEp6VUiFWnE+ZgWHrifiOdXLUtdR4XzP0HU+WBFLP0t0XXVAnSsdQJJFgBI88UqNZ6lRnr1JCxAgaVP+neOUnfzxgH5mk/iCuGZk5mtWrnw0vClLUbydRbyBi59V6YstUFAAmIMxz+XywyZHJUqo+GROqdIAnqJEchfyGKvGqX4dGfUrJyWooJnopG/ocExm4yAdzOV4ktSg5+KAZHKCL4oDh0gFZIItbEWVVKlJ3oUysySg2NpOgcvT5dMLeW45UVQNjzExfGoxrULMgJ1Ojdv+IaUSlBlzy5R+skR6YCDtACnd5he8EXJFjHO/P0xT7XcZ7/xqCEV7E7xp6esn/wAemKDOhUiJMSCTMztYbT5zhhIYyTCyOtAyHO8foMy06CFRq+LlIv0Am2LvEECIDU+OoNYUck8UMZ/uJY+2ANLLq2ZgW1QNO0mQOUCJO0YM9qak5qoF+FSKSiNgg0wOvPHGgNRyg9SgrSbTz+VtPzv9MYVTpVd/vyxc4dkBUYAWWbm3kLeeLXEM+uVdkWkSmoS4a6i24jaSdjecKJ/EdKfFKBydKjmkOq4IHqCCD053vthj7PcXFdAdJC/EpOxMGVPpqPy2xzfjfEA6HTI1ciZE89PTc4m7PcTelR7kuqHvVqIDJPmpAFgw69ThOb4/kS/cD+oCNxj9SNLXpjSXZtLBfEAASI9sT5iq1V6YSmWCTqBI8JNrgnxTp5dDGAuXrLWCGn4KyMHm5tDagOUm2+DCHuKlPuwNZP8AUFoKsfzdSLkD98ROeTAN3LcagCxC9HiUAFQhUT8IO/Qi8eYPTGtbOUQymoB47ghbmxN46W/humcar1VzDmgui5JImXJibne8+uJK5rae9qjTU0kDVs4AJgQYF4tyvgqPVwTjXuXc9laVOgawcwATvYD4QIHM6oBgTGFLI8YemCiEgMNMBBBF97EC5PucZz1Wi0sTWWmRHxHwtuTFwQTuLnY2xtW4JmKVOnmAGhRLAwbQJZeYF5gi3W2L8eLiuzszzMuNHNAVI0WoCrQSCboNIMDrMECTseXTfEXF8ktcGoKihgWIF9ywMG3ha4gE9ZOxxs/EajNpZgCtoKr4jIgENa9rbHzxPkaKVGJMimT4iF7ttX9saixJNtItvI6VYxQgMqp9KyfhvGc4KIQKhjwM35ioJmNtxYm2wwK7U8Np0zrpjTLSR1m+56XvvjYsxapWTTSlyAmq+8ED8oAt4gRz64s5ygAB3gdCF1Uy11lSNRabm4iIIJ64BVCn6eodAij3F9cw1Z+7TyUXsADJj354bcjxHLJQWnq1fkNud5mRIg3+WIOA8H79TWNUpVcmFVAVjoQACPaBcdZxRzvBK/ehdBZriVBZWE7j25W5cr4zJxfV9TcXJNx/4QiVCBSVlfuydYDQb2BPw+x3n1w1PrbKEsEFRqJkH4JKn6YTuyy1qNEd5IBMJy25RuDbY8sHe01Q1Mn3ZDIDC1WidKCNXP8ANsP9xwhaBjnswF2ayYVnhie9pqBtYiZI5DcGPIYXOzHenO1KVQ+GmTqm+xgD0Nz7YcOA8OGXoJUpIztUAhqzGY6AAcwJEb2wm8I7QKmbadOipVYGqwi2ogHTEAH23wwbuZ1G/tPxruqOqn3giAptova83j0xzir2rr1Gip4oPgJ2HmBG/njpfEeHU3QrUOpTsL3ETI+vywi9qeztPLUTUQESQFDG9+ft08sEoHUG6Mu9kuJOKpLEzFr/ADxPmalN2JNNTyHh5e+A3YTNq1Rlb4ot54Yc5lGLEgz6YD7SRK0KtuDK2eBpmktPUzEHVMRA5/M42ytNgFvJAHoRf7D/ANsGKXZyqMsx1RfVAF4O48zgTUp90q3JLTIgcjG/Lblhmq1PK+NiKOTM8PIOboJEf1FJ6/EOfPoScSZoh6lUswXS7t4jEnVtG53wNp58Ua6ObaSD8mBj6Yj7VKFzNUEgeMsrDmGOoHccjjjsSwGjN89xSsZVFCopBGiSAQDfVMzBwLzHEqhJLu02+Ly2mR/IxXfNN/cYgbmP1xq6HUAUJbwmDtBAImDaxGN4gTCx9Su2ZHegsZvP89+eC3DOFNVqAoCzHxAC9urHYep64h4pw1FpnSupySNV/DAkiNjzvhx7E1qdN2eiHbUpUF9IFgsECAQotciTfCs+Sk5LFLgLZNwdxXs9Uy6ioKrqZ/KQfUWt7HDLT47oo02K6tYHjifFBsTsDI9sTUEaalXN1VcrIp6SSskTAFhNtIt1xZXKVK9FAvh8IjSo0o0yYBEGcea7cqB3PTUUIMFc1CzClNQqfCWACKxMM5O7GZiOm3MpQysKlOrqLp8Lm5uNj0P+MDuL8CzIJrqdLpSIOgElyCTsd56GbnBDg/DalWitR6ssyqTpiNhuY5GfmcY2NiLWcci9GL/FOD0EWqWCqwFkDEiFJ0ki0g8522wQFWpXydPMWC7QG+FbrMgXMjoDYc8WuPZEikTIaAZDCxAvHuBuOuFTiJorl6X4StUUKs11V/HugMo06dJm3ReeKsduBy7v/ElyEL11IKvDlq1CaavqQQ7VCT4pEgSTtEdLnfAfN06tWo5FRu8RZAAMCNwNPwGYg9RHPBvs1xILT0vMybtu0mZnmb4q5ZdedijHjPitPoRzBvPt5YfjyuuRlbodSJ3B3CGQ7N5irSgCkoIOqS3jmxmNzYGYmRM4h49lKgyyDuv6q1AIiYAJ2gadBgWsNsHs9xtaVQ0yD3Q2cHwncGLEWYFSBeQABNsTHi1CtRJpkknUDuCNwd94/bCXzZ0pnAqK8hWU+ylUVqTVVCiqVgzbSRbflEATyxp2O4JXWmQHAexGoyJFuewIjbEfYwLGY7wmkECsSSBJP/AEC98X+KcXoK3jqmCJRKDai0+YELebNfyOG+yPU9BWBUNGug9WpQdKqrT1grIMiSLkRcdRgF2gyqfhjRpvN9ywuf8AVJuSYPtgk+a79KRUEIRI1bg7bCxJg87Yv5Hh6miyuqkybgQSBB+dzgwPUyzVic8y3GWy6E1arVJZTOosUsRN7yYiJ2GFniPCqtdnqomigzEj/SDzb5zHnyx1bM9mcu8zTW4joSD1IgnA6p2Y7tWVW8EWBYj54NSB1MZT7i3wnLpR+OrUqViAtJlaRtAAF/4cXs3w78Qg795g3HnzAjpAHucYqZZ1daaqtMD4JM6tIJ8MTe04lDMpbUw0KjMSLGItHmTG2MB3BIsSHgfZ/W9QUlRB3ZFOTDa5EGIsIB3wr5zP1svUek5IIY89773GOm9gouxHIt84/YYrcUy+UeofxNEO4gK0G6brtvEke2CFEWZh5IaEJUXCBhJgkkDpO436398K/FKKkhQ0EzpnrMkHyuYwxVj4r/CeZH64r57gC1BOqDytP64n/qEQ0xjRiJ2IjVuB1KtburSADM+E+ft/IwcyvZqnXOiqx/pgKtQMAxEnwkXFrRaf1z2ioNQNKqoJ0MRpMz8JBGrmD588WtaVVFWkwWEBibzeVMWJG1/+V5szMobGdf7jMeMWQ/cDcS7ErRqBkdnpiJDQTJneALecf5MJR7xCyEMFUnuiBJiJ09TM2Nrj3kypNdu7qCBuRPiYTtIMADrHp5GBwtY1JaD8PpeIF58/TE7tkNcu45Ai9RQ4Tl0zbsoDUgtmnkdrAmxAEdOUYN5/s3UhTl6w6EPHwmOa/aMaZzKGiXq0KZUPLOCJEiN4HnM+vlgvSpEgMoJXkRfkDy6+eBbMbFdfubwHdwBw3I6hQpNKRAcGQJ8RYA85Mww5Gxw0Uc0xcpTACCw5XEWH2wIq1dFRTbmQAAOoE84nf6YG9oWLlWk+G8flBmfOeeANkw6uOdTN6Jhvfl74A57jApIHU7tBFo3IB+cYF8FrV6ymmiro1SXnnAtHOP1OBfGOB10ZRrmnqVzyuCARHrg8agtTGJyfSNCFOJcT8UMJLdT5WB5Rvv8AvgWmRbM5esmqRTRipIGnVLOb7206SN7AnljGVKMztmQ4ZWhUAAkQPFJ5TI9sXeH6H7001K6hamGJnTuZMXK6x74oQeJL96nlvnZjR9Ra4nTYImtCATpRgTBXSQpgHVyBE+1rYj4TwnWutdSOoEwxnUPMHf02mMW+PcOYVFKglbhCWNoN9JJsPTBbsNw0sarVgNAIVBymJbpfb64q5F0HAwNE6i7nnzFBYqa2pkwQWMC87bC8HDd2e7o0RULDytHSeW0z6kHFfiHCxU11JRlDMU70u0qu8nvIF+cCPPA3s/w/+oaZZ2EalUHwQZ/9doBPttgMuLyJ3BKc9CHM9nwQ4oSarAlUQK3iUEAwykcryIwN4znRTANXLolbTLin8N7bx0uYHvhuyj9xRcCkLAklB4mgWAECT7xhFzyNUp1HdnJJsKihXAHI6Ynny5YUhZRR6ua/PGNxs7CcWpPlylWoFNCYdyApVzIk7CCSPSPPDfkq6QFNRWYl40mRsJvtYDbHBOB59stWIZXZKg0lU+IgnkNjzEeeOxdm8sppsPhZRrAM6lDKQZIETbYT9cVkEGVYmDJ3D7It/EI84wG4vm5pkIVkkAGRbzid8a5rhZrIRTc0yQf6jAk+ouCfnGA/BeCNTqNNQvIjvWvHRVE2vfwx88LlFyLLZio7vRcBlVTFXTFx57T6YH8LKau7c/F4rgwL+FdvU4scc4dxALUAbvEUAqEMMwjxDTdiQbATfz2xVo5XQoY6tIF5ux8wBy5XjbGG61MsXGjg9IU0rmmdUIREjc+fpOJciFqoDUCswlZ8pkRPK+IeGA6lWIQ6gy8zIIk4gpZVUkB6ygmYABj30mdsaLAEEiyZJmsnrNzBBxYyfhsbx9PTGmXzIqKHQyCL+vT+dMTIZ/bHjMCO5aGsSXP0Fq0ymxIsYB+hwk1+ztSlUdnqKtPddMgnpI2thzUE21Ae37YHdpKtPuleoBEgX3v0GKfiZGJ4k6icorYirw+u9J2qqS7SpYnlcT9Tyx0BR3iK62kTvyIxzn8RTTWQp0lGiOto+uGvs1xghBTcwRAH+LYb8kbuchJEYackc7cjv/PPCbxx6tCooo//ABvdkUxpix0rMR/nrhnTPhGMn+XwOqhatYMPhVbW53n2ticHgu9w1FtM0fGNWkd5v4rSDbcW35YH8Sq06h7k3AHjIB8PIDVG5wVyWbVWYEEnSdPQsCCJ6TtgHxLjlGnqoMRUqVDolYinJAmB+cH688biTkb9wsjcZT7PvTy9ViKrKgnxhZAgbGJEbE+gxPkO0raqjV9LBQxpmNOoyNPh2mwidp+RDLZLL0kNVlDXaJAjwxcQApv5Yg4JxalmalZiFVUlQAQ0CJDAjeTPywwhCC1XJ8uYoNwL/wBur1kavUfSDJPhaVHmNO3rvOF3gOcqUc0jmXRS5CyNUEMLi4BvJE4axxAVZmES+oHSdRuOoJA8vW5iAuayh75GpkGmPiIIJBmIkXIuLke5xahHA2Knl2eVwx2kzEZXLuqjxvCgDYMJK+sj1B88U8lTq0qLGSKlQFEUk7TJMHnaw/fG5zijN06VQnuFaXWfCJm56QwUkza5wz8Zya96rQLAGEjSFncgC5MfTClbxYxL1rIT+5X4Jw2s6Gn4QUKgrVaBt+XTPIzONuA9mqlPMM7GmbmNL2F5jbz+uAPHe1pp1dEBwIFmI67xHLl543yHahixqU6VMsJlvzRYmdSzFvphJObiDWpK6DG5Aj5maqiulJyuqqG08x4RJn+dcLPE8sgrOaykavh/tEW5Re0z54s8M4mcxVDMpViCA4E7zf2k4XTmeIUZOaU5hAxV2AllPoB8F7W67YLE7ZQQexMyHyioOrZ6nRzSrToh6hkLq5E7MIHQEe5w75nXk6iZjxtSnTWjdVbckDcA3iOU45/VdlrHMJUQLtCyKlPYgwQOYEkYe+D9oIFJKwqEspBqRKVL20kSxsRvGLCvEC47468VqMo1VEgsCnVT8Q5bDYjpf7404kvdr8SqqqRA8ME2meQg2+eBPCeHdy7wzd2zlqaH4aYj4R7yegmw6zuqUzVqNU16yCSxspg7dBgY+VeHZl1SCAzAm87HrJ5EQfQjGO1jik61FA1VKcNaQdJ/OBfT4jcbEkwZIK92fztU5hwFC0mYmQIIAOx6z8xOC/aLhlTMZinVWqafdppWBvMkyRty3B2wS+xMYbBlzhuc/MTCLsTsSdh5n0wTN7yflhTPeSKdRw5BIpvA0SRYOosOgYQeWLPA83mGpkMjSjFTpPhMAGRPK/njgeOoYXluT8YzFLLSaMEx8IBI+Qxc7O5ta9IVG0s3MA7X5r19cQ1OBrUy5AHiAKx/PnhDp1vw9Uto0uLAhtJ3vFj7jywrP8YZF+nRisOWtGdKzp0t4LSJj+DAvjxFWiaZsbHa4IvGAVPtPBU1AxDCzRJF9io+4xZ4p2uokQUZtP5gNvnBny+mI0+NkU/uPfOkXmPeDT4mHVTpt6FSfrjXKhldSXbwnysJ2J5x7YFZRwapqNUNMarW8XUDmAOXP0xa43xQVIWiGAaA1wZjYAi5/YDF5xsdTz1zMX71OgPS72L7RJn/AIwP4xxqvRYaVpkKBJHLofL0xFwGutPLJrJV1WCDvby3No9cX6ORp5igHDSSCd5joD5xiU4lGiJTl+QyCxJ+C5arm6DVGbumI8LAXGoQCPSx5fXGnFeFU3paERVdG8JQAQ/ImOpjrgxwthTydNQRAmT5i23O8/IYFcOzMFg5AZ2doPxxa4XmLgSOeJWJsBPUrx5FYfX7lF+Kr+A0VSgqaSCAIkyQbECDIHl7HCz2cyHeMSxYB41ottV7avKTytfEPa2uveikqiEqteBzExPQMT9OmJOH54IoXTsYLEjTM9fKxHpj0PERjNe4g8WbfqMWapLTWYAE/Csb358iP2wISlUDjw6hvqFiBB58za/1tjfivE9aqiSSDIMXPT/kc/rXp8QdtDd6g0mfihmJm5HWZPngcWIhbMazA6qEcplCXZqoGpha8Kw66TAVrQeXw+eBDcXOXVlTwgsfhggwYiRMcoPTnhgz475gjiDobYRHwgHc33sevlgWvA0y6GpmmkGNNNSbk8jzJ22OKcaHKg5CSORjYgQbkXWs9TvKSabt8JJZmCqBqF5JE7jYjcgYu5Ls+4JqZeqBVUiF/KRNwfp6X6YmyXB3FfW6rRpMfgRtZB0+EGbfFeBMYYOGUVGYbWxUqI0GIkkQSqm4IG/U47I9aEzHhuy00yXZl2rd+rFHkBlQwNrsVnn1jphuqZGAdpIuSJnbHsgx/Ks/6mER+vt9r4q8TzZIIUlipEmYA9gCTiYtZ/ceEUdQRxyjTYaVSSLGFgi24bp5H54T8pn8xlVCNTZqaPqSQSAfMg7T54YlzDZh2VlqBFJkqSV6EkQfmMUM5RWpmNFM6KYIB7tmgnyvEEX3w5GHuYykdT3CeI06hc1czUZiSQgkb3gwJ62BxOwGqBTZkcAOuveDKmDLCMFspwimGgan5kmW5dCb+uDOUyJAuAB7X9ojGkj1M2Ir18swU6BAvI1HXfqzQZ/k4s5POnVAqtqEggwfZgenz88M1PLKNiJO8DfAjjfBUKmog0uokFd7XiNjN7YyarfmBOLZJxU1L4UZgxXSZ1T+W0QT98FeA1q9SgpMBgWUj0Yx/wDkrgZR4tAIqMxUeViI5xInAmvxvLaminrBMzf98cQTCsToeUqGjmjQf4XEoT1HL5T/AOOFD/qPwcK2tRAqER/viI/+w+qjD72yyB0rVUeOmQy+36f5xU4xlVzeUOn8yhlPQ7j0vihRWpF+5xt81pCEKZVQCD0G3of3xk6m+HSSRIB2O2LPFaG1QA3tUA5MOo6b/IYzwbhtRqgVdj9MdkHuKyIW2JT4RwupmSF0lIPitb67HHQ+A9naVE2WTzJ+wxb4TkRTWBc8z54MU1A9MKuUY0CiaVadPwqwNzAABI63jYW3NuXPEeZ4Gh8VL+lU31KN/wDcOf3wSoLzj9vnibw8z8v3x3EHuEwBitxBWogmsg0kyXS6za5H5Thd4jw16tcZjWFVZVDqvaZAA2mT546PnMurqVIkEQQT/jCPnQaVdaKU2gjwmdQMEWPOwsDyxI+HxW6QsOMFqMBVezeZcl1VKigx4DedIUCDAPhI+EtMDrgGzKqsSwDSdSGJBEi/NSDuInHWeEPTHhr6SFaVkkEEEEauQIMX9Mc3/wCoxC8TeqNOlzSePIKoJI5E6SffDPj5vLo9xmUePqTcE4W9VQ9Re7prF/CWJa8XHh9I+WI6qICAV5+ExsRtJPmPtgzmeKE0kRQWRwCGHwi4Im/6H74Wc5n9FMK58cSecze/r+uAJd21/ieecjse4YyWfRGuJZuSjUTpEBTA63na/LFjIZKrVqd9mgDeaST4VFoNtzub+UROF3LcRUotKmYqOw7x4+Fdonpy98dY7M8JFSmtVzKESoBkEdSenlioFwoQShFCjk0BHh1fM1VZABTQmWZYEiw0ib7Dy3wby9HK5UNUqPLCZYy0TEjmRyt6Y0472iRancZUoahIRm5LHK25Gpt7A++BVSippFS8u5gCfymxYx5Em/PAZDxIofzHqOQN6lHjf/UJO8FJabCn1tqPSBsF959MV/8AvXeViAwCqsEzbVJsT1g/MfMHxDJUFerTVge7AULBG3iYpczGv4Tcwb4p9ncg9Wo9NWBpqDIHOSQL8xYnB+NexBD1qP8Amg5ylQ5YaOT1OYXxatN/Efh25MYJiMUOA5bQFQ+I6dz15nfqfpir2f4/Vo1GoO2qkpCuu8DaZM206bbb+x1KaGrqWwuVW0QeQgwR5+mFto1DBvcYMjlO7Bmb/XFmpt0xDQzK6ACb+d4xE9E6g6kmxBB6GJjlNt8GOoB7lymvlfEdenY88b06gNoxmr746ZOO8d4YRm6tMTGqVE28VxblE/TGmV4aY8QuCRfB/tUoGdpwN0XUeviPysMEKa0yJZb+k4bxJGpnKjOs8Ty4dYMEXB98KHAgaZqZdt0aV81aT9DPsRh5InCn2iybU3Wsv5bN/t/xY+2GZRxNyfGbFTn3afIClXqj8lQFh01c/rfFvs5loTURc4O9pMmK1IPuVuMUcmoCj0B+2EsY5JcptBGCCMFTWw1clXkT1PkMByx5YKZ5gHCTZFUe8ST8zgRqEZuMzqPjMk/IenTFlWPTAiut5BPpy9xi3lszaXNoHi5j16jHXNqXX6fXCf2topXYU9RQoJDqYIJmL9PTzw11I0kgyJ/nnjn/AGwzoSssEE1GC6Z8W129BYYDIGr6YzHx5fVLFTjucpUlSvSFQwNLgamJEboTqDbGf4Qwyder8YGpp8DrJO5Gotc+oIwa4fmIKrUJBYAAk6iOkHcC/UbYNZXPq6KCDrAhdjO/PdZInEbZDjFoKjxgP9+4hrlqqEZQMqEkaS5MgbnTaHjkLHyGAnF8lURmFTeVGrkVsAR5R9sdF7X8OWvS1rJqU/EsbgrcT5/5wocVztLMrRZ2ZSCy1FsSrDr79bRiz4uRcuMsO/cjyYBjf+eoJ4dkPE5MaN5NiVmxAF77zy35Ydck+aUfh1qCnScBkjbcawGIlZ36AnnJGBOdektGmqa2LPFR9IZl3CDopLERttgnQzpKFag1rT0iQQLWkqeVrm/M9cMYFvqENaXUxmuCVaNQ11bUjA2a7LcAkHnJ2wOo54DLsQoFRGUEHWfGSBPisbkgx1ODlTNpUXQXPdyoXTZl0kEG4tpjl05EjADis/iYKN4D4n0iGYKQNhEDWDHMzjeCzC7VIM9lGSkrTLkszNzJgkn6n2wy/wDTPJBKLtUIDVHkX5QABbYzNsLmYotVqVGDFQiMFpmdTaQSSy7Bbb9eW2CHAqzHJuQCmmmWVg3na3Tz8vnzq1a9wFIP/Up5OuRmc29oNWopHkGIUicNOSrioupfhgeHYgwPTkPUThCo5gUa1QTAJb6E7csNXDM6B40go3xA/wAtBnAOu4YMbFYkW5bQfqOmLWUrALEGcCcu0CUJI8jcfLFylVW0/PnjBOMvpnVZbkypt/xiQ5uRtbAqlWpixO9xjWtxBaYYsfCOczH8/bBTIA483eZpFH5FJPuf8YK0MgziVOkbevn/ADpgNwumzsXPxVWJA6L5e36YecrlYUADYYei2KiXao8EYir0gwIOJjjBxWwsSYGoncRyhoyPyH5DCvlzDOgEhbj/AGn9tsdPz+VWohVhIOOa8c4c+WqBvEaeq8bxIlfl1nEOVCvUpxNc1NQwDfkcXuJVCKrz5EH2GFvI8WVpRiqtJgGykevI72Ptg/WqCqiMsMwUBlBF1Fgy9RGFDqOM3ytWwZiA19x529TH3xOKgkkex1fvtgLms4UILU2jaSDt1N7Y1q51y600ADMpaDfwyBJsNzgTqENwtnuIpSRqjGIBMSPEeQ9zHljlHEsyKmbVg4KM4g8xfYxsZwS4xwvOPVYNULWJ5xH+0bD0/fC7n+D1EkxqA3KmY9Rv9MPxKGGjFO3EjUdY1LpPnp9j+swOV8EeH1tQ+MFtwNiI8+drxhb4PV7ymrnfYzJBEwducwcXTxGiKhbUsndFkxFjtMAwN8QHGbInr+RasmNFPOqUJmR6wPfATPcNy9R0r0dJd72sGg858pj2nFD/ALiFpFwP6bydREb+QmxJAv5dcBshx1hWRTTDLMaE6dBYAQY+WF/H+MykkRGbKo0YycT4iEV6Yy7eIQy6fDyG9xvGKXAWLSmZQKBAgWLHlKi8C42G/phgWqtR9AovTYq0O4UlSR+USbCSd8LwzVRKhpOxDqsMwO0zIEzv5/PFq3xoSY9yLN5xaTE0w5RWMArHi1Az16AiYufDzwzZvOqHy9JaZIejJfcahuGPmOfUjATNV1ylEMqHUzEEm2oL+YapsdX38sXuzWYbOA09R0ggFWYuDzEgxz54bz8dEbiSOeiai1keEVszWIpSqSyPXuAV2YAmNU+n7YPdsqlKhRGWom+gCptCot42mW2idvrX49xbOBW7vStNRpKIpDowsZ6jnIixB88LDBe4NTXLlyGQm5DQQQPWZN9sYQ1gt16nKVNwlwrhRz9KoVgVgSY2mb2/bAzLZurlSUYc/ECIvtI5jbG3ZvjzZWsrgTf/AMl2j088N/bVcvmKAzNIwY5bhomD16YbQ6MSWI2IPyvG0gFWvFwftI3+WDeV4+kCWmfOfacczp0p3OnfY+eC3D8isMylqmkS0XgfwHCnUCNV7G46Vc6JAB1m+wuLm1sC8znfxB7u+lWBqE222HmcCga1RYpzTTy+Jv2HmSB54bOznZ9qjhmJgXtsT1Yn4j9vrjlUg77msw9Q92c4afjYXIsP7R0w1pStjXLUAoAxYjFirUkZrh7GDj2PYbAmhxUz2USopVgCCOeLrDETYEgHRmg1OQ9sOxZQ6kBKnpuP3H1wkZqlmKUBnYgAql7aSZIHQWmPLH0fWpBhBwk9oeyMy1ISDuh+4PI4lbHw66lKZOWjONZjUdyTHUk/vgzwTNVu+/EPUYt8OoiZX+3oNvmMTcS4E1Inw+HmOY9v1wN1EDSD4DeIEfz9sKY8hxjgtHkI9/8Ac0eCQNW09PXywJz+SapUBYpo0jSyyHDg8m6YWRnysgyV/nS+LFDNDUG1OBYmDIO3I+2JPAyGxH81YUZFxbI1aE80Y3iwDeY8xfpIONeHV6dKmTphoId5gwYi0GYI2GGv8flszTKagZF1NjaNp6bj0wn1KdipuptOxjdSJuBMfw4pxOWG9H3FMANCCs9mmJgSFgDSD4bTHUQOQxY7NuVzCEaZ5zAtBny2+eIs7TAIC2mCQbn/ADvvgjkjTal4Aq1kMHZWYGIKkmNQIiOc2jFDEcYhQeUeuF5aDTVl7wAsTUYywPkAvtyEYF8WWiuZJdVYIsaSLljpY+Xnf+44K8ErPSyxd4ZkBLNqBAABmT1sRbnzxz/PZ9nM6p/uMXmZNvMGMTIpJMoyECpZ7Q8UNdyzEW8IC/CFBMAdeZJ6+WIOynGzlMyG3U2brBi/sf1xRNOwjn0/m2K+YokMp6b9IttigAVUnN+p13tfQ0vTzK//AB1oSp0Dfkb3nSfUY5Zx7K9zWZIgTI9949/thy4R2opNk3ymYJPgKoYJmx0ExsRYX6ThI4rmXqVH1HkojyH8J98bjexxPqA6Vub8PzCpVV3khDyifb9sXM5xUOa3djRTdgQtheBf3MnAnvLXA8z1xNlss1Q6aYLH6D32jGHGC1zedLxmlNCw0qb/AEwe7LMKK5h3/wD5QB/cWYBf1xPkeDJSANSWfeATE9ABc+mGzgXZN2H9WkFRmWUFmgGZJ2EdMZlQ1UHkKgjhXB1r6Q7vCLzPhJA/KOcnnjqXCckKdJFAiAMT5XIogAVQALCMW1XDseKjyMF8nIUJhVxvpxlUxvpw+KhU4xj2PY6dM40YY9j2MnSF16YwNsZx7AzYN4twinWU6hDcmG/+ccr47wRO9ZQYYH4gN+dx+uMY9ibKKYSjGTUSqtHuyYvZht679cY0QSJ5T9NvTGMewMaJRzdcggjraLRbFnI8Rd5B6c9/Scex7Bf2wCafUq58yfcfb7YI8HyikTabEWmNtsex7HH7Zw++N/HUNHJ92pMNUAnmFJLR5jcehxztq506uZYn6jHsexmL7IWf75LRqfIkWxaprf6/LGcexzTFkFKNbVI3O3Tf9sT57IqXUyfHS1EW3DMtv/GcZx7AHRJ/UYBagH8y/wAM7Po1R1ZiVTkBBO+5k/TBis4pxTRQokCwjfnj2PYpBrFy91Ja+uv3Oldnuz1Kiqt8dQgHWR5chy3wfCY9j2GIBQimJuZ043Ax7HsHBm4GPY9j2NmT/9k=',
    'description': 'ก๋วยเตี๋ยว \n\n ก๋วยเตี๋ยวเป็นอาหารที่นิยมมากในไทย มีหลากหลายประเภทตามรสชาติและวิธีการปรุง''เส้นก๋วยเตี๋ยว, เนื้อสัตว์, ผัก, เครื่องปรุงต่าง ๆ\n1.ต้มเส้นก๋วยเตี๋ยว\n2. ผัดหรือทำน้ำซุป\n3. ใส่เนื้อสัตว์และเส้น',
    'price': '60 บาท',
  };
  void _incrementLike() {
    setState(() {
      likeCount++;
    });
  }

  void _incrementDislike() {
    setState(() {
      dislikeCount++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ), // AppBar
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            // ปุ่มไปยังหน้าอื่น
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/page3');  // ไปยังหน้า page2
              },
              child: Text('ไปหน้าที่สาม'),
            ),
            SizedBox(height: 20),
            
            // แสดงรายละเอียดของเมนู
            Text(
              'รายละเอียดเมนู: ${menuDetails['title']}',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Image.network(
              menuDetails['image']!,
              width: 200,
              height: 200,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 10),
            Text(
              'คำอธิบาย: ${menuDetails['description']}',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 10),
            Text(
              'ราคา: ${menuDetails['price']}',
              style: TextStyle(fontSize: 18, color: Colors.green),
            ),
            SizedBox(height: 20),
             Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    IconButton(
                      icon: Icon(Icons.thumb_up),
                      onPressed: _incrementLike,
                    ),
                    Text('ถูกใจ: $likeCount'),
                  ],
                ),
                SizedBox(width: 30),
                Column(
                  children: [
                    IconButton(
                      icon: Icon(Icons.thumb_down),
                      onPressed: _incrementDislike,
                    ),
                    Text('ไม่ถูกใจ: $dislikeCount'),
                  ],
                ),
              ],
            ),
            // ปุ่มเปิด YouTube
            ElevatedButton(
              onPressed: _launchYouTube,  // เมื่อกดปุ่มจะเปิด YouTube
              child: Text('เปิด YouTube'),
            ),
          ],
        ),
      ),
    );
  }
}

// void main() {
//   runApp(MyApp());
// }

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Page2(title: 'หน้าที่2'),
    );
  }
}
