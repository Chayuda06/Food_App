import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class Page3 extends StatefulWidget {
  Page3({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _Page3State createState() => _Page3State();
}

class _Page3State extends State<Page3> {
    int likeCount = 0;
  int dislikeCount = 0;
  // ฟังก์ชันสำหรับเปิด URL
  void _launchYouTube() async {
    final Uri url = Uri.parse('https://youtu.be/fU4eQje2Gxo?si=FnNX_gX_DOjZx7f6'); // ใส่ลิงก์ YouTube

    // ใช้ launchUrl แทน launch
    if (await canLaunch(url.toString())) {  // ตรวจสอบว่า URL สามารถเปิดได้หรือไม่
      await launchUrl(url); // เปิด URL
      print('เปิด URL สำเร็จ');
    } else {
      throw 'ไม่สามารถเปิด URL ได้: $url';
    }
  }

  // ข้อมูลเมนูแรก
  final Map<String, String> menuDetails = {
    'title': 'ส้มตำ',
    'image': 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTEhMWFRUXFxcYGBgYGBcXGBgXFxUXFx0XFxYaHSggGBolHRcXITEiJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGy8lICUtLS0vLS0tLS0tLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIALcBEwMBEQACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAEBQMGAQIHAAj/xAA8EAABAwIEAwYEBQMDBAMAAAABAgMRACEEBRIxBkFREyJhcYGRMkKhsVLB0eHwFCNiM3KSBxUk8TSisv/EABoBAAIDAQEAAAAAAAAAAAAAAAMEAAECBQb/xAAzEQACAgEEAQMCBAYCAwEBAAAAAQIDEQQSITFBEyJRBWFxgcHwMkKRobHRFCND4fFSBv/aAAwDAQACEQMRAD8AvQowuZFQhmoQ9UIZqEPVCGahD0VCGYqEM6ao0ontNTJpRNgmqNYMhNQh4qA51CyNWKQOdVkohVmTY51TkicEjeOQedRNEJu3T1qyGqsWgc6mSEKs0bHMVW5EIXM8aHMVTnFFZRojPWjzFUrY/JMonGZNnnWt6L4NhiWzzq9xMIzCTsavJW01U30NXkraakGoZwY1VZD01CGZqEPVCGDUIamoQ1NQhioQJioZM1CGahDMVCHoqEM1CGYqiGYqZNqJ6ao2kemqLInMUlO5qZwQV43iNtHMUCeohHtmXJCXFcYD5ZNLT10V0Z3ivEcSOq2gfWgPWyl0VuYC5mTyvn9qFK+x+TOQZ19fNavehynLvJDzOauJMBZ+9XXdNeSZwWHK8Jj3yIBQjmpQi3gNzTqle1x/c3HLLCjhBUy5iV6eiQB9TR1GXcpG/TfyEM5Ngkg/PG5K1K/OKG76Yptvo0qgHGYPLV90jR4/3E/Xahetp7eItMtVwfYrxPBaVArwj4I6FUj/AJD86w9NGXMGDdPwVXGofZWULKkqHKd/EdRSst8HhsBJSTGeBwuLLSnAowOR3NGg7sZTCKMtuSHD8QvjmDWVrLImdzCxxc4N0/Wix18/gnqhLHGQ+YEUaOv+UaViHeBz5tzYg03XqYS6ZvhjNLyTsaYUkysG2urM4NgurIZ1VCHqhDBqENahAuoZMxUIZqEPRUIZioQzFVk0omCuqCJGKosHxWOSgXNZlNLshT824nUTDd/HlSFurf8AKDchM9mLq/iUfS1Ku6cu2ZyButc6VsWOSj3Zg3rGUyGik9Ky2Vg1KiK1GRCxcPcLu4jvKBQjqdz5DlTtOnlPl9BI1t9l7yvh/C4fZAK+ZiT707XCFfC7GVUlykFY90FMSUDoB9zSmptlLjOEOUVpc9lX4gwLiWlKbWSn5rmw60ldCahlPKDScZLGOTTKMMU4SALrk+/7UGUX6L47FdvGAljCiAFTYRyE1yHFqWev7GZQ+BYtjs3FFpN4nu2rr6LWTmvcs/8AoPCuO1MzmSUvBlax/cTJIMbTaYrpOamlnsFZp05ZG2HxadMREiiOz5J6XwUrPsv7NZWn4FH2NJ3Q/mQjdW4P7CRwg0JZQu8EaW5rTlgwokiUabgwfCq3BEsdDDC546kiTIpiGpsj5NKb8l8yTMUOpF669F6sXAXhjB3DkXFMlNEIdjeoZwSJcqFG2qrIemoQNqGT1QhkVCGwFQh5SgKzkIokRVNUbNXHAkSTUbwQQ5txElIITc+FJ26uMeEU5FQxWYOOmSbdKSlNz5McsgbdjcUNIy8m7KSswhJPlWOckim+iN0Xg2oNuWyGgTFAyRI1UqtF4Ltwdk6FIS4QFE3M9OlHoSzljtFa2Z8llzl9aUpQ0Qidz0TzI8Yp23UuC4D16ff+IgVnrgWnStPZn4BFzFu8dyaRt1WohYvC+P8AZ0YaOp1/L+S1YXEmBPPw/SumrXhZ/wAHNlWs8EeNytt0WOhXVOx/3J2UPOpZTXavj8Ae6USu45WIYkvrETCdCYTHIwZg+FcvVVzg/e3t+waCU1wCZWp1zSXlgiDq092PAHrSHo1Te5vg2orwuR2xlqWgSCVJKVQTvflXUorhBPHWGVJybwUTAYwF1Uk6ZIA6XpCWYtSOnFJxwSZm882pCmSFtmyk8/MGnqr1OOPItOlRfI1wpDqIWgieRo8GpLlYFLIJ8C3GcIpMqbcgnkdqp1RfTEpaPyherh5xDLjqyAEGI3Kr7+VY9BuLk30LyqcexOVUDBnBGRWisBeXZiplQINuYoldjhLKNReDpWRZyl1AvXapuU0F7GT+GBpgmBc42pNUZwZbeq8mcEuuoUMxVmTMVCGUpqiHnFxVNhYrAOTVGgTM8ellBUaFdcq45ZCh47PnHZElI+tcS3V2T48Gd2RW4sgWNLrjkmCIYsjaiRlJFGqscJvW8y7MtnTOGMA2lrUkfEJ96Lw+UdPT1qMfxEnH6EIQlSU96eW9YlHLSRWpqW3OOSmZYXH1lKBECSTYAfrQL1GpZl5FaNLZe2oeC0OcPIQka1G43pSyyVc8PoN/xoR4kF5Njf6ZHfclOqEjnJ5VuizfPrB0dDoZWxex5COJswdIKEqgqKQIE96QQNR2mKcmntz4GKq4qa+Rrg+HkktrcCgpHeAm0nqR40GjTy7tk2S7VPG2CQ0y3LCyFq1qVJUqCbAdAOVNV0zqi5Z68CllkbGlgJcdSoJlKgY1AiwtFioHx251frKValhpmPTxLGTZshxJbeSCkjcjbwI6eNEoulOOy5cP9/tmLYKL3QZXs0y1WHWFEksi9hz5autJ6rRuvlcxC02qfHkEOeoedbRcNyUk7XIImeu1Brk5Ti2sRQWyGyLx2UrNHEYfEllYMpO4HqD4yKO9NJZz0YjqVxgszeUnsw6pXdkbHbzodUK1jsJZKTHOAWkiAoH2NdKKj0mINshx2EJIIXEHlFDlp+cph67ljDRFiWgtCkKNlCDQ9jUuSTipRwVt/hczLa7dDRfSXaEpaV+BXjMqfa3RI6pvUdbXgBKEo9gLoIHeSR5ihOJnDJsszRTKpSbcxWq5ut5REzpGQ54l1IvXXpuU0bHKgDRyhfisJzFU0TAH2pFoqZM4LIK0CMgVCG7itI8aw2FjHAGTNUaMOLCQSeVVKSisshQs9zIurP4R9a85q9Q7Z8dAZPIqUkEUqsooGcZoikXkhbwK1KhAJPSjRlng1HLeEbYnI30m7ZPlRY89BZUzXLRb+FeI+zR2TyVJIgJkETyFXD2+1jdVyxh+B4nLVupdcebIKFHRN5TAv7zTKqcYbvIX1Izmo+BOps6AvRoJJBEbgEwfKK4evnKViz8Hd0lNcE1DksqMC242nUDcTG0ftXSdULq4uSxwcW2OJtfDE2OyJhZBGshJBEGBPW9LqMK8uI/pLraE4xxhk2LQVuNgaUgEEzfvAzfrzq5KVjis4RW/am/JYThVyklwkJBASALzzJ6imbqnBJ7vwFa7VLKx+YBmmIcbHxEAgjlI8aBbOcIZbCQjCUsYG7sjsmwPi3PSE05ZnMK15/0KRa90/gUcQP6FpSFwSDzgm31rnfVMwaSb/f4EW91OUY8efsLcq4lTr/p8R3m1BWle+mIkHqm/p9mPp+rezZbyheEZT5j2KuLsl0QptXcm8bpk/ED+dE1VGz3R5Q9RP1PbLs3zplL7CHiAVJ7qpF1J5Gf5vSDtc61Jv3Lj8fuMxqUJuOOHyhXg81KW3GTJEAp9flrXKSI0uxTkjDxXpS2oGYvai2VOTwuzmenwNs4W40oI1krVeBNhUlXOvjIelcAj2OWmQVGfOh++MuWOKCceCLAZ2sr0aifOmd844fg6Ff0+Lo3S7HuCzFZBDkdAaYhY0snJv0+14Z57Bzv3hQpxlnKMKMGsMpecoQ24QD6VexnLuioy4NMpzhTSpTtzFEi5VvKAKZ0vIM/S8kXrp03qaC9j8GaYKIlYcVCB9WAJUiBJrLZuCA3FyayFNU1CFW4rzgJKWhsT3o6c65utuTah/UxNg2O4dKkJcw6gpJiQeXiKTnol3HozsysxIs9xGHYY7BA1OqHqD1PSiWwrhDajTSjH7lfZSQL71zpdgsj/AIObh1TigNKU39f/AFTGnhuy/gY08sTyWTOilSO0aIiJHSs2WbJZidytKceRLwvnacVrSWwS2QCSUi5Nonfan020m0czKbaOgpdsPK9NuWUZUSvcQmTbpuDfmIjlavO/VZYsTX9f0O99M/hef6AWX4/s7OiUxGobgeND0+sSWyX9Q1+k3PfD+gW2gLWUpMFQ+GRJETInlTUYSlLauxST2Ry+idWVTGuAkf8AL3o0dG+pvj+4GWoX8q5CsPj22yElQ0ix5wOpNFdkI4XhA9k2m/JFmzIU6lIvqUn2J3PpSmohm1QXOWv6B6pYrcn9x843KwrpYetdZLNqZzc4hg5r/wBVWz2iFA7JiPMkzSmpmvX2/Zfqer//AJyWaZ14+/6CvhFkPEFdyiR6qET7TQK4Ytx4ZyddpHprZY6fK/0aJ4naZW4ysL0pUpBEAixiwmixrsjleDPp70pLsfsL7Rj/AMZSXW7gXumdxG4PgaFLTN/w9fH4lO3a8SXJBhsi7NwOE6hvB5EeFGWn2tP4AO3dlDNt1MqUICUC/nvRYzU5PHgxKtxSz5Ksp5b61L+HVseenlek7JuUshoJJYEOcOpZMTN6uuqU2xqOMIEylUuDxmiXLET0H/iwW1tsdmeouPShV2JcSOZq68xygDF526lCtAlQo0ZrfhnGti1HKKcp/WorWbqMmmZJ+DkT5fJOhSRQmpGMIPy/GltQUg+nWsxlKDyiJ4OiZBxClwBJN66lOpU+PJvssoNNlBzaJMVYBGmNcvArAwlgEqiA2Z4wNNqUelCvtVcG2RnL8bii4sqiZNeebbblJ9gNzbGGUZ8vDqgk6enKi1WzX3RtLbyWMtYbHpmyHeShY/vTEHC77MJlSK3nWEfwyShxIUmbOD8+lYtg0trRiUcIe8NqDuAcSj/UhUgb84odcJYaiHp2+n9ykZZn7zSVNfKbQflNS2hS5RVWosrWEXTgbg9sKTiXIWSApKYsCbyepo8FKWEbrr/nkXrEum6U0S2e3KQxXHc+QZeBbnSpVzz6mudbTGXtkzoV2OCzFACspFytQSkcxz8PA0lD6dtzKcsRXn9+Rxa58KEcv4/fgHzrMUIILYh1JgGOY5zTd+ohGXs4kitPpZ2L3v2sVrzfEulJMgDcJB0q8VefnWJ6uyTyGWjorTX/ANQ4yRhskiFDVMoN4t8p6U3poQfjGfBz9U5R8rjyNOH8NpWUKIUUkkeAFhRtNWoz2tdCuok3HKHqk3Hn+VMxg/UTYq2tpSuNsp7denVpgAgxNwDb61z9VHGq3fbB2vo+s/4y3Yzngq3BLBbxLzZIMWJBtqST+9EhHLTOj9YasphYvP8AhhXEPA7a1uYlU6VEqOkxHiRzHjWrJXJb4vg4VV6WIeRTlvD6UqCsO8tpQ+ZJJ9+o86BVqJyeZNB7Jtxw1kuOLxjmGZT/AFBQ64fwp02PW+/iAPzor1D6xkVVSfPQJinkls6B3V7+u81UZLDwuyNPz4E2YNLSiWto33g/pQrFwn4NweCgY1DiypKpKgZPWacrlGPuQeENxZuGuGX1gLPd6A7/ALVicPU4R0JfUIQgo9jrMGywQFmx6UpqaGlglVyuXABnGFHYqeZ3vIrFGJYUu0JaqDhFtHOnCUm9dpYa4POyTXZK05WZRB4D2KBIrAxy/EqbWFJO1DUtryjSeDouD4mQUJkwYrox1ccGi9NWSVU7IFBCxxUmsBTyahCocaZj3g16muR9QscmoIzIq4bB2tXMxIxxk0fwsjrVxntfJtSRJhG1twQYI5it7svKZnBdMizpD6Sy9BVsQeY6iulRYrY7Zdmoz8M0RlSsG72zA1Nn40cwPDrVenKqe5deQqS8AWaZCxjSXcP3V8xESfEdaqe2eXEIoLyWrhfDOtspacTGkRPUCrpi84kgmcR4Y8cwQtJgdBvRbaVLt8IqE2uuxRicoU4ZDmlIMjnYdSa50tM7XujLCOgtTsWGuTZKFIc70rSsnWSRAPIgfz6VqNUqpqMuU+/x8AJXOWHHjAvzfLnArWkQdoFpA2PnvSOronGW5f2+P32dXTamtx2MQKxToWkFUAqSDYSATB3FL1y3PDHZ1V7HLBZ8XjsOj/TSNSbSQZ/5GnLb4RX/AFdnKhVN/wAbD+HEpUtbo30hJHLeZ+lOfTpynuchTWrbiKHxG3mPtXTiuRF9FZzdUvLBFgBfxIrm6jm5rA9RxWmULE4MtKcU05CytRVMbEkwOlJ2W4k0/HHB1Z6iVsYp9JIecNKcUwdLhlSiL3T8UEwbEQD7Uxp9+OH2c25R3coc5lgEYTCnQYUuwPMCCSaPqNMoVcfv5M0XOdpWs4xQxOFaUDdICF/4rRY+h39aUXGEvjAdxw3+OTTJkKLSgvnI8LWolaeXkHZjjABlrrjLvZqlbahqM7okmw6jwqblForGUNBkrSVdqlII94oirSeV0V6rxtFec8ZpaGlpMnrsKOp7uIhadNveZMqOMzdx463FTHLYUKUeeTu01QhHER1kWZmyCJm0UnZU1LMSTrTXJtnvB7bq9TRKTPeT+nSiVaycMwaOHqPp8ZvdHgo+OwxadUjoa6UJb4Js4dsNknEJwyCaFNpAcNhrTBHOgSmmTaw5LKqHj7EwzvOMOlAFehfZuC4FVUaNgajLOb55iA48s+MA+Vebts32SYJy5Ag1WUkysmxKhWsPyXg1DpNClBdlcmusTOxHOqW5dEH+VcUrTCV94dTvH503HV2R/i5QSuXga4/CEjtsKstr3gfCr0o0mpLdB4Y3FZ7LRkqXAykvK1OKEk9J5CmIbtqz2VhJjBwwmKqx8JG4LnIpcsStZISm8eVcyf8A1tyfSGJT9pXcVjHruNr+I/BvYmLjlSFeosi+Zdg4VSa3lqwjylJ/uaYSAN/vNP1XuafqNcG0sPERVm2DQsFQCSUlOlVjexF6DbV24vo6NFjSw/IuzDLS4lDjCtBUqVjcEi6kx7/SqlJYTxnP7/sbjLlqXgb8Cu//ACUD5FI/+yNVveuj9OjiEn8nO13MolsZcCgkg2KQQetdGDzj8BCyLi2n8lXzZ4JdWTtInySkfpXL1Nqha2/3wO1RbrRz0ZhqWbDvKNjHMmufJNtyOkq3tLrgn22FsJMALVp8AdJj7AetdShqCjk58oynuwR8cZnJbbEEqJSB4kgCfWjauftwXpKsNsHzDAITh04dIlWkSoHdUydq4ll2zC8/vgejBybfgWYPFFDZaUIKefIinqr04bX2hSyrEsit7MTFoKtvO9A9RtkwG4DFYlDgUNJbIGpJ/ljTFc5Lkw4xaCczyfDuy82gKKe8psXM9QnrR3FSeYkrtlDg55jcUMQsltAQEiAnmfOtS9nZ19NPbHOckeXuw4nUdICrnpVOOR1yymXrD5s2V/21agBE9TXP1icbFKItGuTh7hLxRw4rEK7VuNY3A5j9aZ0epeNrORr9Gpe6JTFIW2opVYjcU+9sjhzg4hLOIV1oMoIA5Mbs4uwvQOuAqfB3jNjcCu6bXQtFQsw+e4ryP2rFrxB/gUctWlRUVdSa87B55BGwJ5ijKKwVg1W8ALmKy/hEwaN4tB3rGH5JuMyk0HkvciJuJNaecGq3yPcozJSSG5lJIA8J6VUJtPB0q84Om4JPdTPgK7ME+Acsci7iLPmWLKUNW2kb0O+Sisjmk0lt38K4AGe0xSBI7MKvHzaR4VxrXO6ez8wmo08YS2J5S7f6CVnCpw+NhapCQFAG8FQJv1irfs2qSRmWNu2A/wAodCwp5xMhQIQPDrB8opaiEIbpz5yKu7bLgkwiCWnEpgQSqeUST5Cj6Vysrko+ORmrURlNJr8CocO56RjNKAVpXqSZ+ECJCgOspF/1o1SlXDc+ztavQuFe6fBfeD8GWw/qmVrCiTzmdhyA2FPfTlLEtyx0cLXyi3HaWCIgDkK6UVjgQfJyjjLM1do4kL0jURFpPKvP3pzvlxxk7engo1r8Cr5Xg+0cTJ6qPOwvW5Swtow5PstXE+E7Xs/7nZoQkqWo7iYiB1tTbipYXgSre3LM5flTeKIS4FLSOa/iMQdR6Xi1ZpW6fDZVtriskzuEeStaGgVobAkjladMHcwZt1rn6jR7ZtR5G6tXGUU58A7rDrxII0J0kFRESYNzPnWaW1xjP7+Qd04drkEbaaaOlJK1DdRED61tb93KF+Zc9BjJUVA2KenX1o7U5PgiwuzV7AAOa2iptXUc+oPUURJ5KyuiuZ9w2648t5ooSVRKRKbgQVDxO9NK1SWJIJRZ6bx4KticMtpWlxJB/nOr4fR1q7U+UFYHF9mdQmaFODkMfxI6bwy+FNdssQItPPxqUVqOZvwcbWye704lI4zydSnFPIEya3XdzyIanStrKEOVsBatJtG9XY348nMVPu5DnezBIBoOJA3sTwd7zX4q7gQX1CGwvUaysFM57mrSW3loEgBVq87Y4xk4LwymkCr96F6mDOBXj2iTMT5VuEzEkwDTfnRs8GcZCEpUIvahtxZNrM4rElEAe9SuClyz030fRU2JynyS9jiEBt5aSEEhSDYBUXiRR2ksZR3UtPzBJHTeC87ViCsnuhOkaSZIJmb8xTNc/c34OBr9LGlpR5yD5zkjfaSof31q1CBqkbxPWuXZHc3Fv3Pn7YGqNbZCCX8qWB9krWkkquoIP0JkD2+lD08W7pJ8tJiO/epNdORQ8xBezFSRbafBIQKzJ5r3Pgmo9iwi0Yx8JSEiwAgeVIXyf8KOZ2yn5pm7zyjhWrBSgFdVRe55J5+ldHR1+nDh9nsvpmhp01S1NnLxn8M/H3CQyGmw3hVd4nvOC6pHToP541qdyXCWTN10rp7rPyRduBS52bvaqUpWoXVvGkfvTugk2pM4OuS3RwWBGIJ1HoI8/KnoTzl/AnOCWF8nJDg0lSyYnUSZ5kk15u22W55Z6WEVtWCZeACEFaDBANx9j1FSNs1LKZmUFLhgQL+IcgJnbwSLC96cblb0KyUa+y58P4JWHQS6tMkzM2SIFpMU3SpVo590vUftRt/3PDoClNwoKMqUm4J2kq2NgParcYvl8lx09tklAWZbj1YlLz0aW0nQgczsZPvtVxSkm10gtsYVYhHl+X4/Ihz3AI1C+kKEjz51V9S7B1yfQlcZU0RKyAdjytSqrSfYdJy6Rs3xM2mEqWFeQ/OmVlfcJ/w7Gs4GanQsShUGs8PlC+MPDKjxHjA5/ZVHaSINSty7aGaZKDFWGwfZupRiBoQTdR2gXseZosstcDvr+32jjE5u/ilhvDIIaRZIFrdVVVjikotgqq41pyly2OGMJjNGlSAR1JpVyx0Ym4spmZ4QsOk7Sbima7PUjtfg4+orUJbkEIb1CQnehN4eBFyi/B3vNh3q7xBbUIZBrMm10RIpvGGCh0LHzj6i36VwddB13N/PJmXyhIkEc486VxlGDxdt3gCOv71W0mSDWg7iixeDSZqcMFbK9DWkXhMEx2CVYH06VuMtp0tBrZaV8LKHziHMTh2GmyUhsJCp217d29xW52rhrng7Gn1tblKco8ssmTZYMFi22xrV2ye8Sbakd6SOVqHVdLLUwepn60N3wWzGNICw6sXFkdb86b2Qrl6svyOY5ylHYvzBEKSCEawlakakyY1d5YUPqK5FbxLdnlr/AC2XpHw1jyV/hPAhDj2IWmQ44QhSrkpBImeh3pqtR9rn1+pi6xStaGee5U2TMlBPMEpAHjFEu09e7OBrS7VLdtTwA8PYBlI1YeHnSoBRMgBOrmeSTB2mYoSTWFDl+fhD+r1U7OJ8RXSDs3waGroAE3odyjDoXqslPsKyTCOgKOrQSmY8B196Z0lNiUpPjIDU2wbS7Grr4Qw4roD9B+1PqSVTYtGtzujH5KA62HE69SAr8ML1WtdUR471yJ1Ssjuys/menr06rlt5x88Y/wA5B3WlqETA8CaEtLNfA16dZBhG3GfgWTe8gEmjR9WDykAnoa7HywnPMUh5tSAVI1WJUorgTcAeIketG9Z5zj+oCv6ZODznIixqXAEAKSpCd0pMSSYNukQN+ZqRklHA9pNP6W7K5fke495DeCU3hT3luSkEwUyoG/gAKb9SCg8eTzktFep+6PRNiScThSmwdCZA6LA+x+xqRmrIYYN1OufuXBQcx4hU8y2y4kBSFDvzyAIgpj+RVRq2nRrUYWZiyNzJHgoCAUm4WDKY6zUlJRWQv/KjgdMvaQIVtb2pBNp5OfKOWyHO8hcch5nSVb73MdDT9cl56YDLTLDg8rVjMF2eIGlewOxBG1Erf9gc3h8Cjg/Mf6F1xjFkJKY0+I6isaityakvBuFvGGO8+44w6EHQrUrkE3oCplN8IkroxXZzptxzELK3DYmYo09tSxHs5ep1Lkto3C4tFJ4yc/czvGcovNejHBRUIZFQpld41sGiOqx/+a431Ve6P4P9Ac+iuJcBBCxPlyvzrlxUcGFIhcKNgTHPn9K3yvuXuRGrDDkfT9jVtpGso1XhiP5etL7GhhgcnxLye4g6eqoSPSdxW0pyWMBYxb6LnluSlDKUKQkLHzAzeZBnrVyqlsxjn8ToUzUexyTJbW4lJU2O6fEiJ9ifeiwe1KclnCNyecxi+xbmOLSFy4tIgTGoSPAp3m9KX3Wyy5R8BVRJ1tVpv8iJGKYUrU4tpSYFjHdg2M3v/OVVpsZ92MGa9LeoY2PIVhS0e0AXrQpKdIOyQSZKT7Ux6ceY5zF/PjPeP0MLTSi8uOGVDiTEOPYjsUmWkASBzP8AkZuKHKbknt/A6en0jxmTwi35HlacI2pZMuLiSeQGyQOW596dqrVFfu7ZzLZu6eI9IzhMNqUXnZ0pPdBm56x0FLaehOTsmunwFusaSrh35C8vWVP6iDpKFJ8tj+VPQzKX4oWsSjDH3PcQ6UsaT85IPlz+1YvxGnb85CaWT9bevBS3cApAkHUk7KFwf0NIQbjwz1NOphavv8AD+NCbFUcqPvT4HYUuXKQCnMAk/FPl+tZXDGXp3JdG5x6VW+9EyjDolEDecBJlNgY1QQJqoOM+jWHFd/kBvYMkgIkzskXJPgNzVygkaVqx7gN/DrQAopKQSUg/5J3B6EVlNN4ASsi3jIIszvfzvRVlC84wfaQ2yjHOJhHdKDuk7AdfCrSyzm6jTVPnGGMMH2Lh1IUAbjSTvHMeFLW054izlyTqliRM+ziUrBbKUt8wTM+nKtUQlCLz2U3CbC3Me4lhSEKlZ57afEdaJG1xWHyV6MXJN9CXiBpTyWlYgCUiC4N1DxFadtiXCC1005eehLjMj0QtF0H6VmvV7/bLsV1uh2rfX0T4Ipi16HbnPJ56Tw+QgvjpQ9jMb4nf8zRqQFeVelfY1F5QiUKoswBUIxLxi3LKVfhWPYgj9K5f1WOYRl9/3/gHPopJXfauQo8ASMEEyLX8q1yisZ6J1uExPe87n33iqc3Ls0QuvGwB2vWstrkptlowvFLSGQNCiqPhHK5uVq3J39aJKW5YHq9VGEVxyZyTPXH3kNaNIWqCQo2Av0vah1UOclBS7DQ1rb5iXXHuBP8AaagukSkGSEpmCtX8vXXcIQW2K5IptvLE3E2GQIWo6laQk9SQI1AX/gpPUqCksnU0GpcVtfCKw44k8h5wa580j0lT3LKeUbNuApCQoyLQCRVeMZNOHOWh3w3w8gKD6wIF0Dx/Eab0tX88nwcj6n9QePQr7ff+hi68nFOFsKMJuY2sevnV2J6iXD6+BFVy0tanJcsY4h+AQBZP0ok7ZY66FIQy8vyLsNjl9onSJAInwHP6VdVsm8oNOqO15DOJMLrQlR+EX/KfvW9VDPufQLTTSePINw820ptwgBSZgkiRYXiq0kIOMngLfZZGUcPBzvE5M+88vs27FSoGpIgTYXPSlYOMm1E9Rp/qkaq0rX+Zpi8hxTKda8OqBuoEKG+5CSY/aiuDXaHK/qmmte1T/LoY5PlqUJGJxquzb3Q2ficPLu7x4VahlZfX+RPV6+Un6OlWZeX4X/sT8RZ2rEud1OlsfCkfdXjUiuchtFpPQj7nl/I8/wCnsB1bqx8IgT4m/wBgLdaxZclalL7i/wBWblUoRNOOXkqQqI0lduuqCfPYUvp8eu9vRzapSrcM99FHT2fNRPkP1rq7YnSlY/BltetQbSNIO53Jj7VU5bVlIBJ55YqxpAsZkfCofzai1pnH1k1Oz8B9keNsnWpcbEmVAeVK2Qe/7DMYxccosCVpV/pnvbaiN/elrblB8chYUblyarktKbUQZm53msx1bSxgktGpdPArQpDSQ2p3UTsIP3qNStluUcA9qrW2UsgCWyhzlpVcRTDkpw+6POfUaFCeV0w4tjwoG45u1H0E2NTUdLV6eQat8CF9EGshCMVCEOaYYOMrQRMpMeYuPrS2rr9SmS/P+hTRzMFCpBSQZ5GuJWltAp/YwcOjkq3iP3q9pODJZ20lJHSb/aqcF4LwmBvNrQSSkx13HvU2rGDOxjvht7D99WIE2hKSkm/X+daE44fYxp1BP3ob8KuspBUlP/kFZDaSTso2mNgBufCjaaSU8rsOoxw2h3neYrwzqW2kBTjoKnHLkiIAgdBeBTV9/pZS7CVw38+CFjDDFSVJU2sGAsiAT/tJ2MevpQ1QtRHe+H+oy7nD2+CY5SSA24hKSnYgRqF7pV6yQf3peFE42bZ//fwf6DNWrdfuh+/38iDGYTQo2iDB5e9Ztrxykeg0uqjcuzKc6fDRZBBBsDzHgKGr57fTNy0FDtVz7/t+JYEqGAwanFiXFAEgdTYJ9J+9dCFf/Hqx5Zwpt/UdYq4fwr/Hljbh50OsoXv2iBv1vvTNCTXPlCOug6rZR+GRFxtGpAgKRZQ2Pn49aBJwgsLtFKM5NN9MJyvHNvAsqi4sDzHSiUWQtXpsq6mdT9RCHPnHMMgsJbhtRPfFyZOxHL9q52p36eDqjwn5/Q6+ghVqJq5v3Lx+ohOEKDrQTfxN65sNROL7wdd+nats0G5bxCtA0kax4m48id6cq1lkOJPKENR9NhJ5jwZzLImMYVFtZLugxrJPkR5Hl4mn4yja/wDrln7P9BaGou0scTjhZ8fqc+xmVYhlSkLbVKSZgSLcx4VbaTwdmnXwmk0xtwxl2IdlaVBtAtK1FIPoBcVfoq3hrIHWaymKxJZf2IOKslxLSdaghbW4W2SoX5mbjz2ra0yr6QhRfp7J8Zz8MqwkXHK81rjocch7hsF2zLjhAbUlCoUbDzocH79q5RztTe4Re1lfyvM/8QpSRsdlDpRrqOfscuFuefJBh8zcB0kQkrKikDaelGnXFwwbpvcZcl3ZYWUJUy06o7nWEp8oEk+9cixU52qWWdeq99yWELc4zBxtN2lpUTzT3QP921bo08JPsl+shBZFmW4UrcC3CbC0U1OyMVtR52/WOcsof/8AbgkFQGr70Cdcmsp8CNjlPlkNAwwODveXrvHUfWvVS6LrfIHmbEE0MOLqhDdNQhz7i7KC06VoHcWZ8lc64Opq9GzHh8r/AECmvInudx+9De5mMHknp/6rKyiBAeWBN7z6i3Ki7ng0iJQB5Qeo/TagOSfgvkIwWNcYWFIIJGxisxbhLdHs2pyXDC287d1a1HUo76oP6RQ8y3785Y3C/jGBmzxSsbAePQjoQd6jvuTyn+Xh/iMxlCSwyy5fxA093Rv+A/F5oPz+W/nXWovjdHDX5efy+V/cHODi8p/v9P8ABLjsAHU6myFEfb8J6+Rok6N3ujyEp1DrlzwxVlWRDttaxCUX0n8Q2HlzpOGmip7pdI62o+qN6fZH+J8fkMDh0Y15xpZ7iE7dSTBPoLetEjBamx56XQrXOehpjZHuT/sv9hrTacI02lPwoUlIn/JYH501hVJfiKWWS1VspS7eX/YF4vwnwvAWPdXH0P5e1c76tp+rl+DGvpd3dT/FCjBtpBC0g8iCLEEVwt7qe7z4f+zp2e5bWWxzS80A58w3/mxr0kJrVadK3hteDhrdp7c1+CpZzhgyANYNzEm9642o0jreM5O3RrlPlxAnsAohKwEhCwIMwJ9ataaeE10wy10FlN8iRvHFCk6VFMEHUCQYnlzo1EHu3J4YDVaiMltxwWLMMWjShSipSlju7qCp6HaunNR2qT7OVFtNpdFOzHFOuEtBNhYi8evXyoUZtrgOpOLymXDiLClnLEsfN2SUeqo+35U+/wDrqWTnxscr3NfJzbhHPAxiQnEJStskjUQNSPHxHhWdkMbsBbLrZPDY84tYC+0S2oJaUUrCxdGhV7R8V5sKHOUK58dl002WrCFyuDWyyheHWrXvK7A+nKlX9Qe/bJZX2JOlQePIry4I7UawErQqD0MGKJdu2Pb0zNc4qWWdi4beZcbJSoEiCRzEeFJaWmMU93YzZduawezVCVpKUhN99UEHwiqm1nMUXnjDOUY/ArYxa2YhNlJEz3T5bXBtT0nGVSmcPUVbJtDztCQALUF3e3ERZ5IlM9TQXnyzPPydpQYMivWFBuMbC0ahQ2sDKeUIXEQahDUVRYPmmCDzSkHnseh5UvqqPWrcfPj8SmsnOFocSspUIIMEb1yIRzx0CaaPJfgmUgxtPWtcIzySuYgRyH29jWpt4LywX+ojpS3qfKJuNlYpCrH7be1VJqXgvejLrBMQoHnQ8JdM2n8M1S2RyIobwMV2EgOkg8xespvPA/XNFhyziNcyokn8SY1j/cDZ0ecK8a6dGr4xPv5X6rz/AJJOpPrr4/18f4LK3jFPAQsEEX0gz6p+JP28axf6mo4Ult+V+q7RcYRguVz9/wB4MowZacDrSkkidQ5qB3Efzamaa3XiUWmGlerIOuxfh9grNgX2F6QQoEEAiCCkhX5Ua33xeBWn/qtWRolCXWoULKTf1H3o8oxshiXTFlJ1zyu0Upa1sLUgmyTsRY/5CvMavTzrTjF8fB6KE42xUscjDDZikpKQRf2Nc2u+ymDil3+8C9kPcmyJeBS6YFlxzuDHjypmiMdTxF4l9+mTe4LL5QRnaQ3h2UK0ggpF9rAyBXcnHZRCMu1gUqlvtk0K8fkeGejtUAkix5gx1olc4SltzhlSnNG2AyMtpLKldoybjktCvxJPnR41NLa+V/gFK1P3LhmMPlCGF9q7KwLtgDn+JX+VZjXGt5l0SVkprERdxJmJWhS1jSADpTPhuaxZZKbz4NQgoI5jw3gf6rGpQfhkk/7RNvX86La/TqSXZcMNuTOwPYZlpAQnTZMaRsBtEVzZRbkkuy42Sb4Of53xFDhQgwNgAPHfwFHrp44LlJR7JMncwsythTqzuTFZUtn8b4AzkpdIbYrMUsx2TDbavAyr1ArfrR8QBNuPkQ47FuukKUsgjbT3Y9qw7E+GkAna15J8tY7sxKiZJN1Hxk3oFrcnwKOTfkziCUnf+eNZigUnJeSMLPX71ZWZfJ3AV6w2G4Bz5Tz2qpIJXLwBZnhYPhQwosqFm6TUKEHE2Sdp/dbkOAbD5gPzrnavTPm2vvyvkzJZKWl7kd+ciufC7PaB5RCtaZrTmiZiQKSP4aWyy+Galmr3F7USMOEVCbQhTxKY2qY46I48A/bEbkiqcEFrb+SVnEReb+VYcDoVzfyO+HswUt9tISVmbRYiBuVckit1V+9d/l2MOx7HyXRxotlS3nFLUSTFzA/CkC9PYlCTlN/7BJ7uIIzw9nCXe05BJBgnYXHpRdLerHJfBvVaSypRcl2OcKQCAk91Ww/MeFNrjgSlzyxVxPhF60qSUibEK5xSWsUlhoa0liSaYlZydSyTpCY+ZJMe1cmcU3hwz+A1LUKPkmweHeZcSoQuOpi1F0+nVU1ZAzO6NkHFj7MiDpCq6l0VJLIhU2s4EOeuJaQFfEhRgRyP6b0hbW6/d2hqp75Y6YIzmZIGiTRVrXjhZI6F5NE5z/cDTs6VWO0pJ2VPSiRvcpbZA5V4WYlP4jacS6vD6xrBuV7FJuIHQio1seJG4y3LKNskyVxJ1j+mCwDdOpJuDzBB2m9Dc9z9rf5s10uv7Cl3iBwKcR2SULJKVKClk+mom1qN6MUsoB6jFrWHvqi563PvVSnxgBKTHeUJb1gOkoReVJFxa31pWZVco7ve+CBagHFAAqSFHSSSCRO5FW1xwwV+oabjHonK0HkR6ihYkJO1+UTYd/rNtuX2qdc4JGzPgkU8Vb38xUc89k3oHKPEe1VkmUdxFetIZBqEGNnEeNYawMRllCLFsFJqiwcVCG4NURoqHF+Qm7zQ/wByR9xXG1ml2P1IdPv7A5x8oo6qTQJmC3V7isG6EmstokY4NkJM7VWUEWQttwQZ5db/AErcWjabRoqFkJCNSjYaTFU5ZLT56HeC4XkpDrgST8oIKvKBW1RN8vC/yN1v5LdgstRgmyW21KUrdUSfK2wplwdEcpNsLFqx4zwB5m6Cwt1SiDoMXvq2iPO3tSdlTmvUm/Hz58nY0LXrRhFef7CLg/FttA9oFEuAJA+Ui9z71dV0ISlu/A6f1mLsaUccf1OgrSewbUj5D9OldT/xxa8HlP8AySTJM9GpoLBAiCZuIIv+VXqVmCZil4nhiBvPG2xoCgokz3RJ+lc9WxXtyMSqc3kHGaq1AlEIkSVGD6ATVqUl44+5r0o475GudPuHR2KC5q6GwFrzTNknhbVkBTFNvc8Ar7A0f31ARskX+tVKrMffx9je/D9gtzrHtsMBTYQAbDrPUgb9aWklGOIIJBuT5ZzTNM/KgeykkmFOK3PkOVHrpUeZdmZTGXEL/bYfB4pc69KmXbkFRbI0q8ZEn18KNYt0Mr8AKliWPHYxwnE7TYHZNFcCO93RMes0lGuMGm1lhJ3NrCKy2wXXSo7kyrkATf8AgrU7cRFLLkg5eHSOlLKbYtLUEwaEcqxuZl2mf6OTCSL7TatKXODOcg5YULR7Gr3ow1knLYCB8QVzEb+tT2vyXhYISsx+1VgzgwHB41e0mDuYr1Zo3qEJcO7pM+9RrJcZYYXi8OFpkUPoYTzyIH2SDUIRiqIbxUayQqHFHDBVLrIvzT18vGuRqdHte6HXx/oxOGeUUhWoGFCCOXSkOPAHkmb6mstfBpNknbzuKmWaUmbEReN6vOO0bTXkw26pElCoteLWrJWAjLswW24FjfrbnvHQxUj7HuQWFjXB0bKMweWjWpMJ+XUbkdbV2arpThuxx4D4j8g2f9k6lIWQkBQUrbvAfLPQmPag6hwlHngf0d8qZOUeXjC+33IMJicGCIWkEbXigVVaVPcnyXbdfPvkf5Vj23ErbQsKgTYzXQqcJRcYvIlbGUWpNYM4d5K2y0sAjvIIPtBrMPdDbIqacZbkcrxnFXZrU0yxsopM7yCRZIFKRrjAalJsd5SHndKloKR/mbk9Yiw8PrWlCM8YWfuzO9x7Ds14laYToU7qV+FG/wBNqO2o9sDnLykKMhzb+reU2olkFPci6lHnc2FqVtsw1hhY85NcrykOOPNKdIcQoiTcxyVB3ERNVVXvnyyStwsCPOcKppzRiGkzuFpEBYHj18NxWrozjwBdhBmON7VKEQENoB0pG0kySTzND9SWFH4BStXYLh8OCQBWHL5Au5DTskoSe6ffc/rWHHPLAy+WArneCR1saiQJoMy9tKld9SgOVufQ9KkYxlLDeDUYoOVhkQSFKt0Aj70Z0V4zk3tFr67mJ9RS7SzwZcSB14+FXGJlxMIcsTy/Or2FKAU3BAP51qNWVnJvadqFemKNxVlGRUIFYTEaTB2qmsm4SwTY7BBYlNDDiF5opNWUaA1MENxVEEOecMNv94d1fUc/OkL9Ep+6HDKcUyrY3KuwOlafJXI1y5/9cttkTPCAF4cEzqtQm45+xG0ahofin0qe35JlAxbNVlGuAnLcUppRUkAkpKTqAVY9OhrcJuPSyRpp5Qc7m2IUNOsgARAtat/8i7G3JncwAYV5Z7oWv3P1NY90+wi3+Bkxw3iVD4APMgVpaax9IYjOa7kOMqwb7BGp5CEgzEjmIpqmF9fHGA3qRl/FyT4jPWWyT2wJJmEjV9qjm4yy5FucMYwVnEZy3rUplgSSVFSoBJJkmgynHOTDvSQDisxxDxhSyB0T3R71Jah4APURRE1lyaWd0mZepTJmmAmFAkEGxG/pF6y5tmf+TgkwuILbgUFEKmZMkk+PWtKc09y7KV8emXnMMxwxw6VPBLoKQezse+IkX5A/Q12HfX6SlZ58ecl+ok+GcwcZJWopgJKiQkcgSTHpSE7IvlIFKcfkLwTGm5VE0Jy3PAPgIx7qSICpvW7HnGGVIAgGscoHtCmGgoESZ8KkYuTNqPAeyShOkgjypiMdq5RrAC6pQJkmlJRW5mWmQluefvUTwRJkWkDp7VvLLTYezlDykhSUGDteixjY1lBlXJo7GDXpQJuKhDYVCjaoQLweJ02O1U45Nwngmx2CChI3oYcQvYcg1ZREKmCGaosixWEQ6kpWAQaHbTGyOJIoo+fcJOIlTKpT+EnbyNce/SurntApVfBUlqULGl0kwLTPAnrUwisMkRiFDas7UaTkvIZhs5UmApIUOQPXx61p5x2MU3YeJrKHDedPuAQvT4JASKPGdslw8fkU5yyQvrUrd1z/AJGo1b/+mTewROCQTdZnxE0L023yy/UMuYdCbChWbU8YKc8mW8NO0ddvCrjFS6LS3HlYU32rLrMuJGphUTFvOh4wsk2cGW2p7xrdcU/JnabquevnRtryXgjxMCxms2QSefJTRnANAiU/ENwenga1XXu67IorwSLiNq06lgm0FcQN/wAqFKDSK2kXZDlWMtsrYbMAAyRW4d8lpYDG8VeNNvemlZzgvkxjkJgnT9SKzdD+ZFMBTI2pVPHJE2iwZFkPbqDiwAkHYQJ845V0dPR63LXAwku2XxthKQABYV2FBJYRTbP/2Q==',
    'description': 'ส้มตำ\n\nส้มตำเป็นอาหารไทยรสจัดที่ได้รับความนิยมอย่างสูงในภาคอีสาน เป็นเมนูที่ผสมผสานรสเปรี้ยว เผ็ด หวาน และเค็มอย่างลงตัว \nจากการโขลกมะละกอสดพร้อมกับพริก กระเทียม และเครื่องปรุงต่างๆ มะละกอสับ, พริกสด, กระเทียม, น้ำปลา, น้ำตาลปี๊บ, ถั่วฝักยาว, มะเขือเทศ, น้ำมะนาว, กุ้งแห้ง (หรือปูเค็ม)',
    'price': '50 บาท',
  };
void _incrementLike() {
    setState(() {
      likeCount++;
    });
  }

  void _incrementDislike() {
    setState(() {
      dislikeCount++;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ), // AppBar
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            // ปุ่มไปยังหน้าอื่น
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/page4');  
              },
              child: Text('ไปหน้าที่สี่'),
            ),
            SizedBox(height: 20),
            
            // แสดงรายละเอียดของเมนู
            Text(
              'รายละเอียดเมนู: ${menuDetails['title']}',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Image.network(
              menuDetails['image']!,
              width: 200,
              height: 200,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 10),
            Text(
              'คำอธิบาย: ${menuDetails['description']}',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 10),
            Text(
              'ราคา: ${menuDetails['price']}',
              style: TextStyle(fontSize: 18, color: Colors.green),
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    IconButton(
                      icon: Icon(Icons.thumb_up),
                      onPressed: _incrementLike,
                    ),
                    Text('ถูกใจ: $likeCount'),
                  ],
                ),
                SizedBox(width: 30),
                Column(
                  children: [
                    IconButton(
                      icon: Icon(Icons.thumb_down),
                      onPressed: _incrementDislike,
                    ),
                    Text('ไม่ถูกใจ: $dislikeCount'),
                  ],
                ),
              ],
            ),
           
            // ปุ่มเปิด YouTube
            ElevatedButton(
              onPressed: _launchYouTube,  // เมื่อกดปุ่มจะเปิด YouTube
              child: Text('เปิด YouTube'),
            ),
          ],
        ),
      ),
    );
  }
}

// void main() {
//   runApp(MyApp());
// }

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Page3(title: 'หน้าที่3'),
    );
  }
}
